# 🔐 FACEBOOK DOMAIN VERIFICATION REHBERİ

**Domain**: xn--hriyetsagliksonnhaberler-65c29b.site  
**Sebep**: iOS 14+ için domain doğrulaması  
**Zorunlu mu?**: Hayır, ama önerilen  
**Süre**: 5-10 dakika

---

## 🎯 NEDEN YAPILMALI?

### Faydaları:
```
✅ iOS 14+ cihazlarda daha iyi tracking
✅ 8 öncelikli event seçebilme
✅ Aggregated Event Measurement
✅ Daha güvenilir veri toplama
✅ Facebook'a domain sahipliğini kanıtlama
```

### Yapmazsak Ne Olur?
```
⚠️ iOS 14+ kullanıcılardan sınırlı veri
⚠️ Sadece 1 event önceliklendirilebilir
✅ Pixel yine de çalışır (Android + web'de sorun yok)
```

---

## 📍 YÖNTEM 1: BUSINESS MANAGER (ÖNERİLEN)

### Adım 1: Business Settings'e Git
```
URL: https://business.facebook.com/settings

Veya:
1. Facebook Business Suite'e git
2. Sol alt köşe → "Ayarlar" (⚙️) ikonuna tıkla
3. "İşletme ayarları" (Business Settings)
```

### Adım 2: Brand Safety Bölümü
```
Sol menüde ara:
📱 Brand Safety
  └─ Domains (Alan Adları)
```

### Adım 3: Domain Ekle
```
1. "Ekle" veya "+ Add" butonu
2. Domain gir: xn--hriyetsagliksonnhaberler-65c29b.site
3. Enter
```

### Adım 4: Doğrulama Yöntemi Seç

Facebook 3 yöntem sunar:

#### A. DNS TXT Kaydı (Önerilen)
```
Facebook şunu verir:
TXT kaydı: "facebook-domain-verification=xxxxxxxxxxxxx"

Yapılacak:
1. Domain sağlayıcına git (Cloudflare, GoDaddy, vs.)
2. DNS ayarlarına git
3. TXT kaydı ekle:
   - Type: TXT
   - Name: @ veya root
   - Value: facebook-domain-verification=xxxxxxxxxxxxx
   - TTL: 3600
4. Kaydet
5. Facebook'a dön → "Doğrula" butonuna bas
```

#### B. HTML Dosyası Yükleme
```
Facebook bir HTML dosyası verir:
Örnek: facebook-domain-verification-123456789.html

Yapılacak:
1. Dosyayı indir
2. Sunucuya yükle:
   /var/www/html/facebook-domain-verification-123456789.html
3. Test et:
   https://hüriyetsagliksonnhaberler.site/facebook-domain-verification-123456789.html
4. Açılıyorsa Facebook'ta "Doğrula" bas
```

#### C. Meta-Tag (HTML Head)
```
Facebook bir meta tag verir:
<meta name="facebook-domain-verification" content="xxxxxxxxxxxxx" />

Yapılacak:
1. HTML dosyasının <head> bölümüne ekle
2. Production'a deploy et
3. Facebook'ta "Doğrula" bas
```

---

## 📍 YÖNTEM 2: EVENTS MANAGER'DAN (HIZLI)

### Adım 1: Events Manager'da Uyarıyı Bul
```
Sen zaten gördün bu uyarıyı:
"Alan Adını İncele"
xn--hriyetsagliksonnhaberler-65c29b.site
```

### Adım 2: "Çözümü Gözden Geçir" Butonu
```
1. Sarı uyarı kutusunda → "Çözümü gözden geçir"
2. Facebook seni doğrulama sayfasına yönlendirir
3. Doğrulama yöntemini seç (DNS, HTML, Meta-tag)
4. Adımları takip et
```

---

## 🛠️ DETAYLI UYGULAMA

### DNS TXT KAYDI EKLEME (EN KOLAY)

#### Cloudflare Kullanıyorsan:
```
1. https://dash.cloudflare.com → Giriş yap
2. Domain seç: hüriyetsagliksonnhaberler.site
3. Sol menü → "DNS" → "Records"
4. "Add record" butonu
5. Şunları gir:
   Type: TXT
   Name: @
   Content: facebook-domain-verification=xxxxxxxxxxxxx
   TTL: Auto
6. "Save" → Tamamlandı!
7. Facebook'a dön → "Doğrula" bas
8. 1-5 dakika içinde doğrulama tamamlanır
```

#### GoDaddy / Diğer Sağlayıcılar:
```
1. Domain sağlayıcı paneline giriş yap
2. DNS Management / DNS Ayarları
3. TXT Record ekle
4. Name: @ veya boş bırak
5. Value: facebook-domain-verification=xxxxxxxxxxxxx
6. TTL: 3600
7. Kaydet
8. Facebook'ta "Doğrula" bas
```

---

## 🔧 HTML DOSYASI YÜKLEME (SUNUCU ERİŞİMİN VARSA)

### Facebook'tan Dosya İndir:
```
Facebook şunu verecek:
facebook-domain-verification-a1b2c3d4e5f6.html

İçeriği:
facebook-domain-verification=xxxxxxxxxxxxx
```

### Sunucuya Yükle:
```bash
# Dosyayı oluştur
sudo nano /var/www/html/facebook-domain-verification-a1b2c3d4e5f6.html

# İçine yaz (Facebook'tan kopyala):
facebook-domain-verification=xxxxxxxxxxxxx

# Kaydet (Ctrl+X, Y, Enter)

# Test et:
curl https://hüriyetsagliksonnhaberler.site/facebook-domain-verification-a1b2c3d4e5f6.html
```

### Facebook'ta Doğrula:
```
1. "Doğrula" butonuna bas
2. Facebook dosyayı kontrol eder
3. Bulursa: ✅ "Doğrulandı"
4. Bulamazsa: ❌ Dosya yolu doğru mu kontrol et
```

---

## 🔧 META-TAG EKLEME (HTML'E EKLEME)

### Facebook'tan Kodu Al:
```html
<meta name="facebook-domain-verification" content="a1b2c3d4e5f6g7h8i9j0" />
```

### HTML'e Ekle:
```bash
# Production dosyasını düzenle
sudo nano /var/www/html/index.html

# <head> bölümünün içine ekle (</head>'den önce):
<meta name="facebook-domain-verification" content="a1b2c3d4e5f6g7h8i9j0" />

# Kaydet (Ctrl+X, Y, Enter)
```

### Veya Backup'tan Deploy Et:
```bash
# Backup dosyasına ekle
nano /home/root/webapp/hurriyet-saglik-fixed-template.html

# <head> içine ekle:
<meta name="facebook-domain-verification" content="a1b2c3d4e5f6g7h8i9j0" />

# Production'a kopyala
sudo cp /home/root/webapp/hurriyet-saglik-fixed-template.html /var/www/html/index.html
```

### Facebook'ta Doğrula:
```
1. "Doğrula" butonuna bas
2. Facebook sayfayı tarar
3. Meta-tag'i bulursa: ✅ "Doğrulandı"
```

---

## 📊 DOĞRULAMA SONRASI

### Business Manager'da Göreceğin:
```
Brand Safety → Domains:
✅ xn--hriyetsagliksonnhaberler-65c29b.site (Doğrulandı)
```

### Events Manager'da:
```
Aktif Hatalar: 0
🟢 "Alan adı doğrulandı"
⚠️ Uyarı kalkar
```

### Pixel Ayarları:
```
Aggregated Event Measurement:
- 8 event önceliklendirilebilir
- iOS 14+ için optimize edildi
```

---

## 🚨 SORUN GİDERME

### Problem 1: "Domain bulunamadı"
```
Sebep: DNS henüz yayılmadı
Çözüm:
1. 5-10 dakika bekle
2. DNS propagation kontrol et: https://dnschecker.org
3. Tekrar dene
```

### Problem 2: "HTML dosyası bulunamadı"
```
Sebep: Dosya yolu yanlış veya izin sorunu
Çözüm:
1. Dosya yolunu kontrol et: /var/www/html/
2. İzinleri kontrol et: ls -la /var/www/html/facebook-*.html
3. chmod 644 ile izin ver
4. Test et: curl https://domain.com/facebook-verification-file.html
```

### Problem 3: "Meta-tag bulunamadı"
```
Sebep: Cache veya <head> bölümünde değil
Çözüm:
1. Sayfayı hard refresh (Ctrl+Shift+R)
2. View Source'da <head> içinde mi kontrol et
3. </head>'den önce olduğundan emin ol
4. Cache temizle ve tekrar dene
```

---

## ⏱️ DOĞRULAMA SÜRELERİ

```
DNS TXT Kaydı: 5-30 dakika (DNS propagation)
HTML Dosyası: 1-5 dakika (anında)
Meta-Tag: 1-5 dakika (anında)
```

---

## 💡 TAVSİYE

### En Kolay Yöntem: DNS TXT
```
✅ Sunucuya dokunmadan yapılır
✅ Kalıcıdır (dosya silinme riski yok)
✅ Birçok domain için tek yerden yönetilir
```

### En Hızlı Yöntem: HTML Dosyası
```
✅ Sunucu erişimin varsa anında
✅ Test edilebilir (curl ile)
✅ Dosya yoksa hata mesajı net
```

### En Pratik: Meta-Tag
```
✅ Zaten HTML düzenliyorsan
✅ Pixel kodunun yanına ekleyebilirsin
✅ View Source'da görünür ve doğrulanabilir
```

---

## 🎯 SENİN DURUMUN İÇİN

### Önerim:
```
1. "Çözümü gözden geçir" butonuna bas
2. DNS TXT yöntemini seç
3. Cloudflare/Domain panelinde TXT kaydı ekle
4. 5-10 dakika bekle
5. Facebook'ta doğrula
6. ✅ Tamamlandı!
```

### Alternatif (Hızlı):
```
1. Meta-tag al
2. HTML'e ekle (pixel kodunun altına)
3. Production'a deploy et
4. Facebook'ta doğrula
5. ✅ 2 dakika!
```

---

## ✅ SONUÇ

Domain verification:
- ✅ Zorunlu DEĞİL
- ✅ Önerilen (iOS 14+ için)
- ✅ 5-10 dakika sürer
- ✅ Pixel çalışmaya devam eder (yapmasanda)

**Tavsiye**: Kampanyayı başlat, domain verification'ı arka planda yap!

---

**Oluşturulma**: 2025-10-14  
**Durum**: Domain verification bekleniyor  
**Aciliyet**: Orta (kampanya öncelikli)
