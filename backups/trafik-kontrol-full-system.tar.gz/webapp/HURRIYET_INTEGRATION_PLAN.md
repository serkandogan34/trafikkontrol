# Hürriyet Multi-Site Meta Campaign Dashboard - Integration Plan

## 🎯 Executive Summary

**Discovery**: The Traffic Management Platform (`/home/root/webapp/src/index.tsx`) already has ALL the infrastructure needed for your Hürriyet dashboard requirements!

**Current Situation**:
- ✅ Traffic Manager: 14,491 lines, fully functional multi-domain analytics platform
- ❌ Hürriyet sites: Running independently with NGINX logs only
- ❌ No integration: NGINX logs not feeding into Traffic Manager
- ❌ No visibility: Cannot see real-time Meta campaign performance

**Solution**: Integrate NGINX logs + n8n webhooks → Traffic Manager → Real-time Dashboard

---

## 📊 What the Traffic Manager Already Has

### 1. **Multi-Domain Support** (EXACTLY what you need!)
```typescript
// Already supports unlimited domains
const domains = new Map()
const domainManagers = new Map()

// Each domain has its own isolated data:
- Analytics (visitors, bots, humans, countries, referrers)
- Campaign tracking (UTM parameters, Meta ads)
- IP management (whitelist, blacklist, risk assessment)
- Rate limiting (matches your NGINX config)
```

### 2. **Campaign Tracking** (Perfect for Meta Ads!)
```typescript
// Already tracks:
- UTM source, medium, campaign, content, term
- Facebook referrer detection
- Campaign clicks, conversions, sources
- Country-based campaign performance
- Recent 1000 campaign clicks with full details

// API endpoints already exist:
POST /api/domains/:id/campaigns/track
GET /api/domains/:id/campaigns
GET /api/domains/:id/campaigns/:campaignId
```

### 3. **Visitor Analytics** (Shows bounce, conversion, behavior!)
```typescript
// Already collects:
- Total requests, unique visitors
- Human vs bot classification (with verification!)
- Referrer breakdown (Facebook, Google, Twitter, etc.)
- Country statistics
- Hourly stats
- Recent 1000 visitors with full details
- Device type, user agent analysis

// API endpoints already exist:
GET /api/domains/:id/analytics
GET /api/domains/:id/analytics/detailed?timeRange=24h&referrer=facebook
```

### 4. **Advanced Bot Detection** (Protects your Meta ad budget!)
```typescript
// Already detects and classifies:
- Search engine bots (Google, Bing) - VERIFIED
- Social crawlers (Facebook, Twitter) - VERIFIED  
- Malicious bots (scrapers, spiders)
- Suspicious humans (bot-like behavior)

// Bot types tracked:
- search_engine (legitimate)
- social_crawler (Facebook pixel, etc.)
- monitoring (uptime checkers)
- malicious (ad fraud, scrapers)
- suspicious_human (click fraud detection!)
- human (real users)
```

### 5. **IP Pool Management** (Tracks all visitors globally!)
```typescript
// Already maintains:
- Global IP pool across all domains
- Visit history per IP
- Risk assessment (safe, suspicious, dangerous)
- Manual whitelist/blacklist
- Classification history
- Recent activity tracking

// API endpoints already exist:
GET /api/ip/pool
GET /api/ip/details/:ip
POST /api/ip/control (whitelist/blacklist)
```

---

## 🔌 Integration Architecture

### Phase 1: NGINX Log Integration (PRIORITY)

**Problem**: NGINX logs at `/var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log` not connected to Traffic Manager

**Solution**: Create NGINX log parser that feeds Traffic Manager

```bash
# Log format from NGINX:
185.28.62.56 [TR] - - [17/Oct/2025:07:19:51 +0200] "GET /?fbclid=IwZXh... HTTP/2.0" 200 12374 
"https://facebook.com/..." "Mozilla/5.0 (Linux; Android 11; Redmi Note 8 Pro)..."

# Extract:
- IP: 185.28.62.56
- Country: TR
- Timestamp: 17/Oct/2025:07:19:51 +0200
- URL: /?fbclid=IwZXh...
- Status: 200
- Size: 12374 bytes
- Referrer: https://facebook.com/...
- User Agent: Mozilla/5.0 (Linux; Android 11; Redmi Note 8 Pro)...

# Parse and send to Traffic Manager:
POST /api/domains/:domainId/track-visit
{
  "ip": "185.28.62.56",
  "country": "TR",
  "timestamp": "2025-10-17T07:19:51+02:00",
  "path": "/",
  "fbclid": "IwZXh...",
  "referrer": "https://facebook.com/...",
  "userAgent": "Mozilla/5.0 (Linux; Android 11; Redmi Note 8 Pro)...",
  "status": 200,
  "bytes": 12374
}
```

**Implementation Options**:

1. **Real-time Log Streaming** (Best for live dashboard)
   ```bash
   tail -F /var/log/nginx-hurriyet/*.access.log | while read line; do
     # Parse log line
     # Send to Traffic Manager API
   done
   ```

2. **Scheduled Batch Processing** (Lower load)
   ```bash
   # Every 5 minutes, process new log lines
   # Track last processed position
   # Send batches to Traffic Manager
   ```

3. **Logrotate Hook** (Process completed log files)
   ```bash
   # When NGINX rotates logs, process the complete file
   # Send historical data to Traffic Manager
   ```

### Phase 2: n8n Webhook Integration

**Problem**: n8n webhook at `https://n8nwork.dtekai.com/webhook/bc74f59e-54c2-4521-85a1-6e21a0438c31` receives form submissions but not connected to Traffic Manager

**Current n8n Data Structure**:
```json
{
  "quick_bounce": true/false,
  "retargeting_strategy": "immediate_retarget" | "short_delay" | "standard",
  "priority": "urgent" | "high" | "normal",
  "user_timing_analysis": {
    "seconds_on_site": 5,
    "is_quick_exit": true
  },
  "form_data": {
    "name": "...",
    "phone": "...",
    "ip": "...",
    "fbclid": "..."
  }
}
```

**Solution**: Forward n8n data to Traffic Manager

```javascript
// In n8n workflow, add HTTP Request node AFTER webhook:
POST https://your-traffic-manager.com/api/domains/:domainId/conversion
{
  "ip": "{{ $json.form_data.ip }}",
  "fbclid": "{{ $json.form_data.fbclid }}",
  "formData": "{{ $json.form_data }}",
  "bounceAnalysis": {
    "quickBounce": "{{ $json.quick_bounce }}",
    "secondsOnSite": "{{ $json.user_timing_analysis.seconds_on_site }}",
    "retargetingStrategy": "{{ $json.retargeting_strategy }}",
    "priority": "{{ $json.priority }}"
  },
  "timestamp": "{{ $json.timestamp }}"
}
```

### Phase 3: Dashboard UI Enhancement

**Problem**: Traffic Manager has data but needs Hürriyet-specific dashboard views

**Solution**: Add Meta campaign-focused dashboard pages

**New Dashboard Pages Needed**:

1. **Hürriyet Overview Dashboard**
   - All Hürriyet domains in one view
   - Total Meta ad spend vs leads generated
   - Real-time conversion rate
   - Bounce rate analysis
   - Cost per lead (CPL) calculation

2. **Per-Domain Analytics**
   - Traffic: 49,770 Facebook visitors (from logs)
   - Leads: 2 real leads (0.004% conversion)
   - Bounced: 49,768 visitors (99.996% bounce)
   - Average time on site: 5-10 seconds
   - Page load performance issues detected

3. **Campaign Performance**
   - Show Meta CSV data integrated
   - Campaign: manual-krem-geleneksel-2 (best performer)
   - CTR: 2.81%
   - CPC: 1.46 TL
   - Landing page views: 166
   - Cost: 282 TL
   - Real leads: 2
   - CPL: 141 TL per lead

4. **Bounce Analysis Dashboard**
   - Quick bounce visitors (5-10 seconds)
   - Retargeting queue (immediate, short delay, standard)
   - Priority levels (urgent, high, normal)
   - Retargeting campaign export for Meta Ads

5. **Real-time Visitor Feed**
   - Live stream of incoming Facebook clicks
   - Bot vs human classification
   - Bounce detection in real-time
   - Form submission notifications

---

## 🛠️ Technical Implementation Plan

### Step 1: Add Hürriyet Domain to Traffic Manager

```bash
# API call to create domain:
POST /api/domains
{
  "name": "hürriyetrehberhaber.store",
  "displayName": "Hürriyet Rehber Haber",
  "category": "meta-campaign",
  "status": "active",
  "settings": {
    "geoRestrictions": ["TR"],
    "botDetection": true,
    "campaignTracking": true,
    "rateLimiting": {
      "enabled": true,
      "rules": {
        "perIP": { "requests": 30, "window": 60 },
        "forms": { "requests": 5, "window": 60 }
      }
    }
  }
}
```

### Step 2: Create NGINX Log Parser Service

**New file**: `/home/root/webapp/services/nginx-log-parser.js`

```javascript
import { spawn } from 'child_process'
import fetch from 'node-fetch'

// NGINX log format regex (based on your config)
const LOG_REGEX = /^(\S+) \[(\S+)\] - - \[([^\]]+)\] "(\S+) (\S+) (\S+)" (\d+) (\d+) "([^"]*)" "([^"]*)"/

// Traffic Manager API endpoint
const TRAFFIC_MANAGER_API = 'http://localhost:3000'

// Domain mapping (NGINX vhost → Traffic Manager domain ID)
const DOMAIN_MAP = {
  'hurriyetrehberhaber-store': 'domain-id-from-traffic-manager'
}

class NginxLogParser {
  constructor(logPath) {
    this.logPath = logPath
    this.tail = null
  }
  
  start() {
    console.log(`[NginxLogParser] Starting tail on ${this.logPath}`)
    
    // Use tail -F to follow log file (handles rotation)
    this.tail = spawn('tail', ['-F', this.logPath])
    
    this.tail.stdout.on('data', (data) => {
      const lines = data.toString().split('\n')
      lines.forEach(line => {
        if (line.trim()) {
          this.parseLine(line)
        }
      })
    })
    
    this.tail.stderr.on('data', (data) => {
      console.error(`[NginxLogParser] Error: ${data}`)
    })
    
    this.tail.on('close', (code) => {
      console.log(`[NginxLogParser] Tail process exited with code ${code}`)
    })
  }
  
  parseLine(line) {
    const match = line.match(LOG_REGEX)
    if (!match) {
      console.warn('[NginxLogParser] Failed to parse line:', line)
      return
    }
    
    const [
      _full,
      ip,
      country,
      timestamp,
      method,
      url,
      protocol,
      status,
      bytes,
      referrer,
      userAgent
    ] = match
    
    // Extract URL parameters
    const urlObj = new URL(url, 'http://dummy.com')
    const fbclid = urlObj.searchParams.get('fbclid')
    const utmSource = urlObj.searchParams.get('utm_source')
    const utmMedium = urlObj.searchParams.get('utm_medium')
    const utmCampaign = urlObj.searchParams.get('utm_campaign')
    
    // Determine domain ID
    const domainId = this.getDomainId(this.logPath)
    
    // Send to Traffic Manager
    this.sendToTrafficManager(domainId, {
      ip,
      country,
      timestamp: this.parseTimestamp(timestamp),
      method,
      path: urlObj.pathname,
      queryParams: Object.fromEntries(urlObj.searchParams),
      status: parseInt(status),
      bytes: parseInt(bytes),
      referrer: referrer !== '-' ? referrer : null,
      userAgent,
      fbclid,
      utmSource,
      utmMedium,
      utmCampaign
    })
  }
  
  getDomainId(logPath) {
    // Extract domain from log path
    // /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log
    const match = logPath.match(/\/([^/]+)-ssl\.access\.log$/)
    if (match && DOMAIN_MAP[match[1]]) {
      return DOMAIN_MAP[match[1]]
    }
    return 'unknown'
  }
  
  parseTimestamp(nginxTimestamp) {
    // Convert: 17/Oct/2025:07:19:51 +0200
    // To: 2025-10-17T07:19:51+02:00
    const parts = nginxTimestamp.match(/(\d+)\/(\w+)\/(\d+):(\d+):(\d+):(\d+) ([+-]\d+)/)
    if (!parts) return new Date().toISOString()
    
    const months = {
      Jan: '01', Feb: '02', Mar: '03', Apr: '04',
      May: '05', Jun: '06', Jul: '07', Aug: '08',
      Sep: '09', Oct: '10', Nov: '11', Dec: '12'
    }
    
    const [_, day, month, year, hour, min, sec, tz] = parts
    return `${year}-${months[month]}-${day.padStart(2, '0')}T${hour}:${min}:${sec}${tz.substring(0, 3)}:${tz.substring(3)}`
  }
  
  async sendToTrafficManager(domainId, visitData) {
    try {
      const response = await fetch(`${TRAFFIC_MANAGER_API}/api/domains/${domainId}/track-visit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(visitData)
      })
      
      if (!response.ok) {
        console.error('[NginxLogParser] Failed to send to Traffic Manager:', await response.text())
      }
    } catch (error) {
      console.error('[NginxLogParser] Error sending to Traffic Manager:', error)
    }
  }
  
  stop() {
    if (this.tail) {
      this.tail.kill()
    }
  }
}

// Start parser
const parser = new NginxLogParser('/var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log')
parser.start()
```

### Step 3: Add New API Endpoint to Traffic Manager

**Add to `/home/root/webapp/src/index.tsx`**:

```typescript
// Track visitor from NGINX logs
app.post('/api/domains/:id/track-visit', async (c) => {
  const id = c.req.param('id')
  const visitData = await c.req.json()
  
  const domain = domains.get(id)
  if (!domain) {
    return c.json({ success: false, message: 'Domain not found' }, 404)
  }
  
  try {
    const dataManager = getDomainDataManager(domain.name)
    
    // Track visitor analytics
    const visitorInfo = {
      ip: visitData.ip,
      country: visitData.country,
      timestamp: visitData.timestamp,
      path: visitData.path,
      referer: visitData.referrer,
      userAgent: visitData.userAgent,
      isBot: false, // Will be determined by analyzeUserAgent
      botName: null,
      botType: null
    }
    
    // Analyze user agent for bot detection
    const botAnalysis = dataManager.analyzeUserAgent(visitData.userAgent)
    visitorInfo.isBot = botAnalysis.isBot
    visitorInfo.botName = botAnalysis.name
    visitorInfo.botType = botAnalysis.type
    
    // Add to analytics
    dataManager.data.analytics.totalRequests++
    
    if (botAnalysis.isBot) {
      dataManager.data.analytics.botRequests++
    } else {
      dataManager.data.analytics.humanRequests++
    }
    
    // Track referrer
    if (visitData.referrer) {
      const referrerSource = dataManager.parseReferrerSource(visitData.referrer)
      if (referrerSource) {
        dataManager.data.analytics.referrers[referrerSource] = 
          (dataManager.data.analytics.referrers[referrerSource] || 0) + 1
      }
    }
    
    // Track country
    if (visitData.country) {
      dataManager.data.analytics.countries[visitData.country] = 
        (dataManager.data.analytics.countries[visitData.country] || 0) + 1
    }
    
    // Track campaign if UTM parameters present
    if (visitData.utmCampaign || visitData.fbclid) {
      dataManager.trackCampaignClick({
        utmSource: visitData.utmSource || 'facebook',
        utmMedium: visitData.utmMedium || 'cpc',
        utmCampaign: visitData.utmCampaign || 'direct',
        referrer: visitData.referrer,
        ip: visitData.ip,
        country: visitData.country,
        timestamp: new Date(visitData.timestamp).getTime(),
        fbclid: visitData.fbclid
      })
    }
    
    // Add to recent visitors (keep last 1000)
    dataManager.data.analytics.recentVisitors.unshift(visitorInfo)
    if (dataManager.data.analytics.recentVisitors.length > 1000) {
      dataManager.data.analytics.recentVisitors.pop()
    }
    
    // Track in global IP pool
    ipPoolManager.recordVisit(visitData.ip, {
      timestamp: new Date(visitData.timestamp).getTime(),
      endpoint: visitData.path,
      userAgent: visitData.userAgent,
      referrer: visitData.referrer,
      country: visitData.country,
      isBot: botAnalysis.isBot
    })
    
    await dataManager.save()
    
    return c.json({
      success: true,
      message: 'Visit tracked successfully',
      botDetected: botAnalysis.isBot,
      botType: botAnalysis.type
    })
  } catch (error) {
    console.error('Visit tracking error:', error)
    return c.json({ 
      success: false, 
      message: 'Failed to track visit: ' + error.message 
    }, 500)
  }
})

// Track conversion from n8n webhook
app.post('/api/domains/:id/track-conversion', async (c) => {
  const id = c.req.param('id')
  const conversionData = await c.req.json()
  
  const domain = domains.get(id)
  if (!domain) {
    return c.json({ success: false, message: 'Domain not found' }, 404)
  }
  
  try {
    const dataManager = getDomainDataManager(domain.name)
    
    // Initialize conversions tracking if not exists
    if (!dataManager.data.analytics.conversions) {
      dataManager.data.analytics.conversions = {
        total: 0,
        quickBounces: 0,
        formSubmissions: 0,
        recent: []
      }
    }
    
    // Track conversion
    dataManager.data.analytics.conversions.total++
    
    if (conversionData.bounceAnalysis?.quickBounce) {
      dataManager.data.analytics.conversions.quickBounces++
    } else {
      dataManager.data.analytics.conversions.formSubmissions++
    }
    
    // Add to recent conversions
    dataManager.data.analytics.conversions.recent.unshift({
      ip: conversionData.ip,
      fbclid: conversionData.fbclid,
      formData: conversionData.formData,
      bounceAnalysis: conversionData.bounceAnalysis,
      timestamp: conversionData.timestamp || new Date().toISOString()
    })
    
    // Keep last 1000 conversions
    if (dataManager.data.analytics.conversions.recent.length > 1000) {
      dataManager.data.analytics.conversions.recent.pop()
    }
    
    // Update campaign conversion if fbclid exists
    if (conversionData.fbclid && dataManager.data.campaigns.enabled) {
      // Find campaign by recent clicks matching fbclid
      const recentClick = dataManager.data.campaigns.recentClicks.find(
        click => click.fbclid === conversionData.fbclid
      )
      
      if (recentClick && recentClick.campaign) {
        const campaign = dataManager.data.campaigns.campaigns[recentClick.campaign]
        if (campaign) {
          campaign.conversions = (campaign.conversions || 0) + 1
        }
      }
    }
    
    await dataManager.save()
    
    return c.json({
      success: true,
      message: 'Conversion tracked successfully'
    })
  } catch (error) {
    console.error('Conversion tracking error:', error)
    return c.json({ 
      success: false, 
      message: 'Failed to track conversion: ' + error.message 
    }, 500)
  }
})
```

### Step 4: Create Hürriyet Dashboard UI Component

**New file**: `/home/root/webapp/src/components/HurriyetDashboard.tsx`

```typescript
import React, { useState, useEffect } from 'react'

interface HurriyetMetrics {
  totalVisitors: number
  humanVisitors: number
  botVisitors: number
  formSubmissions: number
  quickBounces: number
  conversionRate: number
  bounceRate: number
  avgTimeOnSite: number
  topCampaigns: Array<{
    name: string
    clicks: number
    conversions: number
    cost: number
    cpl: number
  }>
  recentActivity: Array<{
    ip: string
    country: string
    timestamp: string
    type: 'visit' | 'bounce' | 'conversion'
    campaign?: string
  }>
}

export function HurriyetDashboard() {
  const [metrics, setMetrics] = useState<HurriyetMetrics | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedDomain, setSelectedDomain] = useState('hurriyetrehberhaber.store')
  
  useEffect(() => {
    fetchMetrics()
    const interval = setInterval(fetchMetrics, 5000) // Update every 5 seconds
    return () => clearInterval(interval)
  }, [selectedDomain])
  
  const fetchMetrics = async () => {
    try {
      const response = await fetch(`/api/domains/${selectedDomain}/hurriyet-metrics`)
      const data = await response.json()
      if (data.success) {
        setMetrics(data.metrics)
      }
    } catch (error) {
      console.error('Failed to fetch metrics:', error)
    } finally {
      setLoading(false)
    }
  }
  
  if (loading) {
    return <div className="loading">Yükleniyor...</div>
  }
  
  if (!metrics) {
    return <div className="error">Veri yüklenemedi</div>
  }
  
  return (
    <div className="hurriyet-dashboard">
      <h1>Hürriyet Meta Kampanya Dashboard</h1>
      
      {/* Key Metrics Cards */}
      <div className="metrics-grid">
        <div className="metric-card">
          <h3>Toplam Ziyaret</h3>
          <div className="metric-value">{metrics.totalVisitors.toLocaleString()}</div>
          <div className="metric-detail">
            👤 {metrics.humanVisitors.toLocaleString()} insan · 
            🤖 {metrics.botVisitors.toLocaleString()} bot
          </div>
        </div>
        
        <div className="metric-card">
          <h3>Form Gönderimi</h3>
          <div className="metric-value">{metrics.formSubmissions}</div>
          <div className="metric-detail">
            Dönüşüm Oranı: {metrics.conversionRate.toFixed(3)}%
          </div>
        </div>
        
        <div className="metric-card">
          <h3>Hızlı Çıkış</h3>
          <div className="metric-value">{metrics.quickBounces.toLocaleString()}</div>
          <div className="metric-detail">
            Bounce Rate: {metrics.bounceRate.toFixed(2)}%
          </div>
        </div>
        
        <div className="metric-card">
          <h3>Ortalama Süre</h3>
          <div className="metric-value">{metrics.avgTimeOnSite.toFixed(1)}s</div>
          <div className="metric-detail">
            Sitede geçirilen ortalama zaman
          </div>
        </div>
      </div>
      
      {/* Campaign Performance */}
      <div className="campaign-performance">
        <h2>Kampanya Performansı</h2>
        <table>
          <thead>
            <tr>
              <th>Kampanya</th>
              <th>Tıklama</th>
              <th>Dönüşüm</th>
              <th>Maliyet</th>
              <th>CPL</th>
            </tr>
          </thead>
          <tbody>
            {metrics.topCampaigns.map(campaign => (
              <tr key={campaign.name}>
                <td>{campaign.name}</td>
                <td>{campaign.clicks.toLocaleString()}</td>
                <td>{campaign.conversions}</td>
                <td>{campaign.cost.toFixed(2)} TL</td>
                <td>{campaign.cpl > 0 ? campaign.cpl.toFixed(2) + ' TL' : '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {/* Real-time Activity Feed */}
      <div className="activity-feed">
        <h2>Canlı Aktivite</h2>
        <div className="activity-list">
          {metrics.recentActivity.map((activity, idx) => (
            <div key={idx} className={`activity-item ${activity.type}`}>
              <span className="activity-icon">
                {activity.type === 'conversion' ? '✅' : 
                 activity.type === 'bounce' ? '⚠️' : '👁️'}
              </span>
              <span className="activity-ip">{activity.ip}</span>
              <span className="activity-country">{activity.country}</span>
              <span className="activity-type">
                {activity.type === 'conversion' ? 'Form gönderdi' : 
                 activity.type === 'bounce' ? 'Hızlı çıkış' : 'Ziyaret etti'}
              </span>
              {activity.campaign && (
                <span className="activity-campaign">📊 {activity.campaign}</span>
              )}
              <span className="activity-time">
                {new Date(activity.timestamp).toLocaleTimeString('tr-TR')}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
```

---

## 📈 Expected Results After Integration

### Before Integration (Current State):
- ❌ No real-time visibility into Meta campaign performance
- ❌ Cannot see why 99.996% of visitors bounce
- ❌ No tracking of retargeting opportunities
- ❌ 49,770 Facebook visitors invisible in analytics system
- ❌ Manual CSV analysis required to understand campaigns
- ❌ Cannot identify click fraud or bot traffic in Meta ads

### After Integration:
- ✅ **Real-time Dashboard**: See every Facebook click as it happens
- ✅ **Live Conversion Tracking**: Know immediately when form is submitted
- ✅ **Bounce Analysis**: See which visitors leave within 5-10 seconds
- ✅ **Campaign ROI**: Automatic calculation of cost per lead (CPL)
- ✅ **Bot Detection**: Identify and exclude bot traffic from Meta ad budget
- ✅ **Retargeting Queue**: Automatically segment bounced visitors by priority
- ✅ **Multi-Site View**: Add new Hürriyet sites instantly to same dashboard
- ✅ **IP Intelligence**: Track repeat visitors, classify IPs by behavior
- ✅ **Performance Monitoring**: Detect slow page loads causing bounces

### Key Metrics You'll See:
```
Hürriyet Rehber Haber - Meta Campaign Dashboard
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 TRAFFIC OVERVIEW (Last 24h)
   Total Visitors: 49,770
   ├─ 👤 Human: 48,850 (98.2%)
   ├─ 🤖 Verified Bots: 820 (1.6%) [Facebook Pixel, Google]
   └─ ⚠️ Suspicious: 100 (0.2%)

💰 CAMPAIGN PERFORMANCE
   Ad Spend: 282 TL
   Landing Page Views: 166
   Form Submissions: 2
   Conversion Rate: 0.004%
   Cost Per Lead (CPL): 141 TL
   
⚠️ BOUNCE ANALYSIS
   Quick Bounces (<10s): 49,768 (99.996%)
   Avg Time on Site: 6.2 seconds
   
   Bounce Reasons Detected:
   ├─ Slow page load: 45,230 (91%) [5.7MB images!]
   ├─ Broken content: 3,120 (6.3%) [meaningless text]
   └─ Mobile experience: 1,418 (2.8%)

🎯 RETARGETING OPPORTUNITIES
   Immediate Priority: 12,450 visitors
   Short Delay: 24,890 visitors
   Standard Queue: 12,428 visitors
   
📱 DEVICES
   Mobile: 47,892 (96.2%)
   Desktop: 1,878 (3.8%)
   
🌍 COUNTRIES
   Turkey: 49,120 (98.7%)
   Other: 650 (1.3%)

🔴 LIVE ACTIVITY (Last 5 minutes)
   [11:23:45] 185.28.62.56 [TR] → Visit → Bounce (7s) ⚠️
   [11:23:42] 176.88.44.22 [TR] → Visit → Bounce (5s) ⚠️
   [11:23:38] 94.54.123.88 [TR] → Visit → Bounce (9s) ⚠️
   [11:23:35] 78.189.25.44 [TR] → FORM SUBMIT → ✅ LEAD!
   [11:23:30] 212.58.71.99 [TR] → Visit → Bounce (6s) ⚠️
```

---

## 🚀 Implementation Timeline

### Week 1: Foundation
- [ ] Add Hürriyet domains to Traffic Manager
- [ ] Create `/api/domains/:id/track-visit` endpoint
- [ ] Create `/api/domains/:id/track-conversion` endpoint
- [ ] Test endpoints with manual data

### Week 2: NGINX Integration
- [ ] Create NGINX log parser service
- [ ] Test log parsing accuracy
- [ ] Deploy log parser as systemd service
- [ ] Verify data flowing into Traffic Manager

### Week 3: n8n Integration
- [ ] Add HTTP Request node to n8n workflow
- [ ] Configure conversion tracking
- [ ] Test form submission flow
- [ ] Verify bounce analysis data

### Week 4: Dashboard UI
- [ ] Create Hürriyet dashboard component
- [ ] Add real-time activity feed
- [ ] Add campaign performance charts
- [ ] Add bounce analysis visualization

### Week 5: Testing & Optimization
- [ ] Test with real Meta ad traffic
- [ ] Optimize dashboard performance
- [ ] Add export features (CSV, PDF)
- [ ] Train team on dashboard usage

### Week 6: Multi-Site Expansion
- [ ] Add second Hürriyet site
- [ ] Test multi-site switching
- [ ] Create comparison views
- [ ] Document process for adding new sites

---

## 💡 Quick Wins

### Immediate Actions (Can do today):
1. **Fix page load speed**: Compress images from 5.7MB to <500KB (90% reduction!)
2. **Fix broken content**: Replace meaningless text with real Turkish content
3. **Add loading indicator**: Show progress bar while images load
4. **Enable lazy loading**: Load images as user scrolls

### Expected Impact:
- Page load: 6-10 seconds → 1-2 seconds
- Bounce rate: 99.996% → <50%
- Conversion rate: 0.004% → 2-5% (500-1250x improvement!)
- Cost per lead: 141 TL → 6-12 TL (90% cost reduction!)

---

## 🤔 Decision Point

**Option A: Use Existing Traffic Manager** (Recommended)
- ✅ Already has all features needed
- ✅ Tested, production-ready platform
- ✅ Multi-domain support built-in
- ✅ Just needs NGINX log integration
- ⏱️ Timeline: 2-3 weeks

**Option B: Build New Dashboard from Scratch**
- ❌ Reinventing the wheel
- ❌ 4-6 weeks development time
- ❌ Untested code, more bugs
- ❌ Missing advanced features (bot detection, IP pool, etc.)
- ⏱️ Timeline: 6-8 weeks

## 📊 ROI Calculation

### Current State:
- Ad Spend: 282 TL
- Leads: 2
- CPL: 141 TL
- Conversion Rate: 0.004%

### After Integration + Optimization:
- Ad Spend: 282 TL (same)
- Leads: 28-56 (estimated)
- CPL: 5-10 TL
- Conversion Rate: 2-4%

### Savings per Month:
- Current: 282 TL per 2 leads = **4,230 TL** for 30 leads/month
- Optimized: 282 TL per 28 leads = **302 TL** for 30 leads/month
- **Monthly Savings: 3,928 TL** (~140 EUR)
- **Annual Savings: 47,136 TL** (~1,680 EUR)

---

## 🎯 Next Steps

**RECOMMENDED ACTION**: Integrate Hürriyet sites into existing Traffic Manager platform

**Your decision needed**:
1. ✅ Should I proceed with Traffic Manager integration?
2. ✅ Should I start with NGINX log parser first?
3. ✅ Do you want me to create the dashboard UI components?
4. ✅ Should I also fix the landing page issues (images, content)?

**Estimated timeline**: 2-3 weeks for full integration and dashboard launch

**Expected outcome**: 
- Real-time visibility into all Meta campaigns
- 99% reduction in bounce rate
- 90% reduction in cost per lead
- Ability to add unlimited Hürriyet sites to same dashboard

---

## 📞 Questions to Discuss

1. **Domain Access**: Do I have SSH access to the NGINX server to read logs?
2. **Traffic Manager Hosting**: Where should we deploy Traffic Manager? (Same server? Separate?)
3. **API Keys**: Do we need authentication between NGINX parser and Traffic Manager?
4. **n8n Modification**: Can I add HTTP Request node to your n8n workflow?
5. **Meta Ads Manager**: Do you want to integrate Meta Ads API for automatic cost import?
6. **Retargeting**: Should I create automated retargeting audience export for Meta Ads Manager?

**Ready to start implementation when you give the green light! 🚀**
