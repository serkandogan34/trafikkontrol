# 🚨 ACİL: META VERİ KAYNAĞI KATEGORİSİ DÜZELTMESİ

**Tarih**: 2025-10-17  
**Durum**: 🔴 KRİTİK - ACİL MÜDAHALE GEREKLİ  
**Sorun**: Yanlış kategori seçimi tüm lead'leri engelliyor

---

## ❌ **SORUN: NE OLDU?**

### **Tespit Edilen:**

Facebook Business Manager'da **veri kaynağı kategorisi** yanlış seçilmiş:

```
Domain: xn--hriyetsagliksonnhaberler-vsc.site (Punycode)
        hüriyetsagliksonnhaberler.site (Unicode)

❌ Seçilen Kategori: "Sağlık ve zindelik - diğer"
✅ Doğru Kategori:   "Health & wellness conditions" VEYA
                     "Health & wellness - General wellness"
```

### **Sonuçlar:**

1. ❌ **Lead'ler Engellendi**
   - Meta tüm form verilerini hassas sağlık verisi olarak görmüş
   - Otomatik veri paylaşım engeli koymuş
   - Lead'ler kampanyaya iletilmemiş

2. 💸 **Para Harcaması Devam Etti**
   - Kampanya çalışmaya devam etmiş
   - Tıklamalar gerçekleşmiş
   - Fakat lead'ler CRM'e gitmemiş

3. 📊 **Veri Kaybı**
   - Kaç lead kaybedildi bilinmiyor
   - Conversion tracking eksik
   - ROI ölçülememiş

---

## 🎯 **ÇÖZÜM: ADIM ADIM DÜZELTİLMESİ**

### **ADIM 1: Doğru Kategoriyi Seç**

1. **Facebook Business Manager'a git**
   - https://business.facebook.com/

2. **Events Manager'ı aç**
   - Sol menüden "Events Manager" seç

3. **Veri Kaynağını bul**
   - Pixel: `1536997377317312`
   - Domain: `xn--hriyetsagliksonnhaberler-vsc.site`

4. **Settings (Ayarlar) → Data Source (Veri Kaynağı)**
   - "Veri kaynağını kategorilerini yönet" tıkla

5. **Kategoriyi değiştir:**

**SEÇENEK A (Önerilen):**
```
Kategori: Health & wellness - General wellness
Alt Kategori: (Yok)
```
**Açıklama:** Genel sağlık ürünleri, hassas veri yok

**SEÇENEK B:**
```
Kategori: E-commerce
Alt Kategori: Health & Beauty
```
**Açıklama:** E-ticaret olarak kategorize et

**SEÇENEK C (Dikkatli kullan):**
```
Kategori: Health & wellness conditions
Alt Kategori: (İlgili hastalık kategorisi)
```
⚠️ **Uyarı:** Bu seçenek veri kısıtlamalarına neden olabilir

6. **Kaydet ve Onayla**
   - "Save" tıkla
   - Değişikliklerin uygulanmasını bekle (5-10 dakika)

---

### **ADIM 2: Domain Verification Kontrol Et**

1. **Business Settings → Brand Safety → Domains**
   - `hüriyetsagliksonnhaberler.site` doğrulanmış mı kontrol et
   - `xn--hriyetsagliksonnhaberler-vsc.site` (Punycode) da ekle

2. **Doğrulama Meta Tag'i:**
```html
<meta name="facebook-domain-verification" content="miulwpw89v22n8ikewuj8m365r6l09" />
```

3. **Her iki domain için de verify et:**
   - Unicode: `hüriyetsagliksonnhaberler.site`
   - Punycode: `xn--hriyetsagliksonnhaberler-vsc.site`

---

### **ADIM 3: Veri Paylaşım Ayarlarını Kontrol Et**

1. **Events Manager → Pixel Settings**

2. **Data Collection & Use (Veri Toplama ve Kullanım)**
   - "Automatic Advanced Matching" → ✅ Açık olsun
   - "Customer Information Parameters" → ✅ Açık olsun

3. **Event Parameters**
   - `em` (email) → ✅ İzinli
   - `ph` (phone) → ✅ İzinli
   - `fn` (first name) → ✅ İzinli

4. **Kısıtlamaları Kaldır:**
   - "Sensitive Data Restrictions" → ❌ Kapalı olmalı
   - "Health Data Restrictions" → ❌ Kapalı olmalı

---

### **ADIM 4: Pixel Event'lerini Test Et**

1. **Test Events Code kullan:**
```javascript
// Browser console'da test
fbq('trackCustom', 'TestLead', {
    content_name: 'Test Form',
    value: 1,
    currency: 'TRY'
});
```

2. **Events Manager → Test Events**
   - Test event görünüyor mu?
   - "Lead" event'i kaydediliyor mu?
   - Veri parametreleri geçiyor mu?

3. **Gerçek Form Test:**
   - Formdan test lead gönder
   - Events Manager'da görünüyor mu?
   - CRM/Webhook'a ulaşıyor mu?

---

### **ADIM 5: Kampanyayı Gözden Geçir**

1. **Ads Manager → Campaigns**
   - Kampanya durumu: Aktif mi?
   - Lead sayısı: Artıyor mu?
   - CPL (Cost Per Lead): Normal mi?

2. **Eğer lead gelmiyorsa:**
   - Kampanyayı duraklat
   - Kategori değişikliğinin etkili olmasını bekle (30-60 dakika)
   - Tekrar başlat

---

## 🔍 **NEDEN BU SORUN OLUŞTU?**

### **Meta'nın Hassas Veri Politikası**

Meta, sağlık verilerini korumak için sıkı kurallar koymuş:

```
Hassas Sağlık Kategorileri:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
❌ "Sağlık ve zindelik - diğer"
   → Meta tüm verileri hassas kabul eder
   → Otomatik kısıtlama uygular
   
❌ "Health conditions" (Hastalık durumları)
   → Kalp hastalığı, diyabet, kanser vb.
   → Çok sıkı veri kısıtlamaları
   
✅ "General wellness" (Genel sağlık)
   → Vitamin, takviye, fitness
   → Normal veri paylaşımı
   
✅ "E-commerce → Health & Beauty"
   → Sağlık ürünleri e-ticaret
   → Kısıtlama yok
```

### **Ne Zaman Kısıtlama Gelir?**

```
1. Yanlış kategori seçilirse → Otomatik engel
2. Hassas anahtar kelimeler → Manuel inceleme
3. Politika ihlali şüphesi → Kampanya reddedilir
4. Kullanıcı şikayeti → Hesap incelemesi
```

---

## 📊 **ETKİ ANALİZİ**

### **Senaryo: 7 Günlük Kampanya**

```
Kampanya Bütçesi: 1,000 TRY
Harcanan: 850 TRY
Tıklama: 340
Beklenen Lead: ~45-50
Gerçek Lead: 0 ❌

Kayıp:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
💸 Para Kaybı: 850 TRY
📊 Veri Kaybı: ~45-50 potansiyel lead
⏱️ Zaman Kaybı: 7 gün
📉 ROI: -100%
```

### **Düzeltme Sonrası Beklenti**

```
Kategori düzeltilince:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✅ Lead'ler akacak
✅ Conversion tracking çalışacak
✅ CRM'e veri gelecek
✅ ROI ölçülebilecek

Beklenen iyileşme: 30-60 dakika
Tam stabilizasyon: 24 saat
```

---

## 🎯 **DOĞRU KATEGORİ SEÇİMİ REHBERİ**

### **Ürün Tiplerine Göre Kategori**

| Ürün | Doğru Kategori | Neden? |
|------|---------------|---------|
| Vitamin, takviye | General wellness | Hassas veri yok |
| Fitness ürünleri | General wellness | Genel sağlık |
| Kozmetik | E-commerce → Health & Beauty | E-ticaret |
| Tıbbi cihaz | Medical devices | Özel kategori |
| İlaç (reçetesiz) | General wellness | Reçetesiz genel |
| Terapi hizmeti | Health conditions | Hassas sağlık |

### **Sizin Durumunuz:**

```
Ürün: Sağlık ürünleri (genel)
İdeal Kategori: "General wellness"
Alternatif: "E-commerce → Health & Beauty"
KESİNLİKLE DEĞİL: "Sağlık ve zindelik - diğer"
```

---

## 🔧 **ACİL KONTROL LİSTESİ**

### **Hemen Yapılacaklar (0-30 dakika)**

- [ ] 1. Facebook Business Manager'a giriş yap
- [ ] 2. Events Manager → Veri Kaynağı Ayarları
- [ ] 3. Kategoriyi "General wellness" olarak değiştir
- [ ] 4. Kaydet ve 10 dakika bekle
- [ ] 5. Test event gönder (browser console)
- [ ] 6. Events Manager'da test event'i gör
- [ ] 7. Gerçek form test et
- [ ] 8. Webhook'a lead ulaşıyor mu kontrol et

### **1 Saat İçinde Yapılacaklar**

- [ ] 9. Domain verification kontrol et (her iki domain)
- [ ] 10. Pixel ayarlarını gözden geçir
- [ ] 11. Veri paylaşım kısıtlamalarını kaldır
- [ ] 12. Kampanya performansını izle
- [ ] 13. İlk gerçek lead'i bekle

### **24 Saat İçinde Yapılacaklar**

- [ ] 14. Lead flow stabil mi kontrol et
- [ ] 15. Conversion rate normal mi?
- [ ] 16. CPL (Cost Per Lead) mantıklı mı?
- [ ] 17. CRM'e veri düzgün akıyor mu?
- [ ] 18. Meta Analytics'te lead görünüyor mu?

---

## 🚨 **EĞER HALA LEAD GELMİYORSA**

### **Sorun Giderme Adımları**

#### **1. Pixel Çalışıyor mu?**
```bash
# Browser console'da test
fbq('track', 'Lead', {
    content_name: 'Test',
    value: 1,
    currency: 'TRY'
});

# Network tab'da kontrol et:
# facebook.com/tr?id=1536997377317312&ev=Lead
```

#### **2. Webhook Çalışıyor mu?**
```bash
# Webhook test
curl -X POST https://n8nwork.dtekai.com/webhook/bc74f59e-54c2-4521-85a1-6e21a0438c31 \
  -H "Content-Type: application/json" \
  -d '{
    "customerName": "Test User",
    "phoneNumber": "5551234567",
    "timestamp": "2025-10-17T05:00:00Z",
    "source": "manual-test"
  }'
```

#### **3. NGINX Blokluyor mu?**
```bash
# Log kontrol
sudo tail -50 /var/log/nginx-hurriyet/hurriyet-health-ssl.access.log | grep "submit-order"

# Form submit istekleri görünüyor mu?
# 200 OK mu yoksa 403/404 mü?
```

#### **4. Facebook Event Debug**
- https://developers.facebook.com/tools/debug/
- Pixel ID gir: `1536997377317312`
- Son event'leri incele

---

## 📞 **DESTEK GEREKİRSE**

### **Facebook Destek**

1. **Business Help Center**
   - https://business.facebook.com/help/
   - "Events Manager" → "Data source categories"

2. **Live Chat** (Varsa)
   - Business Manager → Help (?)
   - "Chat with support"

3. **Telefon Desteği**
   - Türkiye: +90 850 xxx xxxx (Business hesaplar için)

### **Sorulacak Sorular**

```
"Veri kaynağı kategorisini 'Sağlık ve zindelik - diğer' 
olarak seçmiştim ve lead'lerim gelmiyor. 'General wellness' 
olarak değiştirdim, ne kadar sürede düzelir?"

"Domain verification'ım var, pixel çalışıyor ama form 
lead'leri Events Manager'a düşmüyor. Hassas veri 
kısıtlaması olabilir mi?"
```

---

## 💡 **GELECEKTEKİ HATALARDAN KAÇINMA**

### **Kategori Seçerken Dikkat Et**

1. ✅ **General wellness** → Genel sağlık ürünleri için güvenli
2. ✅ **E-commerce** → E-ticaret kategorisi her zaman güvenli
3. ⚠️ **Health conditions** → Sadece gerçekten hastalık tedavisi varsa
4. ❌ **"Diğer" seçenekleri** → Asla "diğer" seçme

### **Test Süreci**

```
1. Kategori seç
2. 24 saat test kampanya çalıştır (düşük bütçe)
3. Lead geliyor mu kontrol et
4. Geliyorsa → Ana kampanyayı başlat
5. Gelmiyorsa → Kategoriyi değiştir
```

### **Monitoring**

```
Günlük kontrol et:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Events Manager → Lead event sayısı
• Webhook → Gelen lead sayısı
• CRM → Kaydedilen lead sayısı

Eşleşmiyorsa → Sorun var!
```

---

## 📊 **ÖZET: HIZLI REHBER**

```
┌─────────────────────────────────────────────────────────┐
│  🚨 ACİL DÜZELTME ADIMLARI                              │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  1️⃣  Facebook Business Manager → Events Manager        │
│  2️⃣  Veri Kaynağı Ayarları → Kategori                  │
│  3️⃣  "Sağlık ve zindelik - diğer" → KALDIR ❌          │
│  4️⃣  "General wellness" SEÇĞ✅                         │
│  5️⃣  Kaydet ve 10 dakika bekle                         │
│  6️⃣  Test event gönder                                 │
│  7️⃣  Gerçek form test et                               │
│  8️⃣  Lead'lerin gelmesini gözle                        │
│                                                         │
│  Beklenen Süre: 30-60 dakika                           │
│  Tam Stabilizasyon: 24 saat                            │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

**Doküman Versiyonu**: 1.0  
**Tarih**: 2025-10-17  
**Aciliyet**: 🔴 KRİTİK  
**Tahmini Çözüm Süresi**: 30-60 dakika  
**Kayıp Lead Tahmini**: Kampanya süresine bağlı

---

**ÖNEMLİ:** Bu düzeltmeyi HEMEN yapın! Her geçen dakika potansiyel lead kaybı demek.
