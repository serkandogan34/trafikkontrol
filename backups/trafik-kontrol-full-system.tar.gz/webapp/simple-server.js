import { Hono } from 'hono'
import { serve } from '@hono/node-server'
import { serveStatic } from '@hono/node-server/serve-static'

const app = new Hono()

// Enable CORS
app.use('/api/*', async (c, next) => {
  c.header('Access-Control-Allow-Origin', '*')
  c.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  c.header('Access-Control-Allow-Headers', 'Authorization, Content-Type')
  
  if (c.req.method === 'OPTIONS') {
    return c.text('', 200)
  }
  
  await next()
})

// Serve static files
app.use('/static/*', serveStatic({ 
  root: './public',
  rewriteRequestPath: (path) => path.replace(/^\/static/, '')
}))

// In-memory storage
const domains = new Map()
const dnsRecords = new Map()
let domainIdCounter = Date.now()

// Authentication middleware (simplified)
const requireAuth = async (c, next) => {
  const authHeader = c.req.header('Authorization')
  if (!authHeader || !authHeader.includes('Bearer')) {
    return c.json({ success: false, message: 'Authentication required' }, 401)
  }
  await next()
}

// Health endpoints
app.get('/api/health', (c) => {
  return c.json({
    success: true,
    status: 'healthy',
    service: 'Traffic Management Platform Node.js',
    version: '3.0',
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()),
    environment: 'development'
  })
})

app.get('/api/auth/demo', (c) => {
  return c.json({
    success: true,
    message: 'Demo authentication successful',
    user: {
      id: 'demo-user',
      email: 'demo@traffic-platform.com',
      role: 'admin'
    },
    token: 'demo-token-12345',
    timestamp: new Date().toISOString()
  })
})

// Domain management
app.get('/api/domains', requireAuth, (c) => {
  const domainList = Array.from(domains.values()).map(domain => ({
    ...domain,
    totalRequests: domain.totalRequests || 0,
    humanRequests: domain.humanRequests || 0,
    botRequests: domain.botRequests || 0,
    blocked: domain.blocked || 0
  }))
  
  return c.json({
    success: true,
    domains: domainList,
    total: domainList.length
  })
})

app.post('/api/domains', requireAuth, async (c) => {
  try {
    const { name, type } = await c.req.json()
    
    if (!name) {
      return c.json({ success: false, message: 'Domain name is required' }, 400)
    }
    
    // Check if domain already exists
    const existingDomain = Array.from(domains.values()).find(d => d.name === name)
    if (existingDomain) {
      return c.json({ success: false, message: 'Domain already exists' }, 400)
    }
    
    const id = (domainIdCounter++).toString()
    const domain = {
      id,
      name,
      type: type || 'production',
      status: 'active',
      connected: true,
      traffic: 0,
      blocked: 0,
      totalRequests: 0,
      humanRequests: 0,
      botRequests: 0,
      cleanServed: 0,
      grayServed: 0,
      aggressiveServed: 0,
      lastTrafficUpdate: new Date().toISOString(),
      addedAt: new Date().toISOString(),
      lastChecked: new Date().toISOString()
    }
    
    domains.set(id, domain)
    
    return c.json({
      success: true,
      domain: domain
    })
  } catch (error) {
    return c.json({
      success: false,
      message: 'Error adding domain: ' + error.message
    }, 500)
  }
})

app.delete('/api/domains/:id', requireAuth, (c) => {
  const id = c.req.param('id')
  
  if (!domains.has(id)) {
    return c.json({ success: false, message: 'Domain not found' }, 404)
  }
  
  domains.delete(id)
  
  return c.json({
    success: true,
    message: 'Domain deleted successfully'
  })
})

// Proxy management for domains
app.post('/api/domains/:id/proxy/generate', requireAuth, async (c) => {
  const id = c.req.param('id')
  const config = await c.req.json()
  
  const domain = domains.get(id)
  if (!domain) {
    return c.json({ success: false, message: 'Domain not found' }, 404)
  }
  
  const {
    backendIP = '46.202.158.197',
    proxyPort = 3000,
    enableSSL = false
  } = config
  
  const nginxConfig = `# Auto-generated Nginx configuration for ${domain.name}
# Generated at: ${new Date().toISOString()}

server {
    listen 80;
    server_name ${domain.name};
    
    # Traffic Management Platform Proxy
    location / {
        proxy_pass http://127.0.0.1:${proxyPort}/proxy-handler;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Original-Domain "${domain.name}";
        proxy_set_header X-Original-Backend "${backendIP}";
    }
}
`
  
  return c.json({
    success: true,
    message: 'Nginx configuration generated successfully',
    config: nginxConfig,
    domain: domain.name
  })
})

// Main route
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Traffic Management Platform V3</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-900 text-white">
        <div id="app">
            <div class="min-h-screen">
                <!-- Navigation -->
                <nav class="bg-gray-800 shadow-lg">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="flex items-center justify-between h-16">
                            <div class="flex items-center">
                                <h1 class="text-xl font-bold text-white">
                                    <i class="fas fa-shield-alt mr-2 text-blue-400"></i>
                                    Traffic Management Platform V3
                                </h1>
                            </div>
                            <div class="flex space-x-4">
                                <button onclick="showSection('domains')" id="btn-domains" class="nav-btn px-3 py-2 rounded-md text-sm font-medium bg-blue-600 text-white">
                                    <i class="fas fa-globe mr-1"></i>Domains
                                </button>
                                <button onclick="showSection('dns')" id="btn-dns" class="nav-btn px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:bg-gray-700 hover:text-white">
                                    <i class="fas fa-network-wired mr-1"></i>DNS
                                </button>
                                <button onclick="showSection('traffic')" id="btn-traffic" class="nav-btn px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:bg-gray-700 hover:text-white">
                                    <i class="fas fa-chart-line mr-1"></i>Traffic
                                </button>
                            </div>
                        </div>
                    </div>
                </nav>
                
                <!-- Main Content -->
                <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
                    <!-- Domain Management Section -->
                    <div id="section-domains" class="section">
                        <div class="bg-gray-800 overflow-hidden shadow rounded-lg">
                            <div class="px-4 py-5 sm:p-6">
                                <div class="flex justify-between items-center mb-4">
                                    <h2 class="text-lg font-medium text-white">Domain Management</h2>
                                    <button onclick="showAddDomain()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                        <i class="fas fa-plus mr-2"></i>Add Domain
                                    </button>
                                </div>
                                <div id="domains-list">
                                    <div class="text-center py-8">
                                        <i class="fas fa-spinner fa-spin text-3xl text-blue-400"></i>
                                        <p class="text-gray-300 mt-2">Loading domains...</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Other sections -->
                    <div id="section-dns" class="section hidden">
                        <div class="bg-gray-800 p-6 rounded-lg">
                            <h2 class="text-lg font-medium text-white mb-4">DNS Management</h2>
                            <p class="text-gray-300">DNS management functionality will be available here.</p>
                        </div>
                    </div>
                    
                    <div id="section-traffic" class="section hidden">
                        <div class="bg-gray-800 p-6 rounded-lg">
                            <h2 class="text-lg font-medium text-white mb-4">Traffic Analytics</h2>
                            <p class="text-gray-300">Traffic analytics will be displayed here.</p>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- Add Domain Modal -->
        <div id="add-domain-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
            <div class="bg-gray-800 p-6 rounded-lg w-full max-w-md">
                <h3 class="text-lg font-medium text-white mb-4">Add New Domain</h3>
                <form id="add-domain-form">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-300 mb-2">Domain Name</label>
                        <input type="text" id="domain-name" required
                               class="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                               placeholder="example.com">
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-300 mb-2">Type</label>
                        <select id="domain-type" class="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white">
                            <option value="production">Production</option>
                            <option value="staging">Staging</option>
                            <option value="development">Development</option>
                        </select>
                    </div>
                    <div class="flex justify-end space-x-3">
                        <button type="button" onclick="hideAddDomain()" class="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700">
                            Cancel
                        </button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                            Add Domain
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            // Global variables
            let token = 'demo';
            let currentSection = 'domains';

            // Show specific section
            function showSection(section) {
                // Hide all sections
                document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
                
                // Update navigation buttons
                document.querySelectorAll('.nav-btn').forEach(btn => {
                    btn.classList.remove('bg-blue-600');
                    btn.classList.add('text-gray-300', 'hover:bg-gray-700', 'hover:text-white');
                });
                
                // Show selected section
                const targetSection = document.getElementById('section-' + section);
                if (targetSection) {
                    targetSection.classList.remove('hidden');
                    currentSection = section;
                }
                
                // Update active nav button
                const activeBtn = document.getElementById('btn-' + section);
                if (activeBtn) {
                    activeBtn.classList.add('bg-blue-600');
                    activeBtn.classList.remove('text-gray-300', 'hover:bg-gray-700', 'hover:text-white');
                }
                
                // Load section specific data
                if (section === 'domains') {
                    loadDomains();
                }
            }

            // Load domains
            async function loadDomains() {
                try {
                    const response = await fetch('/api/domains', {
                        headers: { 'Authorization': 'Bearer ' + token }
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        renderDomains(data.domains);
                    } else {
                        document.getElementById('domains-list').innerHTML = '<p class="text-red-400">Error loading domains: ' + data.message + '</p>';
                    }
                } catch (error) {
                    document.getElementById('domains-list').innerHTML = '<p class="text-red-400">Error loading domains: ' + error.message + '</p>';
                }
            }

            // Render domains
            function renderDomains(domains) {
                const container = document.getElementById('domains-list');
                
                if (domains.length === 0) {
                    container.innerHTML = '<div class="text-center py-8"><p class="text-gray-400">No domains added yet. Click "Add Domain" to get started.</p></div>';
                    return;
                }
                
                const domainsHtml = domains.map(domain => 
                    '<div class="bg-gray-700 p-4 rounded-lg mb-4">' +
                        '<div class="flex justify-between items-center">' +
                            '<div>' +
                                '<h3 class="text-lg font-semibold text-white">' + domain.name + '</h3>' +
                                '<p class="text-gray-400">Status: <span class="text-green-400">' + domain.status + '</span></p>' +
                                '<p class="text-gray-400">Total Requests: ' + domain.totalRequests + '</p>' +
                            '</div>' +
                            '<div class="flex space-x-2">' +
                                '<button onclick="generateProxyConfig(\\'' + domain.id + '\\')" class="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-sm">Proxy Config</button>' +
                                '<button onclick="deleteDomain(\\'' + domain.id + '\\')" class="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm">Delete</button>' +
                            '</div>' +
                        '</div>' +
                    '</div>'
                ).join('');
                
                container.innerHTML = domainsHtml;
            }

            // Show add domain modal
            function showAddDomain() {
                document.getElementById('add-domain-modal').classList.remove('hidden');
            }

            // Hide add domain modal
            function hideAddDomain() {
                document.getElementById('add-domain-modal').classList.add('hidden');
                document.getElementById('add-domain-form').reset();
            }

            // Add domain form submit
            document.getElementById('add-domain-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const name = document.getElementById('domain-name').value.trim();
                const type = document.getElementById('domain-type').value;
                
                if (!name) {
                    alert('Please enter a domain name');
                    return;
                }
                
                try {
                    const response = await fetch('/api/domains', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + token,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ name, type })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        hideAddDomain();
                        loadDomains(); // Reload domains list
                        alert('Domain added successfully!');
                    } else {
                        alert('Error adding domain: ' + data.message);
                    }
                } catch (error) {
                    alert('Error adding domain: ' + error.message);
                }
            });

            // Generate proxy config
            async function generateProxyConfig(domainId) {
                try {
                    const response = await fetch('/api/domains/' + domainId + '/proxy/generate', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + token,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            backendIP: '46.202.158.197',
                            proxyPort: 3000,
                            enableSSL: true
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        // Create a modal to show the config
                        const modal = document.createElement('div');
                        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
                        modal.innerHTML = 
                            '<div class="bg-gray-800 p-6 rounded-lg w-full max-w-4xl max-h-96 overflow-y-auto">' +
                                '<h3 class="text-lg font-medium text-white mb-4">Nginx Configuration for ' + data.domain + '</h3>' +
                                '<pre class="bg-gray-900 p-4 rounded text-green-400 text-sm overflow-x-auto">' + data.config + '</pre>' +
                                '<div class="mt-4 flex justify-end">' +
                                    '<button onclick="this.closest(\\'.fixed\\').remove()" class="bg-gray-600 hover:bg-gray-700 px-4 py-2 rounded text-white">Close</button>' +
                                '</div>' +
                            '</div>';
                        document.body.appendChild(modal);
                    } else {
                        alert('Error generating config: ' + data.message);
                    }
                } catch (error) {
                    alert('Error generating config: ' + error.message);
                }
            }

            // Delete domain
            async function deleteDomain(domainId) {
                if (!confirm('Are you sure you want to delete this domain?')) {
                    return;
                }
                
                try {
                    const response = await fetch('/api/domains/' + domainId, {
                        method: 'DELETE',
                        headers: { 'Authorization': 'Bearer ' + token }
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        loadDomains(); // Reload domains list
                        alert('Domain deleted successfully!');
                    } else {
                        alert('Error deleting domain: ' + data.message);
                    }
                } catch (error) {
                    alert('Error deleting domain: ' + error.message);
                }
            }

            // Initialize
            document.addEventListener('DOMContentLoaded', function() {
                showSection('domains');
            });
        </script>
    </body>
    </html>
  `)
})

const port = 3000
console.log(`🚀 Traffic Management Platform V3 starting on port ${port}`)

serve({
  fetch: app.fetch,
  port
})

console.log(`✅ Server is running on http://localhost:${port}`)