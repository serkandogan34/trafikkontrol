#!/bin/bash

echo "========================================="
echo "🔍 FBCLID DEBUG TEST"
echo "========================================="
echo ""

# Test 1: Access key (known working)
echo "TEST 1: Access Key (Should work)"
curl -k -s -o /dev/null -w "HTTP Status: %{http_code}\n" \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)" \
  "https://127.0.0.1/?access_key=HUR2024_SecureTest_9K3mP7xQ"
echo ""

# Test 2: fbclid only
echo "TEST 2: fbclid only (PROBLEM)"
curl -k -s -o /dev/null -w "HTTP Status: %{http_code}\n" \
  -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X)" \
  "https://127.0.0.1/?fbclid=test12345"
echo ""

# Test 3: Check NGINX variables
echo "TEST 3: Checking NGINX geo variables..."
echo "Simulating request from localhost (127.0.0.1)"
echo ""

echo "========================================="
