import { Hono } from 'hono'
import { serve } from '@hono/node-server'
import { serveStatic } from '@hono/node-server/serve-static'

const app = new Hono()

// Enable CORS
app.use('/api/*', async (c, next) => {
  c.header('Access-Control-Allow-Origin', '*')
  c.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  c.header('Access-Control-Allow-Headers', 'Authorization, Content-Type')
  
  if (c.req.method === 'OPTIONS') {
    return c.text('', 200)
  }
  
  await next()
})

// Serve static files
app.use('/static/*', serveStatic({ 
  root: './public',
  rewriteRequestPath: (path) => path.replace(/^\/static/, '')
}))

// In-memory storage
const domains = new Map()
const dnsRecords = new Map()
let domainIdCounter = Date.now()

// Pre-populate with feroxilprostatit.online
const feroxilDomain = {
  id: '1759847032835',
  name: 'feroxilprostatit.online',
  type: 'production',
  status: 'active',
  connected: true,
  traffic: 1247,
  blocked: 23,
  totalRequests: 1270,
  humanRequests: 1189,
  botRequests: 81,
  cleanServed: 81,
  grayServed: 456,
  aggressiveServed: 733,
  lastTrafficUpdate: new Date().toISOString(),
  addedAt: '2025-10-07T14:24:11.597Z',
  lastChecked: new Date().toISOString()
}
domains.set(feroxilDomain.id, feroxilDomain)

// Authentication middleware (simplified)
const requireAuth = async (c, next) => {
  const authHeader = c.req.header('Authorization')
  if (!authHeader || !authHeader.includes('Bearer')) {
    return c.json({ success: false, message: 'Authentication required' }, 401)
  }
  await next()
}

// Health endpoints
app.get('/api/health', (c) => {
  return c.json({
    success: true,
    status: 'healthy',
    service: 'Traffic Management Platform Node.js',
    version: '3.0',
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()),
    environment: 'development'
  })
})

app.get('/api/auth/demo', (c) => {
  return c.json({
    success: true,
    message: 'Demo authentication successful',
    user: {
      id: 'demo-user',
      email: 'demo@traffic-platform.com',
      role: 'admin'
    },
    token: 'demo-token-12345',
    timestamp: new Date().toISOString()
  })
})

// Domain management
app.get('/api/domains', requireAuth, (c) => {
  const domainList = Array.from(domains.values()).map(domain => ({
    ...domain,
    totalRequests: domain.totalRequests || 0,
    humanRequests: domain.humanRequests || 0,
    botRequests: domain.botRequests || 0,
    blocked: domain.blocked || 0
  }))
  
  return c.json({
    success: true,
    domains: domainList,
    total: domainList.length
  })
})

app.post('/api/domains', requireAuth, async (c) => {
  try {
    const { name, type } = await c.req.json()
    
    if (!name) {
      return c.json({ success: false, message: 'Domain name is required' }, 400)
    }
    
    // Check if domain already exists
    const existingDomain = Array.from(domains.values()).find(d => d.name === name)
    if (existingDomain) {
      return c.json({ success: false, message: 'Domain already exists' }, 400)
    }
    
    const id = (domainIdCounter++).toString()
    const domain = {
      id,
      name,
      type: type || 'production',
      status: 'active',
      connected: true,
      traffic: 0,
      blocked: 0,
      totalRequests: 0,
      humanRequests: 0,
      botRequests: 0,
      cleanServed: 0,
      grayServed: 0,
      aggressiveServed: 0,
      lastTrafficUpdate: new Date().toISOString(),
      addedAt: new Date().toISOString(),
      lastChecked: new Date().toISOString()
    }
    
    domains.set(id, domain)
    
    return c.json({
      success: true,
      domain: domain
    })
  } catch (error) {
    return c.json({
      success: false,
      message: 'Error adding domain: ' + error.message
    }, 500)
  }
})

app.delete('/api/domains/:id', requireAuth, (c) => {
  const id = c.req.param('id')
  
  if (!domains.has(id)) {
    return c.json({ success: false, message: 'Domain not found' }, 404)
  }
  
  domains.delete(id)
  
  return c.json({
    success: true,
    message: 'Domain deleted successfully'
  })
})

// Proxy management for domains
app.post('/api/domains/:id/proxy/generate', requireAuth, async (c) => {
  const id = c.req.param('id')
  const config = await c.req.json()
  
  const domain = domains.get(id)
  if (!domain) {
    return c.json({ success: false, message: 'Domain not found' }, 404)
  }
  
  const {
    backendIP = '46.202.158.197',
    proxyPort = 3000,
    enableSSL = false
  } = config
  
  const nginxConfig = `# Auto-generated Nginx configuration for ${domain.name}
# Generated at: ${new Date().toISOString()}

server {
    listen 80;
    server_name ${domain.name};
    ${enableSSL ? 'listen 443 ssl http2;' : ''}
    
    # Traffic Management Platform Proxy
    location / {
        proxy_pass http://127.0.0.1:${proxyPort}/proxy-handler;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Original-Domain "${domain.name}";
        proxy_set_header X-Original-Backend "${backendIP}";
        
        # Security headers
        add_header X-Frame-Options SAMEORIGIN always;
        add_header X-Content-Type-Options nosniff always;
        add_header X-XSS-Protection "1; mode=block" always;
    }
    
    # Health check endpoint
    location /nginx-health {
        access_log off;
        return 200 "healthy\\n";
        add_header Content-Type text/plain;
    }
}
`
  
  return c.json({
    success: true,
    message: 'Nginx configuration generated successfully',
    config: nginxConfig,
    domain: domain.name
  })
})

// Traffic analytics endpoint
app.get('/api/traffic/overview', requireAuth, (c) => {
  let totalRequests = 0
  let totalBlocked = 0
  let totalDomains = 0
  let totalHumans = 0
  let totalBots = 0
  
  for (const domain of domains.values()) {
    totalRequests += domain.totalRequests || 0
    totalBlocked += domain.blocked || 0
    totalHumans += domain.humanRequests || 0
    totalBots += domain.botRequests || 0
    totalDomains++
  }
  
  return c.json({
    success: true,
    overview: {
      totalDomains,
      totalRequests,
      totalBlocked,
      totalHumans,
      totalBots,
      humanRate: totalRequests > 0 ? Math.round((totalHumans / totalRequests) * 100) : 0,
      botRate: totalRequests > 0 ? Math.round((totalBots / totalRequests) * 100) : 0,
      blockRate: totalRequests > 0 ? Math.round((totalBlocked / totalRequests) * 100) : 0
    },
    timestamp: new Date().toISOString()
  })
})

// DNS records endpoint
app.get('/api/dns/records', requireAuth, (c) => {
  return c.json({
    success: true,
    records: [
      {
        id: '1',
        name: 'feroxilprostatit.online',
        type: 'A',
        value: '46.202.158.197',
        ttl: 300,
        status: 'active'
      },
      {
        id: '2',
        name: 'www.feroxilprostatit.online',
        type: 'CNAME',
        value: 'feroxilprostatit.online',
        ttl: 300,
        status: 'active'
      }
    ],
    total: 2
  })
})

// Main route with enhanced dashboard
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="tr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Traffic Management Platform V3</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-900 text-white">
        <div id="app">
            <div class="min-h-screen">
                <!-- Navigation -->
                <nav class="bg-gray-800 shadow-lg">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="flex items-center justify-between h-16">
                            <div class="flex items-center">
                                <h1 class="text-xl font-bold text-white">
                                    <i class="fas fa-shield-alt mr-2 text-blue-400"></i>
                                    Trafik Yönetim Platformu V3
                                </h1>
                            </div>
                            <div class="flex space-x-4">
                                <button onclick="showSection('domains')" id="btn-domains" class="nav-btn px-3 py-2 rounded-md text-sm font-medium bg-blue-600 text-white">
                                    <i class="fas fa-globe mr-1"></i>Alan Adları
                                </button>
                                <button onclick="showSection('dns')" id="btn-dns" class="nav-btn px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:bg-gray-700 hover:text-white">
                                    <i class="fas fa-network-wired mr-1"></i>DNS
                                </button>
                                <button onclick="showSection('traffic')" id="btn-traffic" class="nav-btn px-3 py-2 rounded-md text-sm font-medium text-gray-300 hover:bg-gray-700 hover:text-white">
                                    <i class="fas fa-chart-line mr-1"></i>Trafik
                                </button>
                            </div>
                        </div>
                    </div>
                </nav>
                
                <!-- Main Content -->
                <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
                    <!-- Domain Management Section -->
                    <div id="section-domains" class="section">
                        <div class="bg-gray-800 overflow-hidden shadow rounded-lg">
                            <div class="px-4 py-5 sm:p-6">
                                <div class="flex justify-between items-center mb-4">
                                    <h2 class="text-lg font-medium text-white">Alan Adı Yönetimi</h2>
                                    <button onclick="showAddDomain()" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                        <i class="fas fa-plus mr-2"></i>Alan Adı Ekle
                                    </button>
                                </div>
                                <div id="domains-list">
                                    <div class="text-center py-8">
                                        <i class="fas fa-spinner fa-spin text-3xl text-blue-400"></i>
                                        <p class="text-gray-300 mt-2">Alan adları yükleniyor...</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- DNS Management Section -->
                    <div id="section-dns" class="section hidden">
                        <div class="bg-gray-800 overflow-hidden shadow rounded-lg">
                            <div class="px-4 py-5 sm:p-6">
                                <div class="flex justify-between items-center mb-4">
                                    <h2 class="text-lg font-medium text-white">DNS Yönetimi</h2>
                                    <button onclick="showAddDNS()" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                        <i class="fas fa-plus mr-2"></i>DNS Kaydı Ekle
                                    </button>
                                </div>
                                <div id="dns-list">
                                    <div class="text-center py-8">
                                        <i class="fas fa-spinner fa-spin text-3xl text-green-400"></i>
                                        <p class="text-gray-300 mt-2">DNS kayıtları yükleniyor...</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Traffic Analytics Section -->
                    <div id="section-traffic" class="section hidden">
                        <div class="bg-gray-800 overflow-hidden shadow rounded-lg">
                            <div class="px-4 py-5 sm:p-6">
                                <h2 class="text-lg font-medium text-white mb-4">Trafik Analizi</h2>
                                <div id="traffic-stats">
                                    <div class="text-center py-8">
                                        <i class="fas fa-spinner fa-spin text-3xl text-purple-400"></i>
                                        <p class="text-gray-300 mt-2">Trafik verileri yükleniyor...</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>

        <!-- Add Domain Modal -->
        <div id="add-domain-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden flex items-center justify-center z-50">
            <div class="bg-gray-800 p-6 rounded-lg w-full max-w-md">
                <h3 class="text-lg font-medium text-white mb-4">Yeni Alan Adı Ekle</h3>
                <form id="add-domain-form">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-300 mb-2">Alan Adı</label>
                        <input type="text" id="domain-name" required
                               class="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white"
                               placeholder="example.com">
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-300 mb-2">Tip</label>
                        <select id="domain-type" class="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white">
                            <option value="production">Production</option>
                            <option value="staging">Staging</option>
                            <option value="development">Development</option>
                        </select>
                    </div>
                    <div class="flex justify-end space-x-3">
                        <button type="button" onclick="hideAddDomain()" class="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700">
                            İptal
                        </button>
                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                            Alan Adı Ekle
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script>
            // Global variables
            let token = 'demo';
            let currentSection = 'domains';

            // Show specific section
            function showSection(section) {
                console.log('Switching to section:', section);
                
                // Hide all sections
                document.querySelectorAll('.section').forEach(s => s.classList.add('hidden'));
                
                // Update navigation buttons
                document.querySelectorAll('.nav-btn').forEach(btn => {
                    btn.classList.remove('bg-blue-600');
                    btn.classList.add('text-gray-300', 'hover:bg-gray-700', 'hover:text-white');
                });
                
                // Show selected section
                const targetSection = document.getElementById('section-' + section);
                if (targetSection) {
                    targetSection.classList.remove('hidden');
                    currentSection = section;
                }
                
                // Update active nav button
                const activeBtn = document.getElementById('btn-' + section);
                if (activeBtn) {
                    activeBtn.classList.add('bg-blue-600');
                    activeBtn.classList.remove('text-gray-300', 'hover:bg-gray-700', 'hover:text-white');
                }
                
                // Load section specific data
                switch(section) {
                    case 'domains':
                        loadDomains();
                        break;
                    case 'dns':
                        loadDNSRecords();
                        break;
                    case 'traffic':
                        loadTrafficStats();
                        break;
                }
            }

            // Load domains
            async function loadDomains() {
                try {
                    console.log('Loading domains...');
                    const response = await fetch('/api/domains', {
                        headers: { 'Authorization': 'Bearer ' + token }
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        console.log('Domains loaded:', data.domains);
                        renderDomains(data.domains);
                    } else {
                        document.getElementById('domains-list').innerHTML = '<p class="text-red-400">Hata: ' + data.message + '</p>';
                    }
                } catch (error) {
                    console.error('Error loading domains:', error);
                    document.getElementById('domains-list').innerHTML = '<p class="text-red-400">Alan adları yüklenirken hata: ' + error.message + '</p>';
                }
            }

            // Load DNS records
            async function loadDNSRecords() {
                try {
                    console.log('Loading DNS records...');
                    const response = await fetch('/api/dns/records', {
                        headers: { 'Authorization': 'Bearer ' + token }
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        console.log('DNS records loaded:', data.records);
                        renderDNSRecords(data.records);
                    } else {
                        document.getElementById('dns-list').innerHTML = '<p class="text-red-400">Hata: ' + data.message + '</p>';
                    }
                } catch (error) {
                    console.error('Error loading DNS records:', error);
                    document.getElementById('dns-list').innerHTML = '<p class="text-red-400">DNS kayıtları yüklenirken hata: ' + error.message + '</p>';
                }
            }

            // Load traffic statistics
            async function loadTrafficStats() {
                try {
                    console.log('Loading traffic stats...');
                    const response = await fetch('/api/traffic/overview', {
                        headers: { 'Authorization': 'Bearer ' + token }
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        console.log('Traffic stats loaded:', data.overview);
                        renderTrafficStats(data.overview);
                    } else {
                        document.getElementById('traffic-stats').innerHTML = '<p class="text-red-400">Hata: ' + data.message + '</p>';
                    }
                } catch (error) {
                    console.error('Error loading traffic stats:', error);
                    document.getElementById('traffic-stats').innerHTML = '<p class="text-red-400">Trafik verileri yüklenirken hata: ' + error.message + '</p>';
                }
            }

            // Render domains
            function renderDomains(domains) {
                const container = document.getElementById('domains-list');
                
                if (domains.length === 0) {
                    container.innerHTML = '<div class="text-center py-8"><p class="text-gray-400">Henüz alan adı eklenmemiş. Başlamak için "Alan Adı Ekle" butonuna tıklayın.</p></div>';
                    return;
                }
                
                let domainsHtml = '';
                
                domains.forEach(domain => {
                    domainsHtml += 
                        '<div class="bg-gray-700 p-4 rounded-lg mb-4">' +
                            '<div class="flex justify-between items-center">' +
                                '<div>' +
                                    '<h3 class="text-lg font-semibold text-white">' + domain.name + '</h3>' +
                                    '<div class="flex space-x-4 mt-2 text-sm">' +
                                        '<span class="text-green-400">Durum: ' + domain.status + '</span>' +
                                        '<span class="text-blue-400">Toplam İstek: ' + domain.totalRequests + '</span>' +
                                        '<span class="text-purple-400">İnsan: ' + domain.humanRequests + '</span>' +
                                        '<span class="text-yellow-400">Bot: ' + domain.botRequests + '</span>' +
                                        '<span class="text-red-400">Engellenen: ' + domain.blocked + '</span>' +
                                    '</div>' +
                                '</div>' +
                                '<div class="flex space-x-2">' +
                                    '<button onclick="generateProxyConfig(\\''+domain.id+'\\')" class="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-sm">Proxy Config</button>' +
                                    '<button onclick="deleteDomain(\\''+domain.id+'\\')" class="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-sm">Sil</button>' +
                                '</div>' +
                            '</div>' +
                        '</div>';
                });
                
                container.innerHTML = domainsHtml;
            }

            // Render DNS records
            function renderDNSRecords(records) {
                const container = document.getElementById('dns-list');
                
                if (records.length === 0) {
                    container.innerHTML = '<div class="text-center py-8"><p class="text-gray-400">DNS kaydı bulunamadı.</p></div>';
                    return;
                }
                
                let recordsHtml = '<div class="overflow-x-auto">' +
                                  '<table class="min-w-full divide-y divide-gray-700">' +
                                  '<thead class="bg-gray-700">' +
                                  '<tr>' +
                                  '<th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Name</th>' +
                                  '<th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Type</th>' +
                                  '<th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Value</th>' +
                                  '<th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">TTL</th>' +
                                  '<th class="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Status</th>' +
                                  '</tr>' +
                                  '</thead>' +
                                  '<tbody class="bg-gray-800 divide-y divide-gray-700">';
                
                records.forEach(record => {
                    recordsHtml += 
                        '<tr>' +
                        '<td class="px-6 py-4 whitespace-nowrap text-sm text-white">' + record.name + '</td>' +
                        '<td class="px-6 py-4 whitespace-nowrap text-sm text-blue-400">' + record.type + '</td>' +
                        '<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-300">' + record.value + '</td>' +
                        '<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-300">' + record.ttl + '</td>' +
                        '<td class="px-6 py-4 whitespace-nowrap text-sm text-green-400">' + record.status + '</td>' +
                        '</tr>';
                });
                
                recordsHtml += '</tbody></table></div>';
                container.innerHTML = recordsHtml;
            }

            // Render traffic statistics
            function renderTrafficStats(stats) {
                const container = document.getElementById('traffic-stats');
                
                const statsHtml = 
                    '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">' +
                        '<div class="bg-blue-600 bg-opacity-20 border border-blue-500 p-4 rounded-lg">' +
                            '<div class="flex items-center justify-between">' +
                                '<div>' +
                                    '<p class="text-blue-300 text-sm">Toplam Alan Adı</p>' +
                                    '<p class="text-2xl font-bold text-white">' + stats.totalDomains + '</p>' +
                                '</div>' +
                                '<i class="fas fa-globe text-blue-400 text-2xl"></i>' +
                            '</div>' +
                        '</div>' +
                        
                        '<div class="bg-green-600 bg-opacity-20 border border-green-500 p-4 rounded-lg">' +
                            '<div class="flex items-center justify-between">' +
                                '<div>' +
                                    '<p class="text-green-300 text-sm">İnsan Trafiği</p>' +
                                    '<p class="text-2xl font-bold text-white">' + stats.totalHumans.toLocaleString() + '</p>' +
                                    '<p class="text-xs text-gray-400">' + stats.humanRate + '%</p>' +
                                '</div>' +
                                '<i class="fas fa-user text-green-400 text-2xl"></i>' +
                            '</div>' +
                        '</div>' +
                        
                        '<div class="bg-yellow-600 bg-opacity-20 border border-yellow-500 p-4 rounded-lg">' +
                            '<div class="flex items-center justify-between">' +
                                '<div>' +
                                    '<p class="text-yellow-300 text-sm">Bot Trafiği</p>' +
                                    '<p class="text-2xl font-bold text-white">' + stats.totalBots.toLocaleString() + '</p>' +
                                    '<p class="text-xs text-gray-400">' + stats.botRate + '%</p>' +
                                '</div>' +
                                '<i class="fas fa-robot text-yellow-400 text-2xl"></i>' +
                            '</div>' +
                        '</div>' +
                        
                        '<div class="bg-red-600 bg-opacity-20 border border-red-500 p-4 rounded-lg">' +
                            '<div class="flex items-center justify-between">' +
                                '<div>' +
                                    '<p class="text-red-300 text-sm">Engellenen</p>' +
                                    '<p class="text-2xl font-bold text-white">' + stats.totalBlocked.toLocaleString() + '</p>' +
                                    '<p class="text-xs text-gray-400">' + stats.blockRate + '%</p>' +
                                '</div>' +
                                '<i class="fas fa-ban text-red-400 text-2xl"></i>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    
                    '<div class="bg-gray-700 p-4 rounded-lg">' +
                        '<h3 class="text-lg font-semibold text-white mb-4">Trafik Özeti</h3>' +
                        '<div class="text-sm text-gray-300">' +
                            '<p><strong class="text-white">Toplam İstek:</strong> ' + stats.totalRequests.toLocaleString() + '</p>' +
                            '<p><strong class="text-white">İnsan Oranı:</strong> ' + stats.humanRate + '%</p>' +
                            '<p><strong class="text-white">Bot Oranı:</strong> ' + stats.botRate + '%</p>' +
                            '<p><strong class="text-white">Engelleme Oranı:</strong> ' + stats.blockRate + '%</p>' +
                        '</div>' +
                    '</div>';
                
                container.innerHTML = statsHtml;
            }

            // Show add domain modal
            function showAddDomain() {
                document.getElementById('add-domain-modal').classList.remove('hidden');
            }

            // Hide add domain modal
            function hideAddDomain() {
                document.getElementById('add-domain-modal').classList.add('hidden');
                document.getElementById('add-domain-form').reset();
            }

            // Show add DNS modal (placeholder)
            function showAddDNS() {
                alert('DNS kaydı ekleme özelliği yakında eklenecek.');
            }

            // Add domain form submit
            document.getElementById('add-domain-form').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const name = document.getElementById('domain-name').value.trim();
                const type = document.getElementById('domain-type').value;
                
                if (!name) {
                    alert('Lütfen alan adını girin');
                    return;
                }
                
                try {
                    const response = await fetch('/api/domains', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + token,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ name, type })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        hideAddDomain();
                        loadDomains(); // Reload domains list
                        alert('Alan adı başarıyla eklendi!');
                    } else {
                        alert('Alan adı eklenirken hata: ' + data.message);
                    }
                } catch (error) {
                    alert('Alan adı eklenirken hata: ' + error.message);
                }
            });

            // Generate proxy config
            async function generateProxyConfig(domainId) {
                try {
                    const response = await fetch('/api/domains/' + domainId + '/proxy/generate', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + token,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            backendIP: '46.202.158.197',
                            proxyPort: 3000,
                            enableSSL: true
                        })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        // Create a modal to show the config
                        const modal = document.createElement('div');
                        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
                        modal.innerHTML = 
                            '<div class="bg-gray-800 p-6 rounded-lg w-full max-w-4xl max-h-96 overflow-y-auto">' +
                                '<h3 class="text-lg font-medium text-white mb-4">' + data.domain + ' için Nginx Yapılandırması</h3>' +
                                '<pre class="bg-gray-900 p-4 rounded text-green-400 text-sm overflow-x-auto">' + data.config + '</pre>' +
                                '<div class="mt-4 flex justify-end">' +
                                    '<button onclick="this.closest(\\'.fixed\\').remove()" class="bg-gray-600 hover:bg-gray-700 px-4 py-2 rounded text-white">Kapat</button>' +
                                '</div>' +
                            '</div>';
                        document.body.appendChild(modal);
                    } else {
                        alert('Yapılandırma oluşturulurken hata: ' + data.message);
                    }
                } catch (error) {
                    alert('Yapılandırma oluşturulurken hata: ' + error.message);
                }
            }

            // Delete domain
            async function deleteDomain(domainId) {
                if (!confirm('Bu alan adını silmek istediğinizden emin misiniz?')) {
                    return;
                }
                
                try {
                    const response = await fetch('/api/domains/' + domainId, {
                        method: 'DELETE',
                        headers: { 'Authorization': 'Bearer ' + token }
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        loadDomains(); // Reload domains list
                        alert('Alan adı başarıyla silindi!');
                    } else {
                        alert('Alan adı silinirken hata: ' + data.message);
                    }
                } catch (error) {
                    alert('Alan adı silinirken hata: ' + error.message);
                }
            }

            // Initialize
            document.addEventListener('DOMContentLoaded', function() {
                console.log('Dashboard initializing...');
                showSection('domains');
            });
        </script>
    </body>
    </html>
  `)
})

const port = 3000
console.log(`🚀 Traffic Management Platform V3 starting on port ${port}`)

serve({
  fetch: app.fetch,
  port
})

console.log(`✅ Server is running on http://localhost:${port}`)