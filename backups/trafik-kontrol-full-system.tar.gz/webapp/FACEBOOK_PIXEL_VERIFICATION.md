# ✅ FACEBOOK PIXEL DOĞRULAMA RAPORU

**Tarih**: 2025-10-14  
**Pixel ID**: 1536997377317312  
**Durum**: 🟢 Başarıyla Kuruldu

---

## 📊 KURULUM DETAYLARI

### 1. Pixel Kodu Eklendi ✅
```javascript
Konum: /var/www/html/index.html (Production)
Kaynak: /home/root/webapp/hurriyet-saglik-fixed-template.html
Satır: 8-24 (<head> bölümünde)
```

### 2. Event Tracking Kuruldu ✅

#### A. PageView Event (Otomatik)
```javascript
fbq('init', '1536997377317312');
fbq('track', 'PageView');
```
**Ne Zaman Çalışır**: Her sayfa yüklendiğinde otomatik

#### B. ViewContent Event (Özel)
```javascript
fbq('track', 'ViewContent', {
    content_name: 'Hürriyet Sağlık Landing Page',
    content_category: 'Health Product Page',
    content_type: 'product',
    value: 149.90,
    currency: 'TRY'
});
```
**Ne Zaman Çalışır**: fbclid parametresi tespit edildiğinde (Facebook trafiği)

#### C. Lead Event (Conversion)
```javascript
fbq('track', 'Lead', {
    content_name: 'Hürriyet Sağlık Form',
    content_category: 'Health Product',
    value: 149.90,
    currency: 'TRY'
});
```
**Ne Zaman Çalışır**: Form başarıyla gönderildiğinde

---

## 🧪 TEST SENARYOLARı

### Senaryo 1: Normal Sayfa Ziyareti
```
URL: https://hüriyetsagliksonnhaberler.site/?fbclid=test123
Beklenen:
  ✅ PageView event gönderilir
  ✅ ViewContent event gönderilir
```

### Senaryo 2: Form Gönderimi
```
Adımlar:
  1. Sayfa yükle (?fbclid=test123)
  2. Form doldur (Ad + Telefon)
  3. Gönder butonuna tıkla
  
Beklenen:
  ✅ PageView event gönderilir
  ✅ ViewContent event gönderilir
  ✅ Lead event gönderilir (form sonrası)
```

### Senaryo 3: Admin/Test Erişimi
```
URL: https://hüriyetsagliksonnhaberler.site/?key=HUR2024_SecureTest_9K3mP7xQ
Beklenen:
  ✅ PageView event gönderilir
  ⚠️ ViewContent gönderilmez (fbclid yok)
  ✅ Lead event gönderilir (form doldurulursa)
```

---

## 🛠️ TEST ARAÇLARI

### 1. Facebook Pixel Helper (Chrome Extension)
```
Link: https://chrome.google.com/webstore
Arama: "Facebook Pixel Helper"
Kullanım:
  1. Extension'ı yükle
  2. Siteyi ziyaret et (?fbclid=test123)
  3. Extension ikonuna tıkla
  4. "PageView" ve "ViewContent" eventi görmelisin
  5. Form gönderince "Lead" eventi göreceksin
```

### 2. Facebook Events Manager
```
Link: https://business.facebook.com/events_manager
Adımlar:
  1. Business hesabına giriş yap
  2. Events Manager'ı aç
  3. Pixel: 1536997377317312 seç
  4. "Test Events" sekmesine git
  5. Test trafiğini real-time görürsün
```

### 3. Browser Console Test
```
1. Siteyi aç (?fbclid=test123)
2. F12 tuşuna bas (Developer Tools)
3. Console tab'ına git
4. Şunu yaz: typeof fbq
5. Sonuç: "function" olmalı ✅
6. Şunu yaz: fbq('track', 'ViewContent')
7. Network tab'da facebook.com request'i görmelisin
```

---

## 🔍 DOĞRULAMA KONTROL LİSTESİ

Kampanyayı başlatmadan önce:

- [ ] **Pixel Helper Extension yüklü mü?**
  - İndirme: Chrome Web Store → "Facebook Pixel Helper"
  
- [ ] **Pixel aktif görünüyor mu?** (Yeşil ✓)
  - Test URL: https://hüriyetsagliksonnhaberler.site/?fbclid=test123
  - Pixel Helper'da "1536997377317312" görmelisin
  
- [ ] **PageView event tetikleniyor mu?**
  - Sayfa yüklendiğinde otomatik gelmeli
  - Pixel Helper'da "PageView" yazmalı
  
- [ ] **ViewContent event tetikleniyor mu?**
  - fbclid parametresi varsa gelmeli
  - Pixel Helper'da "ViewContent" yazmalı
  
- [ ] **Lead event tetikleniyor mu?**
  - Form gönderiminde gelmeli
  - Pixel Helper'da "Lead" yazmalı
  
- [ ] **Events Manager'da görünüyor mu?**
  - https://business.facebook.com/events_manager
  - Test Events'te real-time veri görmeli
  
- [ ] **Hata var mı?**
  - Console'da kırmızı hata olmamalı
  - Network tab'da facebook.com request başarılı (200 OK)

---

## 📈 EVENTS MANAGER'DA GÖRÜNÜM

### Beklenen Görünüm:
```
Events Manager → Pixel: 1536997377317312 → Test Events

🟢 PageView
   Time: 14:23:45
   Source: https://hüriyetsagliksonnhaberler.site
   
🟢 ViewContent
   Time: 14:23:46
   Value: 149.90 TRY
   Content: Hürriyet Sağlık Landing Page
   
🟢 Lead
   Time: 14:25:12
   Value: 149.90 TRY
   Content: Hürriyet Sağlık Form
```

---

## 🚨 SORUN GİDERME

### Problem 1: Pixel Helper "No Pixel Found" diyor
```
Sebep: Pixel kodu yüklenmemiş
Çözüm:
  1. Sayfayı yenile (Ctrl+F5)
  2. Cache'i temizle
  3. Browser Console'da: typeof fbq
  4. "undefined" ise pixel yüklenememiş
  5. Network tab'da fbevents.js'i ara
```

### Problem 2: Events Manager'da veri görünmüyor
```
Sebep 1: Test Events modu kapalı
Çözüm: Events Manager → Test Events → "Test Events" butonuna tıkla

Sebep 2: Pixel ID yanlış
Çözüm: HTML'de 1536997377317312 olduğunu doğrula

Sebep 3: Gecikmeli data
Çözüm: 1-2 dakika bekle, real-time bazen gecikir
```

### Problem 3: ViewContent event gelmiyor
```
Sebep: fbclid parametresi yok
Çözüm: URL'ye ?fbclid=test123 ekle
Not: ViewContent sadece fbclid varsa tetiklenir
```

### Problem 4: Lead event gelmiyor
```
Sebep 1: Form gönderilmedi
Çözüm: Formu doldur ve gönder

Sebep 2: JavaScript hatası
Çözüm: Console'da hata var mı kontrol et

Sebep 3: Webhook hatası
Çözüm: Form gönderimi başarılı olsa bile event gitmeli
```

---

## 📊 KRİTİK METRİKLER

Kampanya başladığında Events Manager'da takip et:

### İlk 24 Saat:
```
Hedef:
  PageView: 100+ event
  ViewContent: 80+ event (clicklerin %80'i)
  Lead: 5-10 event (formu doldurma)
```

### 3-7 Gün:
```
Optimization Phase:
  PageView/ViewContent ratio: 1.2-1.5 (normal)
  ViewContent/Lead ratio: 10-20 (conversion rate %5-10)
  CPL (Cost Per Lead): 10-30 TL
```

### 7+ Gün:
```
Scaling Phase:
  Daily Leads: 10-50
  CPL: 15-25 TL (optimize edilmiş)
  ROAS (Return on Ad Spend): 3x-5x hedef
```

---

## ✅ ONAY

**Facebook Pixel Kurulumu**: ✅ TAMAMLANDI  
**PageView Event**: ✅ Aktif  
**ViewContent Event**: ✅ Aktif (fbclid ile)  
**Lead Event**: ✅ Aktif (form submit ile)  
**Production Deploy**: ✅ Tamamlandı  
**Test Hazırlığı**: ✅ Hazır

**Durum**: 🟢 Kampanya başlatılabilir!

---

## 📞 HIZLI KOMUTLAR

```bash
# Pixel kodunu kontrol et
grep "1536997377317312" /var/www/html/index.html

# Event tracking kodunu kontrol et
grep "fbq('track'" /var/www/html/index.html

# Landing page'i test et (mobil)
curl -A "Mozilla/5.0 (iPhone)" "https://hüriyetsagliksonnhaberler.site/?fbclid=test123" -I

# Form gönderim loglarını kontrol et
sudo grep "POST /submit-form" /etc/nginx-hurriyet/logs/hurriyet-health-ssl.access.log
```

---

**Oluşturulma**: 2025-10-14  
**Son Güncelleme**: 2025-10-14  
**Durum**: Production Ready 🚀
