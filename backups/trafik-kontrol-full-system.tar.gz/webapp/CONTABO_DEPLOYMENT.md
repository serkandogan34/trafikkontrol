# 🚀 Contabo Server Deployment Rehberi

## 📋 Traffic Management Platform - Production Kurulum

### 🎯 Repository
- **GitHub**: https://github.com/serkandogan34/trafikkontrol
- **Branch**: main
- **Latest Commit**: Complete Traffic Management Platform

---

## 🔧 Contabo Server Kurulum Adımları

### 1. **Sunucu Hazırlığı**
```bash
# System update
sudo apt update && sudo apt upgrade -y

# Node.js 20 kurulumu
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# PM2 global kurulum
sudo npm install -g pm2

# Git kurulumu
sudo apt install git -y

# Nginx kurulumu (reverse proxy için)
sudo apt install nginx -y

# SSL sertifika yöneticisi
sudo apt install certbot python3-certbot-nginx -y
```

### 2. **Proje Klonlama**
```bash
# Ana dizine git
cd /home/ubuntu

# Repository klonla
git clone https://github.com/serkandogan34/trafikkontrol.git
cd trafikkontrol

# Dependencies yükle
npm install

# Build yap
npm run build
```

### 3. **PM2 ile Servis Başlatma**
```bash
# PM2 ekosistem dosyası zaten mevcut
pm2 start ecosystem.config.cjs

# Autostart ayarla
pm2 startup
pm2 save

# Servis durumunu kontrol et
pm2 list
pm2 logs trafik-kontrol
```

### 4. **Nginx Reverse Proxy Kurulumu**
```bash
# Nginx config oluştur
sudo nano /etc/nginx/sites-available/trafikkontrol

# Config içeriği:
```
```nginx
server {
    listen 80;
    server_name feroxilprostatit.online www.feroxilprostatit.online;
    
    # Traffic Manager'a yönlendir
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        
        # Timeout ayarları
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
    
    # Health check endpoint
    location /health {
        proxy_pass http://localhost:3000/health;
    }
}
```

```bash
# Config'i aktifleştir
sudo ln -s /etc/nginx/sites-available/trafikkontrol /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 5. **SSL Sertifikası (Let's Encrypt)**
```bash
# SSL sertifikası al
sudo certbot --nginx -d feroxilprostatit.online -d www.feroxilprostatit.online

# Auto-renewal test
sudo certbot renew --dry-run
```

### 6. **Firewall Ayarları**
```bash
# UFW firewall aktifleştir
sudo ufw enable
sudo ufw allow ssh
sudo ufw allow 'Nginx Full'
sudo ufw status
```

---

## 🌐 DNS Yönlendirme (Hostinger)

### **⚠️ ÖNEMLİ: DNS değişikliklerinden önce sunucu hazır olmalı!**

### Contabo Server IP'sini öğren:
```bash
curl ifconfig.me
# veya
ip route get 8.8.8.8 | awk '{print $7}'
```

### Hostinger hPanel DNS Ayarları:
```
🔧 Değiştirilecek kayıtlar:

MEVCUT:
A     @     0    207.180.204.60    300
A     www   0    207.180.204.60    300

YENİ:
A     @     0    [CONTABO_SERVER_IP]    300  
A     www   0    [CONTABO_SERVER_IP]    300
```

---

## 🧪 Test ve Doğrulama

### 1. **Sunucu Testi**
```bash
# PM2 durumu
pm2 status

# Nginx durumu  
sudo systemctl status nginx

# Port kontrolü
sudo netstat -tulpn | grep :3000
sudo netstat -tulpn | grep :80
sudo netstat -tulpn | grep :443
```

### 2. **Uygulama Testi**
```bash
# Yerel test
curl http://localhost:3000
curl http://localhost:3000/health

# Nginx üzerinden test
curl http://[CONTABO_SERVER_IP]
```

### 3. **DNS Değişiklik Sonrası**
```bash
# DNS propagation kontrolü
nslookup feroxilprostatit.online
dig feroxilprostatit.online A

# Site erişimi
curl -I https://feroxilprostatit.online
```

---

## 📋 Environment Variables

### Production ayarları için `.env` dosyası oluştur:
```bash
# .env dosyası oluştur
cat > .env << EOF
NODE_ENV=production
PORT=3000
DOMAIN=feroxilprostatit.online
ORIGINAL_BACKEND=https://feroxilprostatit.online
EOF
```

---

## 🛠️ Sorun Giderme

### Log kontrolü:
```bash
# PM2 logs
pm2 logs trafik-kontrol --lines 100

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# System logs
sudo journalctl -u nginx -f
```

### Servis yeniden başlatma:
```bash
# PM2 restart
pm2 restart trafik-kontrol

# Nginx restart
sudo systemctl restart nginx

# Tam sistem restart
sudo reboot
```

---

## 🎯 Deployment Tamamlandıktan Sonra

### 1. **Dashboard Erişimi**
- **URL**: https://feroxilprostatit.online
- **Login**: Mevcut auth sistemi ile

### 2. **Domain Yönetimi**
- feroxilprostatit.online domain'ini sisteme ekle
- Original Backend: https://feroxilprostatit.online (önceki Hostinger)
- 3-tier backend sistemi ayarla

### 3. **Traffic Monitoring**
- Real-time analytics kontrol et
- Bot detection test yap
- Geographic controls dene
- IP management test et

### 4. **Performance Monitoring**
```bash
# CPU & Memory
htop

# Disk usage
df -h

# Network
iotop
```

---

## ⚡ Hızlı Deployment Script

```bash
#!/bin/bash
# deploy.sh - Tek komutla deployment

echo "🚀 Traffic Management Platform Deployment Başlıyor..."

# System update
sudo apt update && sudo apt upgrade -y

# Node.js & Dependencies
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs git nginx certbot python3-certbot-nginx
sudo npm install -g pm2

# Project setup
cd /home/ubuntu
git clone https://github.com/serkandogan34/trafikkontrol.git
cd trafikkontrol
npm install
npm run build

# PM2 start
pm2 start ecosystem.config.cjs
pm2 startup
pm2 save

echo "✅ Deployment tamamlandı!"
echo "🌐 Şimdi DNS ayarlarını yapabilirsiniz"
echo "📋 Nginx config için: sudo nano /etc/nginx/sites-available/trafikkontrol"
```

**Deployment başarılı olursa buradan haber ver! DNS ayarlarını yapalım!** 🚀