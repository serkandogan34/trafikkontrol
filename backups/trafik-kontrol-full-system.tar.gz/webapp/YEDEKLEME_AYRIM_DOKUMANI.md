# 🔄 Hürriyet Sağlık - Yedekleme Ayrımı ve Karşılaştırma

**Tarih**: 2025-10-14  
**Durum**: 2 farklı yedekleme türü mevcut

---

## 📦 İKİ FARKLI YEDEK TİPİ VAR

### 1️⃣ **NGINX Konfigürasyon Yedeği** (Sunucu Ayarları)
```
📁 Dosya: hurriyet-nginx-backup-2025-10-14.tar.gz
📊 Boyut: 1.5MB
📅 Tarih: 2025-10-14
🔧 Tür:   Sistem Konfigürasyonu
```

**İçinde Ne Var:**
```
✅ /etc/nginx-hurriyet/nginx.conf              (NGINX ana ayarları)
✅ /etc/nginx-hurriyet/sites-available/        (Site konfigürasyonları)
✅ /etc/nginx-hurriyet/sites-enabled/          (Aktif site linkleri)
✅ /usr/share/GeoIP/GeoIP.dat                  (GeoIP veritabanı - 1.4MB)
```

**Ne İşe Yarar:**
- ✅ 7 güvenlik katmanı ayarları
- ✅ Rate limiting kuralları
- ✅ Geo-blocking ayarları
- ✅ SSL/TLS konfigürasyonu
- ✅ Mobile-only kuralları
- ✅ Facebook referrer kontrolleri
- ✅ Admin IP bypass ayarları

**Ne Zaman Kullanılır:**
- 🔧 NGINX güncelleme/yeniden kurulum
- 🚨 Sunucu değişikliği
- ⚠️ Konfigürasyon hatası
- 🔄 Yeni sunucuya taşıma
- 📊 Ayar karşılaştırması

---

### 2️⃣ **HTML Site Yedeği** (Web Sayfası İçeriği)
```
📁 Dosyalar: 
   - hurriyet-saglik-fixed-template.html (15KB) ⭐ ANA DOSYA
   - hurriyet-health-form-fix.html (7.7KB)
📊 Toplam: ~23KB
📅 Tarih: 2025-10-14
🎨 Tür:   Frontend/Görsel İçerik
```

**İçinde Ne Var:**
```
✅ HTML yapısı ve içerik
✅ CSS stilleri (inline + external)
✅ JavaScript kodları
✅ N8N Webhook entegrasyonu
✅ Facebook Pixel (1536997377317312)
✅ Form validasyonu
✅ Mobil responsive tasarım
✅ Ürün bilgileri ve görseller
```

**Ne İşe Yarar:**
- 🎨 Sayfa tasarımı ve görünümü
- 📝 İçerik (yazılar, başlıklar)
- 🖼️ Görseller ve layout
- 📱 Mobil uyumluluk
- 🔗 Webhook bağlantıları
- 📊 Facebook Pixel tracking
- 💰 Fiyat ve ürün bilgileri

**Ne Zaman Kullanılır:**
- 🎨 Tasarım değişikliği sonrası geri dönüş
- 📝 İçerik güncelleme hatası
- 🔗 Webhook URL değişikliği
- 🐛 JavaScript hata düzeltme
- 🆕 Yeni sayfa versiyonu karşılaştırması

---

## 🔀 KARŞILAŞTIRMA TABLOSU

| Özellik | NGINX Yedeği | HTML Yedeği |
|---------|--------------|-------------|
| **Dosya Tipi** | `.tar.gz` (arşiv) | `.html` (metin) |
| **Boyut** | 1.5MB | 23KB |
| **İçerik** | Sunucu ayarları | Sayfa içeriği |
| **Etki Alanı** | Backend/Güvenlik | Frontend/Görsel |
| **Düzenleme** | `sudo` gerekli | Basit text editor |
| **Geri Yükleme** | `tar` komutu + restart | Dosya kopyalama |
| **Sıklık** | Aylık (az değişir) | Sık (içerik güncellemeleri) |
| **Kritiklik** | 🔴 Yüksek (sistem) | 🟡 Orta (içerik) |

---

## 🎯 KULLANIM SENARYOLARI

### Senaryo 1: NGINX Ayarlarında Sorun
```bash
# NGINX yedeğini kullan
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C /
sudo nginx -c /etc/nginx-hurriyet/nginx.conf -t
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)
```

### Senaryo 2: Web Sayfası Bozuldu
```bash
# HTML yedeğini kullan
cd /home/root/webapp
sudo cp hurriyet-saglik-fixed-template.html /var/www/hurriyet-health/index.html
# Tarayıcıda test et: https://hüriyetsagliksonnhaberler.site
```

### Senaryo 3: Hem NGINX Hem HTML Sorunu
```bash
# 1. Önce NGINX'i düzelt
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C /
sudo nginx -c /etc/nginx-hurriyet/nginx.conf -t
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)

# 2. Sonra HTML'i düzelt
sudo cp hurriyet-saglik-fixed-template.html /var/www/hurriyet-health/index.html
```

---

## 📂 DOSYA YERLEŞİMİ

```
/home/root/webapp/
├── 📦 NGINX YEDEK
│   └── hurriyet-nginx-backup-2025-10-14.tar.gz (1.5MB)
│
├── 🎨 HTML YEDEKLER
│   ├── hurriyet-saglik-fixed-template.html (15KB) ⭐ ANA
│   └── hurriyet-health-form-fix.html (7.7KB)
│
└── 📚 DOKÜMANTASYON
    ├── HURRIYET_SAGLIK_TRAFIK_KONTROL_SUNUMU.md (39KB)
    ├── HURRIYET_YEDEKLEME_DOKUMANI.md
    ├── YEDEKLEME_AYRIM_DOKUMANI.md (BU DOSYA)
    └── ... (8 diğer dokuman)
```

---

## 🔍 HIZLI KONTROL

### NGINX Yedeğini İnceleme
```bash
# İçeriği listele
tar -tzf hurriyet-nginx-backup-2025-10-14.tar.gz

# Sadece nginx.conf'u oku (geri yüklemeden)
tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz --to-stdout etc/nginx-hurriyet/nginx.conf | less
```

### HTML Yedeğini İnceleme
```bash
# Dosyayı görüntüle
cat hurriyet-saglik-fixed-template.html | less

# Webhook URL'lerini kontrol et
grep -n "WEBHOOK_URL" hurriyet-saglik-fixed-template.html

# Facebook Pixel ID'yi bul
grep -n "fbq.*init" hurriyet-saglik-fixed-template.html
```

---

## 💡 ÖNEMLİ NOTLAR

### ⚠️ NGINX Yedeği İçin
- **Root yetkisi gerekli**: `sudo` kullanmalısın
- **Sistem dosyalarını etkiler**: `/etc/` dizini
- **NGINX restart gerekli**: Değişikliklerin aktif olması için
- **Test zorunlu**: Geri yüklemeden önce `nginx -t` yap
- **GeoIP veritabanı dahil**: 1.4MB boyutunda

### ⚠️ HTML Yedeği İçin
- **Root yetkisi minimal**: Dosya kopyalama için yeterli
- **Anında etki**: Sayfa yenilediğinde görünür
- **Webhook URL'leri kritik**: N8N bağlantılarını koru
- **Facebook Pixel ID**: 1536997377317312 (değiştirme!)
- **Mobil uyumlu**: Responsive tasarım mevcut

---

## 🔄 YEDEKLEME STRATEJİSİ

### NGINX Yedeği (Aylık)
```bash
# Her ayın 1'inde otomatik
0 3 1 * * cd /home/root/webapp && tar -czf hurriyet-nginx-backup-$(date +\%Y-\%m-\%d).tar.gz -C / etc/nginx-hurriyet/ usr/share/GeoIP/GeoIP.dat
```

### HTML Yedeği (Her Değişiklikte)
```bash
# Manuel - her HTML düzenlemesinden önce
cd /home/root/webapp
cp hurriyet-saglik-fixed-template.html hurriyet-saglik-backup-$(date +%Y-%m-%d-%H%M).html
```

---

## 🆘 ACİL DURUM REHBERİ

### Problem: Site açılmıyor (NGINX hatası)
```bash
✅ Çözüm: NGINX yedeğini kullan
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C /
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)
```

### Problem: Sayfa bozuk görünüyor (HTML hatası)
```bash
✅ Çözüm: HTML yedeğini kullan
cd /home/root/webapp
sudo cp hurriyet-saglik-fixed-template.html /var/www/hurriyet-health/index.html
```

### Problem: Form çalışmıyor (Webhook hatası)
```bash
✅ Çözüm: HTML'deki webhook URL'lerini kontrol et
grep "WEBHOOK_URL" hurriyet-saglik-fixed-template.html
# Eğer yanlışsa HTML yedeğini geri yükle
```

### Problem: Geo-blocking çalışmıyor
```bash
✅ Çözüm: NGINX yedeğindeki GeoIP'yi geri yükle
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C / usr/share/GeoIP/GeoIP.dat
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)
```

---

## 📊 YEDEKLEME KONTROL LİSTESİ

### ✅ NGINX Yedeği Kontrol
```
□ nginx.conf var mı?
□ hurriyet-health konfigürasyonu var mı?
□ GeoIP.dat veritabanı var mı?
□ Boyut ~1.5MB civarında mı?
□ Test edildi mi? (tar -tzf)
```

### ✅ HTML Yedeği Kontrol
```
□ hurriyet-saglik-fixed-template.html var mı?
□ Boyut ~15KB civarında mı?
□ Webhook URL'leri doğru mu?
□ Facebook Pixel ID mevcut mu?
□ Tarayıcıda açılıyor mu?
```

---

## 🔗 İLGİLİ DOSYALAR

- **NGINX Yedekleme Detayı**: `HURRIYET_YEDEKLEME_DOKUMANI.md`
- **Güvenlik Katmanları**: `HURRIYET_COMPLETE_SECURITY_SUMMARY.md`
- **Trafik Kontrol Sunumu**: `HURRIYET_SAGLIK_TRAFIK_KONTROL_SUNUMU.md`
- **Hızlı Referans**: `HURRIYET_QUICK_REFERENCE.md`

---

## 📞 ÖZET

**İKİ AYRI YEDEK, İKİ FARKLI İŞLEV:**

1. **NGINX Yedeği** = Sunucu motoru (güvenlik, kurallar, yönlendirme)
2. **HTML Yedeği** = Web sayfası (tasarım, içerik, görünüm)

**İkisi de önemli ama farklı amaçlara hizmet ediyor!**

- 🔧 Sunucu problemi → NGINX yedeği
- 🎨 Sayfa problemi → HTML yedeği
- 🚨 Her ikisi de sorunlu → Her ikisini de geri yükle

---

**Son Güncelleme**: 2025-10-14  
**Versiyon**: 1.0  
**Durum**: ✅ Her iki yedek türü de mevcut ve dokümante edildi
