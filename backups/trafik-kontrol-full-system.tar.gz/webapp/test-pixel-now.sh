#!/bin/bash

echo "══════════════════════════════════════════════════════════"
echo "🧪 FACEBOOK PIXEL TEST"
echo "══════════════════════════════════════════════════════════"
echo ""
echo "Test URL: https://hüriyetsagliksonnhaberler.site/?fbclid=test123"
echo ""
echo "Pixel'i test ediyoruz..."
echo ""

# Test the page with mobile user agent
curl -s -A "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)" \
  "https://xn--hriyetsaglksonnhaberler-65c29b.site/?fbclid=test123" \
  -o /tmp/pixel_test.html

# Check if pixel code exists
if grep -q "1536997377317312" /tmp/pixel_test.html; then
    echo "✅ Pixel kodu sayfada var!"
    echo ""
    grep -o "fbq('init'.*)" /tmp/pixel_test.html | head -1
    echo ""
else
    echo "❌ Pixel kodu sayfada bulunamadı!"
    exit 1
fi

# Check for fbq track calls
echo "Event Tracking Kontrol:"
if grep -q "fbq('track', 'PageView')" /tmp/pixel_test.html; then
    echo "  ✅ PageView event var"
fi
if grep -q "fbq('track', 'ViewContent')" /tmp/pixel_test.html; then
    echo "  ✅ ViewContent event var"
fi
if grep -q "fbq('track', 'Lead')" /tmp/pixel_test.html; then
    echo "  ✅ Lead event var"
fi

echo ""
echo "══════════════════════════════════════════════════════════"
echo "📊 SONRAKİ ADIM:"
echo "══════════════════════════════════════════════════════════"
echo ""
echo "1. Facebook Pixel Helper extension ile test et:"
echo "   https://hüriyetsagliksonnhaberler.site/?fbclid=test123"
echo ""
echo "2. Events Manager → Test Events sekmesine git"
echo ""
echo "3. Test trafiğini göreceksin!"
echo ""
echo "══════════════════════════════════════════════════════════"

rm /tmp/pixel_test.html
