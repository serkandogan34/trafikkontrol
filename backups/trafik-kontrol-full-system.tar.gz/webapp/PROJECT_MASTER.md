# 🗂️ PROJECT MASTER - Tüm Projeler Merkez Dosyası

**Son Güncelleme**: 2025-10-14 16:35  
**Aktif Projeler**: 3  
**Sandbox Konum**: `/home/root/webapp/`

---

## 📋 PROJE LİSTESİ

1. **TRAFIK** - Traffic Management Platform (Node.js Web App)
2. **GARANTÖR** - Garantör Landing/Web (Ana NGINX kullanıyor)
3. **HÜRRIYET** - Hürriyet Sağlık Landing Page (Ayrı NGINX)

---

## 🎯 1. TRAFIK - Traffic Management Platform

**Durum**: 🟢 Aktif (Geliştirme)  
**Konum**: `/home/root/webapp/`  
**Tip**: Node.js + React Hybrid Web Application  
**Port**: 3000

### NGINX Yapısı:
```
Ana NGINX: /etc/nginx/
Sites:
  - trafik-kontrol
  - traffic-subdomain (traffic.garantor360.com)
```

### Teknoloji Stack:
- Node.js + Express
- React (Hybrid system)
- PM2 (Process manager)
- JSON-based storage (No Cloudflare)
- WebSocket + SSE

### Özellikler:
- Domain Management
- Traffic Analytics
- DNS Management
- NGINX Config Generator
- AI Bot Detection
- Security Center
- Real-time Monitoring

### Kritik Dosyalar:
```
/home/root/webapp/
├── src/              (Kaynak kodlar)
├── public/           (Static files)
├── dist/             (Build)
├── package.json
├── README.md
└── ecosystem.config.js (PM2)
```

### Son Durum:
- Version 3 Complete
- No Cloudflare dependencies
- Production ready
- PM2 ile çalışıyor

---

## 🏢 2. GARANTÖR - Garantör Projesi

**Durum**: 🟡 Belirsiz (Trafik domaini kullanıyor)  
**Domain**: garantor360.com  
**NGINX**: /etc/nginx/ (Ana NGINX - Trafik ile paylaşımlı)

### NGINX Yapısı:
```
Ana NGINX: /etc/nginx/
Sites:
  - garantor360-main
  - garantor360-traffic
```

### Önemli Not:
⚠️ Bu proje yanlışlıkla Trafik'in domaini kullanıyor
⚠️ Trafik ile aynı NGINX yapısında
⚠️ Ayrıştırma gerekebilir

### Kritik Dosyalar:
```
Root: /var/www/html/
Fallback: /traffic-admin/
```

### İncelenmesi Gereken:
- [ ] Gerçek proje konumu
- [ ] Garantör'ün kendi dosyaları nerede?
- [ ] Trafik ile bağımlılığı nasıl?

---

## 🏥 3. HÜRRIYET - Hürriyet Sağlık Landing Page

**Durum**: 🟢 Aktif (Production)  
**Konum**: `/home/root/webapp/`  
**Domain**: hüriyetsagliksonnhaberler.site  
**Versiyon**: 2.0

### NGINX Yapısı:
```
AYRI NGINX: /etc/nginx-hurriyet/
Sites:
  - hurriyet-health
PID: /var/run/nginx-hurriyet.pid
Workers: 8
Port: 80, 443
```

### Güvenlik Katmanları: 8 LAYER
1. ✅ SSL/TLS Encryption
2. ✅ Geo-Blocking (TR + International FB)
3. ✅ Rate Limiting (DDoS Protection)
4. ✅ Mobile-Only Access
5. ✅ Facebook Referrer Check
6. ✅ Admin IP Bypass (85.98.16.30)
7. ✅ Secure Access Key System
8. ✅ fbclid Kontrolü

### Kritik Dosyalar:
```
Kaynak (Backup):
  /home/root/webapp/hurriyet-saglik-fixed-template.html (22KB)

Production:
  /var/www/html/index.html (22KB)

NGINX Config:
  /etc/nginx-hurriyet/sites-available/hurriyet-health

Yedek:
  /home/root/webapp/hurriyet-nginx-backup-2025-10-14.tar.gz (1.5MB)

Webhook:
  Production: https://n8nwork.dtekai.com/webhook/bc74f59e-54c2-4521-85a1-6e21a0438c31
  Test: https://n8nwork.dtekai.com/webhook-test/bc74f59e-54c2-4521-85a1-6e21a0438c31
```

### Önemli Bilgiler:
```
Access Key: HUR2024_SecureTest_9K3mP7xQ
Admin IP: 85.98.16.30
Facebook Pixel: 1536997377317312
SSL: Let's Encrypt (Geçerli: 2026-01-10)
```

### Son Yapılanlar:
- ✅ fbclid kontrolü eklendi (2025-10-14)
- ✅ Güvenli access key sistemi (2025-10-14)
- ✅ Rakip analizi yapıldı
- ✅ 15 dokümantasyon dosyası
- ⏳ Token sistemi (ertelendi)

### Dokümantasyon (15 dosya):
```
SECURE_ACCESS_KEY_DOKUMANI.md
FBCLID_KONTROL_TEST_RAPORU.md
RAKIP_ANALIZ_VE_STRATEJI.md
HURRIYET_SAGLIK_TRAFIK_KONTROL_SUNUMU.md
HURRIYET_COMPLETE_SECURITY_SUMMARY.md
HURRIYET_GEO_BLOCKING_DOCUMENTATION.md
HURRIYET_IMPLEMENTATION_REPORT.md
HURRIYET_RATE_LIMITING_DOCUMENTATION.md
HURRIYET_RATE_LIMITING_VISUAL.md
HURRIYET_README.md
HURRIYET_QUICK_REFERENCE.md
HURRIYET_YEDEKLEME_DOKUMANI.md
YEDEKLEME_AYRIM_DOKUMANI.md
NGINX_CONFIGURATION_VERIFICATION.md
HURRIYET_SAGLIK_FIX_GUIDE.md
```

---

## 🏗️ NGINX YAPISI ÖZET

### Ana NGINX (/etc/nginx/):
```
Kullanılan Projeler:
  • TRAFIK (trafik-kontrol, traffic-subdomain)
  • GARANTÖR (garantor360-main, garantor360-traffic)

Sites Available:
  - default
  - garantor360-main
  - garantor360-traffic
  - hurriyet-health (eski, kullanılmıyor)
  - traffic-subdomain
  - trafik-kontrol
  - tv-servis
```

### Hürriyet NGINX (/etc/nginx-hurriyet/):
```
Kullanılan Projeler:
  • HÜRRIYET (hurriyet-health)

Sites Available:
  - hurriyet-health (aktif)
  - example-multi-sites (örnek)

Process ID: 482086
Workers: 8
Ports: 80, 443
```

### Kritik Ayrım:
⚠️ **TRAFIK ve GARANTÖR** → Aynı NGINX (/etc/nginx/)  
✅ **HÜRRIYET** → Ayrı NGINX (/etc/nginx-hurriyet/)

---

## 📁 DOSYA KONUMLARI

### Kodlar:
```
/home/root/webapp/
├── 📂 src/                    (Trafik kaynak kodları)
├── 📂 public/                 (Trafik static files)
├── 📂 dist/                   (Trafik build)
├── 📄 hurriyet-saglik-*.html  (Hürriyet HTML)
├── 📄 package.json            (Trafik npm)
└── 📄 *.md                    (Dokümantasyon - 23 adet)
```

### Production:
```
/var/www/html/
└── index.html                 (Hürriyet Production)
```

### NGINX:
```
/etc/nginx/                    (Ana - Trafik+Garantör)
/etc/nginx-hurriyet/           (Ayrı - Hürriyet)
```

### Yedekler:
```
/home/root/webapp/
└── hurriyet-nginx-backup-2025-10-14.tar.gz (1.5MB)
```

---

## 🎯 HIZLI ERİŞİM

### Projeye Devam Etmek İçin:
```
TRAFIK projesine devam:
  → Read: PROJECT_MASTER.md
  → Read: TRAFIK_PROJECT_STATE.md (oluşturulacak)

GARANTÖR projesine devam:
  → Read: PROJECT_MASTER.md
  → Read: GARANTOR_PROJECT_STATE.md (oluşturulacak)

HÜRRIYET projesine devam:
  → Read: PROJECT_MASTER.md
  → Read: HURRIYET_PROJECT_STATE.md (oluşturulacak)
```

### Yeni Proje Eklemek İçin:
```
"Yeni proje: [İSİM]"
  → Yeni proje dalı açılır
  → [İSİM]_PROJECT_STATE.md oluşturulur
  → PROJECT_MASTER.md güncellenir
```

---

## ⚠️ UYARILAR

### 1. NGINX Karışıklığı:
- Ana NGINX'te 2 proje var (Trafik + Garantör)
- Hürriyet kendi NGINX'inde
- Değişiklik yaparken hangi NGINX olduğuna DİKKAT!

### 2. Garantör Belirsizliği:
- Garantör'ün tam dosya konumu belirsiz
- Trafik domaini kullanıyor
- İleride ayrıştırma gerekebilir

### 3. Yedekleme:
- Sadece Hürriyet'in NGINX yedeği var
- Trafik ve Garantör için yedek YOK
- Trafik için yedek oluşturulmalı

---

## 📞 KULLANIM TALİMATI

### Oturum Başında:
1. Bu dosyayı oku: `Read PROJECT_MASTER.md`
2. Proje-specific dosyayı oku: `Read [PROJE]_PROJECT_STATE.md`
3. Son durumu hatırla ve devam et

### Oturum Sonunda:
1. Proje-specific dosyayı güncelle
2. Gerekirse PROJECT_MASTER.md'yi güncelle
3. Yedekleri kontrol et

---

**Oluşturulma**: 2025-10-14 16:35  
**Oluşturan**: AI Assistant  
**Amaç**: Tüm projeler için merkezi hafıza sistemi
