# 💾 Hürriyet Sağlık NGINX Yedekleme Rehberi

**Son Yedekleme**: 2025-10-14  
**Yedek Dosyası**: `hurriyet-nginx-backup-2025-10-14.tar.gz`  
**Boyut**: 1.5MB

---

## 📦 Yedekte Ne Var?

```
✅ etc/nginx-hurriyet/nginx.conf                    (Ana NGINX ayarları)
✅ etc/nginx-hurriyet/sites-available/hurriyet-health (Güvenlik kuralları)
✅ etc/nginx-hurriyet/sites-enabled/hurriyet-health   (Aktif site linki)
✅ usr/share/GeoIP/GeoIP.dat                          (GeoIP veritabanı - 1.4MB)
```

---

## 🔄 Yedekten Geri Yükleme

### Senaryo 1: Tek Dosya Geri Yükleme
```bash
# Sadece nginx.conf'u geri yükle
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C / etc/nginx-hurriyet/nginx.conf

# NGINX'i test et ve restart et
sudo nginx -c /etc/nginx-hurriyet/nginx.conf -t
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)
```

### Senaryo 2: Tam Geri Yükleme
```bash
# Tüm dosyaları geri yükle
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C /

# NGINX'i restart et
sudo nginx -c /etc/nginx-hurriyet/nginx.conf -t
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)
```

### Senaryo 3: Yeni Sunucuya Kurulum
```bash
# 1. NGINX'i kur
sudo apt update && sudo apt install -y nginx libnginx-mod-http-geoip geoip-database

# 2. Yedek dosyasını yeni sunucuya kopyala
scp hurriyet-nginx-backup-2025-10-14.tar.gz user@new-server:/tmp/

# 3. Yeni sunucuda geri yükle
cd /tmp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C /

# 4. NGINX'i başlat
sudo nginx -c /etc/nginx-hurriyet/nginx.conf -t
sudo nginx -c /etc/nginx-hurriyet/nginx.conf
```

---

## 📅 Düzenli Yedekleme Planı

### Manuel Yedekleme Komutu
```bash
cd /home/root/webapp
sudo tar -czf hurriyet-nginx-backup-$(date +%Y-%m-%d).tar.gz \
  -C / \
  etc/nginx-hurriyet/ \
  usr/share/GeoIP/GeoIP.dat
```

### Otomatik Aylık Yedekleme (Crontab)
```bash
# Crontab'a ekle (her ayın 1'inde saat 03:00'te)
0 3 1 * * cd /home/root/webapp && tar -czf hurriyet-nginx-backup-$(date +\%Y-\%m-\%d).tar.gz -C / etc/nginx-hurriyet/ usr/share/GeoIP/GeoIP.dat
```

---

## 🔍 Yedek Dosyasını İnceleme

```bash
# İçeriği listele
tar -tzf hurriyet-nginx-backup-2025-10-14.tar.gz

# Sadece nginx.conf'u oku (geri yüklemeden)
tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz --to-stdout etc/nginx-hurriyet/nginx.conf | less

# Site konfigürasyonunu oku
tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz --to-stdout etc/nginx-hurriyet/sites-available/hurriyet-health | less
```

---

## 💡 Önemli Notlar

### ⚠️ SSL Sertifikaları
- SSL sertifikaları (`/etc/letsencrypt/`) yedekte **YOK**
- Çünkü Let's Encrypt otomatik yeniliyor
- Yeni sunucuda `certbot` ile yeniden oluştur:
  ```bash
  sudo certbot --nginx -d hüriyetsagliksonnhaberler.site
  ```

### 🌍 GeoIP Veritabanı
- Mevcut veritabanı: **Nisan 2024** versiyonu
- Güncelleme: [MaxMind GeoLite2](https://dev.maxmind.com/geoip/geolite2-free-geolocation-data)
- Yeni veritabanı için:
  ```bash
  sudo apt update && sudo apt install -y geoip-database
  ```

### 🔐 Dosya İzinleri
- Yedek dosyası: `root:root` (sadece admin erişebilir)
- Geri yüklemeden sonra izinleri kontrol et:
  ```bash
  sudo chown -R root:root /etc/nginx-hurriyet/
  sudo chmod 644 /etc/nginx-hurriyet/nginx.conf
  sudo chmod 644 /etc/nginx-hurriyet/sites-available/hurriyet-health
  ```

---

## 📊 Yedekleme Kontrol Listesi

```
✅ nginx.conf (Ana ayarlar)
✅ hurriyet-health (Site konfigürasyonu)
✅ GeoIP.dat (Ülke veritabanı)
✅ Dokümantasyon dosyaları (10 adet .md dosyası)
❌ SSL sertifikaları (Let's Encrypt otomatik)
❌ Log dosyaları (gerekirse ayrı yedekle)
```

---

## 🆘 Acil Durum Senaryoları

### Problem 1: NGINX Çalışmıyor
```bash
# 1. Yedeği geri yükle
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C /

# 2. Test et
sudo nginx -c /etc/nginx-hurriyet/nginx.conf -t

# 3. Yeniden başlat
sudo systemctl restart nginx-hurriyet
```

### Problem 2: GeoIP Çalışmıyor
```bash
# GeoIP veritabanını geri yükle
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C / usr/share/GeoIP/GeoIP.dat

# NGINX'i reload et
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)
```

### Problem 3: Rate Limiting Sorunlu
```bash
# nginx.conf'u geri yükle (rate limit ayarları burada)
cd /home/root/webapp
sudo tar -xzf hurriyet-nginx-backup-2025-10-14.tar.gz -C / etc/nginx-hurriyet/nginx.conf

# Test ve reload
sudo nginx -c /etc/nginx-hurriyet/nginx.conf -t
sudo kill -HUP $(cat /var/run/nginx-hurriyet.pid)
```

---

## 🔗 İlgili Dosyalar

- **Dokümantasyon**: Tüm `.md` dosyaları `/home/root/webapp/` klasöründe
- **Ana Sunum**: `HURRIYET_SAGLIK_TRAFIK_KONTROL_SUNUMU.md`
- **Hızlı Referans**: `HURRIYET_QUICK_REFERENCE.md`
- **Status Check Script**: `check-hurriyet-status.sh`

---

## 📞 Destek

Yedekleme veya geri yükleme konusunda sorun olursa:
1. `HURRIYET_QUICK_REFERENCE.md` dosyasına bak
2. NGINX loglarını kontrol et: `/etc/nginx-hurriyet/logs/error.log`
3. Status script'i çalıştır: `bash check-hurriyet-status.sh`

---

**Son Güncelleme**: 2025-10-14  
**Versiyon**: 1.0  
**Durum**: ✅ Yedek başarıyla oluşturuldu
