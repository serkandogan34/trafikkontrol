/**
 * HÜRRIYET SAĞLIK - FORM CONTAINER DÜZELTME SCRIPT'İ
 * Bu script form container'ın sol-sağ bölünme sorununu dinamik olarak çözer
 */

(function() {
    'use strict';
    
    // DOM yüklendiğinde çalışır
    function fixFormContainer() {
        console.log('Form container düzeltmeleri başlatılıyor...');
        
        // Form container'ları bul ve düzelt
        const formContainers = document.querySelectorAll('.form-container');
        
        formContainers.forEach(function(container, index) {
            console.log('Form container düzeltiliyor: ' + (index + 1));
            
            // Container stillerini düzelt
            container.style.width = '100%';
            container.style.maxWidth = '100%';
            container.style.margin = '0 auto';
            container.style.padding = '0';
            container.style.boxSizing = 'border-box';
            container.style.display = 'block';
            container.style.clear = 'both';
            container.style.float = 'none';
            container.style.position = 'static';
            container.style.overflow = 'visible';
            
            // İç div'leri düzelt
            const innerDivs = container.querySelectorAll('div');
            innerDivs.forEach(function(div) {
                div.style.boxSizing = 'border-box';
                div.style.clear = 'both';
                div.style.display = 'block';
                if (!div.classList.contains('form-row')) {
                    div.style.width = '100%';
                    div.style.float = 'none';
                }
            });
        });
        
        // Order form section'ları düzelt
        const orderFormSections = document.querySelectorAll('.order-form-section');
        
        orderFormSections.forEach(function(section, index) {
            console.log('Order form section düzeltiliyor: ' + (index + 1));
            
            section.style.maxWidth = '800px';
            section.style.width = '800px';
            section.style.margin = '40px auto';
            section.style.padding = '20px';
            section.style.boxSizing = 'border-box';
            section.style.display = 'block';
            section.style.clear = 'both';
            section.style.float = 'none';
            section.style.position = 'relative';
        });
        
        // Scientific results ve campaign sections'ı da düzelt
        const scientificResults = document.querySelectorAll('.scientific-results');
        const campaignSections = document.querySelectorAll('.campaign-section');
        
        scientificResults.forEach(function(section) {
            section.style.maxWidth = '800px';
            section.style.width = '800px';
            section.style.margin = '40px auto';
            section.style.padding = '0 20px';
            section.style.boxSizing = 'border-box';
        });
        
        campaignSections.forEach(function(section) {
            section.style.maxWidth = '800px';
            section.style.width = '800px';
            section.style.margin = '40px auto';
            section.style.padding = '0 20px';
            section.style.boxSizing = 'border-box';
        });
        
        // Teaser'ları düzelt
        const teasers = document.querySelectorAll('.tv-teaser-simple-new');
        
        teasers.forEach(function(teaser, index) {
            console.log('Teaser düzeltiliyor: ' + (index + 1));
            
            teaser.style.width = '800px';
            teaser.style.maxWidth = '90%';
            teaser.style.margin = '40px auto';
            teaser.style.padding = '0 20px';
            teaser.style.boxSizing = 'border-box';
            
            // Arrow'ları kaldır
            const arrows = teaser.querySelectorAll('.red-arrow, .yellow-arrow, .white-arrow');
            arrows.forEach(function(arrow) {
                arrow.style.display = 'none';
                arrow.style.visibility = 'hidden';
                arrow.style.opacity = '0';
            });
        });
        
        // Broken HTML yapısını tespit et ve düzelt
        fixBrokenHTMLStructure();
        
        console.log('Form container düzeltmeleri tamamlandı.');
    }
    
    // Bozuk HTML yapısını düzelt
    function fixBrokenHTMLStructure() {
        console.log('Bozuk HTML yapısı kontrol ediliyor...');
        
        // Açık kalmış div'leri tespit et
        const allDivs = document.querySelectorAll('div');
        
        // Form container içindeki yapıyı yeniden düzenle
        const orderFormSection = document.querySelector('.order-form-section');
        
        if (orderFormSection) {
            // Mevcut form container'ı bul
            let formContainer = orderFormSection.querySelector('.form-container');
            
            if (!formContainer) {
                // Form container yoksa oluştur
                formContainer = document.createElement('div');
                formContainer.className = 'form-container';
                
                // Mevcut içeriği form container'a taşı
                const children = Array.from(orderFormSection.children);
                children.forEach(function(child) {
                    if (!child.classList.contains('form-container')) {
                        formContainer.appendChild(child);
                    }
                });
                
                orderFormSection.appendChild(formContainer);
            }
            
            // Form content div'i ekle veya düzelt
            let formContent = formContainer.querySelector('.form-content');
            
            if (!formContent) {
                formContent = document.createElement('div');
                formContent.className = 'form-content';
                
                // Mevcut içeriği form content'e taşı
                const children = Array.from(formContainer.children);
                children.forEach(function(child) {
                    if (!child.classList.contains('form-content')) {
                        formContent.appendChild(child);
                    }
                });
                
                formContainer.appendChild(formContent);
            }
            
            console.log('HTML yapısı yeniden düzenlendi.');
        }
    }
    
    // CSS ekle
    function addFixCSS() {
        const style = document.createElement('style');
        style.textContent = `
            /* Form Container Düzeltme CSS'i */
            .order-form-section {
                max-width: 800px !important;
                width: 800px !important;
                margin: 40px auto !important;
                padding: 20px !important;
                box-sizing: border-box !important;
                display: block !important;
                clear: both !important;
                float: none !important;
                position: relative !important;
            }
            
            .form-container {
                width: 100% !important;
                max-width: 100% !important;
                margin: 0 auto !important;
                padding: 0 !important;
                box-sizing: border-box !important;
                display: block !important;
                clear: both !important;
                float: none !important;
                position: static !important;
                overflow: visible !important;
            }
            
            .form-content {
                width: 100% !important;
                padding: 20px !important;
                box-sizing: border-box !important;
                background: white;
                border-radius: 8px;
                margin: 0 !important;
                display: block !important;
                clear: both !important;
                float: none !important;
            }
            
            .scientific-results,
            .campaign-section {
                max-width: 800px !important;
                width: 800px !important;
                margin: 40px auto !important;
                padding: 0 20px !important;
                box-sizing: border-box !important;
            }
            
            .tv-teaser-simple-new {
                width: 800px !important;
                max-width: 90% !important;
                margin: 40px auto !important;
                padding: 0 20px !important;
                box-sizing: border-box !important;
            }
            
            /* Arrow'ları kaldır */
            .tv-teaser-simple-new .red-arrow,
            .tv-teaser-simple-new .yellow-arrow,
            .tv-teaser-simple-new .white-arrow,
            .tv-teaser-simple-new::before,
            .tv-teaser-simple-new::after {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
            }
            
            @media (max-width: 768px) {
                .order-form-section,
                .scientific-results,
                .campaign-section,
                .tv-teaser-simple-new {
                    max-width: 95% !important;
                    width: auto !important;
                }
            }
        `;
        document.head.appendChild(style);
    }
    
    // Script'i başlat
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            addFixCSS();
            fixFormContainer();
        });
    } else {
        addFixCSS();
        fixFormContainer();
    }
    
    // Sayfa tamamen yüklendikten sonra tekrar kontrol et
    window.addEventListener('load', function() {
        setTimeout(fixFormContainer, 1000);
    });
    
})();