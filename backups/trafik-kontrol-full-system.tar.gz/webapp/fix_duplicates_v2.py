#!/usr/bin/env python3
"""
Fix duplicate function declarations in dashboard.js
Removes earlier versions and keeps the later, more complete implementations
"""

import re
import os

def find_function_ranges(content, function_name):
    """Find all occurrences of a function and return their line ranges"""
    lines = content.split('\n')
    ranges = []
    
    # Look for function declarations
    patterns = [
        rf'^function\s+{function_name}\s*\(',
        rf'^async\s+function\s+{function_name}\s*\('
    ]
    
    for i, line in enumerate(lines):
        for pattern in patterns:
            if re.search(pattern, line.strip()):
                # Find the end of this function
                brace_count = 0
                start_found = False
                end_line = i
                
                # Look for opening brace and count braces to find function end
                for j in range(i, len(lines)):
                    current_line = lines[j].strip()
                    
                    # Count braces
                    open_braces = current_line.count('{')
                    close_braces = current_line.count('}')
                    
                    if open_braces > 0:
                        start_found = True
                        brace_count += open_braces
                    
                    if start_found:
                        brace_count -= close_braces
                        
                        # Function ends when brace count returns to 0
                        if brace_count <= 0:
                            end_line = j
                            break
                
                ranges.append((i, end_line, f"Line {i+1}: {line.strip()[:100]}..."))
                
    return ranges

def remove_duplicate_functions(file_path):
    """Remove duplicate function declarations from dashboard.js"""
    
    # Functions to deduplicate (keep later versions)
    duplicate_functions = [
        'showDomainIPManagement',
        'showDomainGeoTimeControls', 
        'updateGeographicControls',
        'updateTimeControls',
        'updateCampaignSettings',
        'loadTrafficData',
        'loadDNSRecords',
        'deleteDNSRecord'
    ]
    
    print(f"Reading {file_path}...")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    lines = content.split('\n')
    lines_to_remove = set()
    
    print("\nAnalyzing duplicate functions...")
    
    for func_name in duplicate_functions:
        print(f"\n--- Analyzing {func_name} ---")
        ranges = find_function_ranges(content, func_name)
        
        if len(ranges) > 1:
            print(f"Found {len(ranges)} copies:")
            for i, (start, end, sample) in enumerate(ranges):
                print(f"  Copy {i+1}: Lines {start+1}-{end+1} - {sample}")
            
            # Keep the last (most complete) version, remove earlier ones
            for start, end, _ in ranges[:-1]:  # All except the last one
                for line_num in range(start, end + 1):
                    lines_to_remove.add(line_num)
                print(f"  -> Marked lines {start+1}-{end+1} for removal")
            
            print(f"  -> Keeping final version at lines {ranges[-1][0]+1}-{ranges[-1][1]+1}")
        else:
            print(f"Only {len(ranges)} copy found - no duplicates to remove")
    
    # Remove marked lines
    if lines_to_remove:
        print(f"\nRemoving {len(lines_to_remove)} duplicate lines...")
        clean_lines = []
        for i, line in enumerate(lines):
            if i not in lines_to_remove:
                clean_lines.append(line)
        
        # Write cleaned content
        clean_content = '\n'.join(clean_lines)
        
        # Create backup
        backup_path = file_path + '.backup-dedup'
        with open(backup_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Backup created: {backup_path}")
        
        # Write cleaned file
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(clean_content)
        
        print(f"✅ Successfully removed {len(lines_to_remove)} duplicate lines")
        print(f"   Original: {len(lines)} lines")
        print(f"   Cleaned:  {len(clean_lines)} lines")
        print(f"   Saved:    {len(lines) - len(clean_lines)} lines")
    else:
        print("\n✅ No duplicate lines found to remove")
    
    return len(lines_to_remove) > 0

if __name__ == "__main__":
    dashboard_path = "/home/user/webapp/public/static/dashboard.js"
    
    if os.path.exists(dashboard_path):
        success = remove_duplicate_functions(dashboard_path)
        if success:
            print(f"\n🎉 Duplicate function cleanup completed successfully!")
        else:
            print(f"\n✨ File was already clean - no changes needed!")
    else:
        print(f"❌ Error: {dashboard_path} not found")