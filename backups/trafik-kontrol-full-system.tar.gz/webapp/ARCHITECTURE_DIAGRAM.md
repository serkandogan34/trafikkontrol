# Hürriyet Dashboard - System Architecture

## 🏗️ Complete System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        META ADS MANAGER (Facebook)                          │
│                                                                             │
│  Campaign: manual-krem-geleneksel-2                                        │
│  Budget: 282 TL | CTR: 2.81% | CPC: 1.46 TL                                │
│                                                                             │
│  Generates: fbclid parameters, UTM tracking                                │
└─────────────────────────────┬───────────────────────────────────────────────┘
                              │
                              │ User clicks ad
                              ↓
┌─────────────────────────────────────────────────────────────────────────────┐
│                    FACEBOOK MOBILE APP (96% of traffic)                     │
│                                                                             │
│  Opens URL: https://hürriyetrehberhaber.store/?fbclid=IwZXh...             │
└─────────────────────────────┬───────────────────────────────────────────────┘
                              │
                              │ HTTP/2 request
                              ↓
┌─────────────────────────────────────────────────────────────────────────────┐
│                         NGINX SERVER (8 Security Layers)                    │
│  Location: /etc/nginx-hurriyet/                                            │
│                                                                             │
│  Layer 1: SSL/TLS (HTTPS only)                                             │
│  Layer 2: GeoIP blocking (Turkey only)                                     │
│  Layer 3: Rate limiting (30 req/min per IP)                                │
│  Layer 4: Mobile-only access (96% mobile users)                            │
│  Layer 5: Facebook referrer check (fbclid or referrer)                     │
│  Layer 6: Facebook bot bypass (facebookexternalhit)                        │
│  Layer 7: Secure access key (bypass for testing)                           │
│  Layer 8: Request validation                                               │
│                                                                             │
│  ✅ Allowed → Serve landing page                                           │
│  ❌ Blocked → Return 403 Forbidden                                         │
│                                                                             │
│  Logs every request:                                                       │
│  185.28.62.56 [TR] "GET /?fbclid=..." → 200 OK                             │
│  Log file: /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log│
└─────────────────┬───────────────────────────────────────┬───────────────────┘
                  │                                       │
                  │ Serve HTML                            │ Write log entry
                  ↓                                       ↓
┌───────────────────────────────────┐   ┌─────────────────────────────────────┐
│    LANDING PAGE (HTML)            │   │    NGINX LOG FILE                   │
│  /webapp/hurriyet-saglik-fixed... │   │  49,770 lines (24 hours)           │
│                                   │   │                                     │
│  Problems:                        │   │  Format:                            │
│  ❌ 5.7MB images (2.5MB + 2.4MB)  │   │  IP [Country] Timestamp             │
│  ❌ Broken Turkish text            │   │  "Method URL Protocol" Status       │
│  ❌ 6-10 second load time          │   │  Bytes "Referrer" "User-Agent"     │
│                                   │   │                                     │
│  Has:                             │   │  Updated every request              │
│  ✅ Facebook Pixel                 │   └───────────┬─────────────────────────┘
│  ✅ n8n webhook form               │               │
│  ✅ Contact form                   │               │ Parse continuously
└──────────┬────────────────────────┘               │
           │                                        ↓
           │ User sees page                         ┌───────────────────────────┐
           │ (waits 6-10 seconds)                   │  NGINX LOG PARSER         │
           │                                        │  (NEW SERVICE TO CREATE)  │
           ↓                                        │                           │
    ┌──────────────┐                                │  Reads: tail -F log.log  │
    │ USER DECIDES │                                │  Parses: regex matching  │
    └──────┬───────┘                                │  Sends: HTTP POST to API │
           │                                        │                           │
           ├─ 99.996% → Leave (bounce)              │  Every 1 second          │
           │            Time on site: 5-10s         └─────────┬─────────────────┘
           │                                                  │
           └─ 0.004% → Fill form                             │ POST visit data
                       (2 out of 49,770)                     │
                       ↓                                     ↓
              ┌────────────────────┐      ┌──────────────────────────────────────┐
              │   n8n WORKFLOW     │      │  TRAFFIC MANAGER API                 │
              │  (Already exists)  │      │  Location: /home/root/webapp/        │
              │                    │      │  Framework: Hono (Node.js)           │
              ├────────────────────┤      │  Storage: JSON files                 │
              │ Webhook receives:  │      │                                      │
              │ - Name             │      │  API Endpoints:                      │
              │ - Phone            │      │  ┌──────────────────────────────────┐│
              │ - IP               │      │  │ POST /api/domains/:id/           ││
              │ - fbclid           │      │  │      track-visit                 ││
              │ - Timestamp        │      │  │  • Tracks NGINX log data         ││
              │                    │      │  │  • Bot detection                 ││
              ├────────────────────┤      │  │  • IP classification             ││
              │ Calculates:        │      │  │  • Campaign tracking             ││
              │ - quick_bounce     │      │  └──────────────────────────────────┘│
              │ - time_on_site     │      │  ┌──────────────────────────────────┐│
              │ - retargeting_strat│      │  │ POST /api/domains/:id/           ││
              │ - priority         │      │  │      track-conversion            ││
              ├────────────────────┤      │  │  • Tracks n8n webhook data       ││
              │ Currently sends:   │      │  │  • Form submissions              ││
              │ ✅ Email/SMS        │      │  │  • Bounce analysis               ││
              │ ❌ No tracking      │◄─────┤  │  • Retargeting queue             ││
              │                    │  Add │  └──────────────────────────────────┘│
              │ NEW: Forward to    │ HTTP │  ┌──────────────────────────────────┐│
              │      Traffic Mgr   │ node │  │ GET /api/domains/:id/analytics   ││
              └────────────────────┘      │  │  • Returns all metrics           ││
                                          │  └──────────────────────────────────┘│
                                          │                                      │
                                          │  Stores in DomainDataManager:       │
                                          │  ┌──────────────────────────────────┐│
                                          │  │ Domain Data (JSON)               ││
                                          │  ├──────────────────────────────────┤│
                                          │  │ analytics:                       ││
                                          │  │   totalRequests: 49,770          ││
                                          │  │   humanRequests: 48,850          ││
                                          │  │   botRequests: 920               ││
                                          │  │   referrers:                     ││
                                          │  │     facebook: 49,680             ││
                                          │  │   countries:                     ││
                                          │  │     TR: 49,120                   ││
                                          │  │   recentVisitors: [last 1000]    ││
                                          │  ├──────────────────────────────────┤│
                                          │  │ campaigns:                       ││
                                          │  │   campaigns:                     ││
                                          │  │     "manual-krem-geleneksel-2":  ││
                                          │  │       clicks: 166                ││
                                          │  │       conversions: 2             ││
                                          │  │       cost: 282                  ││
                                          │  │   recentClicks: [last 1000]      ││
                                          │  ├──────────────────────────────────┤│
                                          │  │ conversions:                     ││
                                          │  │   total: 2                       ││
                                          │  │   quickBounces: 49,768           ││
                                          │  │   formSubmissions: 2             ││
                                          │  │   recent: [details]              ││
                                          │  ├──────────────────────────────────┤│
                                          │  │ ipRules:                         ││
                                          │  │   whitelist: [test IPs]          ││
                                          │  │   blacklist: [bots, fraud]       ││
                                          │  └──────────────────────────────────┘│
                                          └──────────────┬───────────────────────┘
                                                         │
                                                         │ Real-time updates
                                                         ↓
                                          ┌─────────────────────────────────────┐
                                          │   REACT DASHBOARD (Browser)         │
                                          │   Component: <HurriyetDashboard>    │
                                          │                                     │
                                          │   Updates every 5 seconds           │
                                          │   (fetch /api/domains/:id/analytics)│
                                          │                                     │
                                          │  ┌─────────────────────────────────┐│
                                          │  │ 📊 KEY METRICS                  ││
                                          │  ├─────────────────────────────────┤│
                                          │  │ Total Visits: 49,770            ││
                                          │  │ Form Submits: 2 (0.004%)        ││
                                          │  │ Bounce Rate: 99.996%            ││
                                          │  │ Avg Time: 6.2 seconds           ││
                                          │  └─────────────────────────────────┘│
                                          │  ┌─────────────────────────────────┐│
                                          │  │ 💰 CAMPAIGN PERFORMANCE         ││
                                          │  ├─────────────────────────────────┤│
                                          │  │ Campaign            Clicks  CPL ││
                                          │  │ manual-krem-gel...   166  141TL ││
                                          │  │ otomatik-gece...      98    -   ││
                                          │  └─────────────────────────────────┘│
                                          │  ┌─────────────────────────────────┐│
                                          │  │ 🔴 LIVE FEED (Auto-refresh)     ││
                                          │  ├─────────────────────────────────┤│
                                          │  │ 11:43:22 185.28.62.56 Bounce 7s ││
                                          │  │ 11:43:18 176.88.44.22 Bounce 5s ││
                                          │  │ 11:43:15 94.54.123.88 Bounce 9s ││
                                          │  │ 11:43:12 78.189.25.44 FORM! ✅  ││
                                          │  └─────────────────────────────────┘│
                                          │  ┌─────────────────────────────────┐│
                                          │  │ 🎯 RETARGETING QUEUE            ││
                                          │  ├─────────────────────────────────┤│
                                          │  │ Immediate: 12,450 visitors      ││
                                          │  │ Short delay: 24,890 visitors    ││
                                          │  │ Standard: 12,428 visitors       ││
                                          │  │                                 ││
                                          │  │ [Export to Meta Ads Manager]    ││
                                          │  └─────────────────────────────────┘│
                                          │                                     │
                                          │  User (YOU) sees everything! 👁️    │
                                          └─────────────────────────────────────┘
```

## 🔄 Data Flow Diagram

### Flow 1: Visitor Tracking (NGINX → Traffic Manager)

```
Facebook Ad Click
      ↓
NGINX receives request
      ↓
Log written: "185.28.62.56 [TR] GET /?fbclid=... 200"
      ↓
Log Parser reads line
      ↓
Parses: {
  ip: "185.28.62.56",
  country: "TR",
  fbclid: "IwZXh...",
  referrer: "facebook.com",
  timestamp: "2025-10-17T11:43:22+02:00"
}
      ↓
POST /api/domains/hurriyet-1/track-visit
      ↓
Traffic Manager:
  ├─ Analyze user agent (bot detection)
  ├─ Track in analytics.totalRequests
  ├─ Add to analytics.recentVisitors
  ├─ Track campaign (fbclid → campaign)
  ├─ Record in IP pool
  └─ Save to JSON file
      ↓
Dashboard refreshes
      ↓
User sees: "11:43:22 185.28.62.56 [TR] → Visit"
```

### Flow 2: Conversion Tracking (n8n → Traffic Manager)

```
User fills form on landing page
      ↓
JavaScript sends to n8n webhook:
  POST https://n8nwork.dtekai.com/webhook/bc74f59e...
      ↓
n8n workflow receives:
  {
    name: "Mehmet",
    phone: "5551234567",
    ip: "185.28.62.56",
    fbclid: "IwZXh...",
    timestamp: "..."
  }
      ↓
n8n analyzes:
  - Time on site: 5 seconds
  - Quick bounce: YES
  - Priority: URGENT
      ↓
n8n sends to Traffic Manager (NEW):
  POST /api/domains/hurriyet-1/track-conversion
  {
    ip: "185.28.62.56",
    fbclid: "IwZXh...",
    bounceAnalysis: {
      quickBounce: true,
      secondsOnSite: 5,
      retargetingStrategy: "immediate_retarget",
      priority: "urgent"
    }
  }
      ↓
Traffic Manager:
  ├─ analytics.conversions.total++
  ├─ analytics.conversions.quickBounces++
  ├─ Find campaign by fbclid
  ├─ campaign.conversions++
  ├─ Add to retargeting queue (immediate)
  └─ Save to JSON file
      ↓
Dashboard refreshes
      ↓
User sees: "11:43:12 185.28.62.56 [TR] → FORM! ✅"
            "Retargeting Queue: +1 immediate"
```

## 🗄️ Data Storage Structure

```
/home/root/webapp/data/domains/
├── hurriyet-rehber-haber.store.json
│   {
│     "id": "domain-1729161234567",
│     "name": "hürriyetrehberhaber.store",
│     "status": "active",
│     
│     "analytics": {
│       "totalRequests": 49770,
│       "uniqueVisitors": 48234,
│       "humanRequests": 48850,
│       "botRequests": 920,
│       
│       "referrers": {
│         "facebook": 49680,
│         "google": 45,
│         "direct": 45
│       },
│       
│       "countries": {
│         "TR": 49120,
│         "DE": 450,
│         "NL": 200
│       },
│       
│       "hourlyStats": {
│         "2025-10-17-11": { requests: 2340, humans: 2280, bots: 60 },
│         "2025-10-17-10": { requests: 2120, humans: 2060, bots: 60 }
│       },
│       
│       "recentVisitors": [
│         {
│           "ip": "185.28.62.56",
│           "country": "TR",
│           "timestamp": "2025-10-17T11:43:22+02:00",
│           "path": "/",
│           "referer": "https://facebook.com/...",
│           "userAgent": "Mozilla/5.0 (Android...)",
│           "isBot": false,
│           "botType": "human",
│           "fbclid": "IwZXh..."
│         }
│         // ... last 1000 visitors
│       ]
│     },
│     
│     "campaigns": {
│       "enabled": true,
│       "utmTracking": true,
│       
│       "campaigns": {
│         "manual-krem-geleneksel-2": {
│           "name": "manual-krem-geleneksel-2",
│           "clicks": 166,
│           "conversions": 2,
│           "cost": 282,
│           "sources": {
│             "facebook": 166
│           },
│           "countries": {
│             "TR": 164,
│             "DE": 2
│           }
│         }
│       },
│       
│       "recentClicks": [
│         {
│           "timestamp": 1729161802000,
│           "ip": "185.28.62.56",
│           "country": "TR",
│           "campaign": "manual-krem-geleneksel-2",
│           "source": "facebook",
│           "medium": "cpc",
│           "referrer": "https://facebook.com/...",
│           "fbclid": "IwZXh..."
│         }
│         // ... last 1000 clicks
│       ]
│     },
│     
│     "conversions": {
│       "total": 2,
│       "quickBounces": 49768,
│       "formSubmissions": 2,
│       
│       "recent": [
│         {
│           "ip": "78.189.25.44",
│           "fbclid": "IwZXh...",
│           "formData": { name: "...", phone: "..." },
│           "bounceAnalysis": {
│             "quickBounce": false,
│             "secondsOnSite": 45,
│             "retargetingStrategy": "standard",
│             "priority": "normal"
│           },
│           "timestamp": "2025-10-17T11:43:12+02:00"
│         }
│         // ... last 1000 conversions
│       ]
│     },
│     
│     "retargetingQueue": {
│       "immediate": [
│         { ip: "...", fbclid: "...", reason: "5s bounce" }
│         // 12,450 visitors
│       ],
│       "shortDelay": [
│         { ip: "...", fbclid: "...", reason: "8s bounce" }
│         // 24,890 visitors
│       ],
│       "standard": [
│         { ip: "...", fbclid: "...", reason: "25s browse" }
│         // 12,428 visitors
│       ]
│     }
│   }
│
├── hurriyet-saglik-2.store.json
│   // Future domain 2
│
└── hurriyet-saglik-3.store.json
    // Future domain 3
```

## 🔐 Security & Access Control

```
┌─────────────────────────────────────────────────────────┐
│  Security Layers                                        │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  NGINX Level (Current - Already working):              │
│  ├─ GeoIP blocking (Turkey only)                       │
│  ├─ Rate limiting (30 req/min)                         │
│  ├─ Mobile-only access                                 │
│  ├─ Facebook referrer check                            │
│  └─ DDoS protection                                    │
│                                                         │
│  Traffic Manager Level (Built-in):                     │
│  ├─ Bot detection (verified bots vs malicious)         │
│  ├─ IP classification (whitelist/blacklist/graylist)   │
│  ├─ Rate limiting per domain                           │
│  ├─ Manual IP control                                  │
│  └─ API authentication (requireAuth middleware)        │
│                                                         │
│  Dashboard Level (React):                              │
│  ├─ JWT authentication                                 │
│  ├─ Role-based access (admin, viewer)                  │
│  ├─ Session management                                 │
│  └─ CORS protection                                    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## 🚀 Deployment Architecture

```
┌───────────────────────────────────────────────────────────────┐
│  PRODUCTION SERVER                                            │
│                                                               │
│  ┌──────────────────────────────────────┐                    │
│  │  NGINX (Port 80/443)                 │                    │
│  │  ├─ SSL certificates                 │                    │
│  │  ├─ Reverse proxy                    │                    │
│  │  └─ Serve landing pages              │                    │
│  └──────────────────────────────────────┘                    │
│                                                               │
│  ┌──────────────────────────────────────┐                    │
│  │  Traffic Manager (Port 3000)         │                    │
│  │  ├─ Hono API server                  │                    │
│  │  ├─ JSON data storage                │                    │
│  │  └─ WebSocket for real-time updates  │                    │
│  │  Process: pm2 start src/index.tsx    │                    │
│  └──────────────────────────────────────┘                    │
│                                                               │
│  ┌──────────────────────────────────────┐                    │
│  │  NGINX Log Parser (Background)       │                    │
│  │  ├─ Reads: tail -F *.access.log      │                    │
│  │  ├─ Parses: regex matching           │                    │
│  │  └─ Sends: POST to Traffic Manager   │                    │
│  │  Process: pm2 start log-parser.js    │                    │
│  └──────────────────────────────────────┘                    │
│                                                               │
│  ┌──────────────────────────────────────┐                    │
│  │  Data Storage (/home/webapp/data/)   │                    │
│  │  ├─ domains/ (JSON files)            │                    │
│  │  ├─ ip-pool/ (Global IP tracking)    │                    │
│  │  └─ backups/ (Daily backups)         │                    │
│  └──────────────────────────────────────┘                    │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

## 🔧 Service Management

```bash
# Start Traffic Manager
pm2 start /home/root/webapp/src/index.tsx --name traffic-manager

# Start NGINX Log Parser
pm2 start /home/root/webapp/services/nginx-log-parser.js --name log-parser

# Monitor services
pm2 status
pm2 logs traffic-manager
pm2 logs log-parser

# Auto-restart on server reboot
pm2 startup
pm2 save

# Update deployment
cd /home/root/webapp
git pull
pm2 restart traffic-manager
```

## 📊 Monitoring & Alerts

```
Health Checks:
├─ Traffic Manager API: GET /api/health (every 60s)
├─ NGINX status: curl -I https://hürriyetrehberhaber.store (every 60s)
├─ Log Parser: Check last processed timestamp (every 60s)
└─ Disk space: Check /home/webapp/data/ size (every 300s)

Alerts (when to notify):
├─ Traffic Manager down (no /api/health response)
├─ NGINX down (status != 200)
├─ Log Parser stuck (last timestamp > 5 minutes ago)
├─ Disk space > 80%
├─ Conversion rate drops below 0.001%
└─ Bot traffic > 10% of total
```

## 🎯 Performance Optimization

```
Current Performance Issues:
├─ Landing page: 5.7MB images → 6-10s load time
├─ Mobile users: 96% waiting too long
├─ Bounce rate: 99.996% (only 2 out of 49,770 convert)
└─ Cost per lead: 141 TL (too expensive!)

After Optimization:
├─ Compress images: 5.7MB → 400KB (93% reduction)
├─ Enable lazy loading: Load images as user scrolls
├─ Add CDN: Cloudflare/CloudFront for fast delivery
├─ Fix content: Replace broken text with real Turkish
├─ Mobile-first: Optimize for 96% of users
└─ Loading state: Show progress bar

Expected Results:
├─ Page load: 6-10s → 1-2s (80% faster)
├─ Bounce rate: 99.996% → 30-50% (50% improvement)
├─ Conversion rate: 0.004% → 2-4% (500-1000x improvement)
└─ Cost per lead: 141 TL → 6-12 TL (95% cost reduction)
```

---

**Total System**: 6 components, all integrated, real-time visibility, scalable to unlimited domains! 🚀
