# 🤖 FACEBOOK BOT WHITELIST & DOMAIN VERIFICATION

**Proje**: Hürriyet Sağlık Landing Page  
**Tarih**: 2025-10-17  
**Durum**: ✅ AKTİF VE ÇALIŞIYOR

---

## 📋 İÇİNDEKİLER

1. [Facebook Bot Nedir?](#-facebook-bot-nedir)
2. [Neden Beyaz Listeye Alınmalı?](#-neden-beyaz-listeye-alinmali)
3. [Whitelist Konfigürasyonu](#-whitelist-konfigürasyonu)
4. [NGINX Bypass Mantığı](#-nginx-bypass-mantiği)
5. [robots.txt Ayarları](#-robotstxt-ayarlari)
6. [Open Graph & Meta Tags](#-open-graph--meta-tags)
7. [Test ve Doğrulama](#-test-ve-doğrulama)
8. [Troubleshooting](#-troubleshooting)

---

## 🤖 FACEBOOK BOT NEDİR?

Facebook, web sitelerini taradığı ve içerik bilgilerini topladığı için özel bot'lar kullanır.

### **Facebook Bot Türleri**

| Bot Adı | User-Agent | Görevi |
|---------|------------|--------|
| **facebookexternalhit** | `facebookexternalhit/1.1` | Link önizlemesi, Open Graph tarama |
| **Facebot** | `Facebot` | Genel Facebook web crawler |
| **facebookcatalog** | `facebookcatalog/1.0` | Katalog ve ürün bilgisi toplama |

### **Facebook Bot User-Agent Örnekleri**

```
facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)
facebookcatalog/1.0
Facebot
Mozilla/5.0 (compatible; Facebot/1.0; +https://www.facebook.com/facebot)
```

---

## 🎯 NEDEN BEYAZ LİSTEYE ALINMALI?

### **1. Domain Doğrulama (Domain Verification)**

Facebook, sitenizi doğrulamak için bot gönderir:

```html
<meta name="facebook-domain-verification" content="miulwpw89v22n8ikewuj8m365r6l09" />
```

**Süreç:**
```
1. Facebook Business Manager'da domain ekliyorsunuz
2. Meta bu kodu sitenize koymanızı istiyor
3. Facebook bot sitenizi ziyaret ediyor
4. Meta tag'i arıyor ve doğruluyor
5. ✅ Domain onaylanıyor
```

**Eğer bot engellenirse:**
```
❌ Facebook bot siteye erişemiyor
❌ Meta tag bulunamıyor
❌ Domain doğrulanamıyor
❌ Reklam yayınlanamıyor
```

---

### **2. Link Önizleme (Link Preview)**

Facebook'ta link paylaşıldığında önizleme gösterilir:

```
┌────────────────────────────────────────┐
│  [RESIM]                               │
│  Hürriyet Sağlık                       │
│  Sağlık ürünleri için en iyi fiyatlar │
│  hüriyetsagliksonnhaberler.site        │
└────────────────────────────────────────┘
```

**Facebook bot'un yaptığı:**
1. Sitenizi ziyaret eder
2. Open Graph meta tag'lerini okur
3. Başlık, açıklama, resim alır
4. Önizleme oluşturur

**Bot engellenirse:**
```
┌────────────────────────────────────────┐
│  hüriyetsagliksonnhaberler.site        │
│  [Önizleme yok]                        │
└────────────────────────────────────────┘
```

---

### **3. Reklam Kampanya Onayı**

Meta reklam kampanyası oluştururken:

```
1. Landing page URL'i giriyorsunuz
2. Facebook bot sayfayı kontrol ediyor
3. İçeriği analiz ediyor (politika ihlali var mı?)
4. Pixel var mı kontrol ediyor
5. ✅ Kampanya onaylanıyor
```

**Bot engellenirse:**
```
❌ Facebook içeriği göremez
❌ Kampanya reddedilir
❌ "Landing page erişilemiyor" hatası
```

---

## 🛡️ WHITELIST KONFIGÜRASYONU

### **1. NGINX Site Config**

**Dosya:** `/etc/nginx-hurriyet/sites-available/hurriyet-health`

```nginx
location / {
    # ============================================
    # 🤖 FACEBOOK BOT BYPASS: Allow domain verification
    # ============================================
    
    set $is_facebook_bot 0;
    if ($http_user_agent ~* "(facebookexternalhit|facebookcatalog|Facebot)") {
        set $is_facebook_bot 1;
    }
    
    # ... rate limiting ...
    
    # ============================================
    # GEO-BLOCKING BYPASS
    # ============================================
    
    # Facebook bot ekleniyor
    set $geo_check "${geo_check}${is_facebook_bot}";
    
    # Facebook bot - always allowed
    if ($geo_check ~ "_1$") {
        set $geo_allowed 1;
    }
    
    # ============================================
    # MOBILE-ONLY BYPASS
    # ============================================
    
    # Facebook bot bypass (domain verification)
    if ($is_facebook_bot = 1) {
        set $mobile 1;
    }
    
    # ... diğer kurallar ...
}
```

### **Bot Bypass Özellikleri**

| Kontrol | Normal Kullanıcı | Facebook Bot |
|---------|------------------|--------------|
| Geo-Blocking | ✅ Kontrol edilir | ✅ **BYPASS** |
| Mobile-Only | ✅ Zorunlu | ✅ **BYPASS** |
| Facebook Referrer | ✅ Zorunlu (yurtdışı) | ✅ **BYPASS** |
| Rate Limiting | ✅ Aktif | ⚠️ Aktif (ama düşük risk) |
| SSL/TLS | ✅ Zorunlu | ✅ Zorunlu |

---

## 🔍 NGINX BYPASS MANTIĞI

### **Multi-Condition Check Sistemi**

NGINX, string concatenation kullanarak çok katmanlı kontrol yapar:

```nginx
# Format: {country}_{facebook_ref}_{admin}_{key}_{bot}
# Örnek: "1_0_0_0_1" = Turkey + FB yok + Admin değil + Key yok + BOT

set $geo_check "${allowed_country}_";           # 1. Ülke (0/1)
set $geo_check "${geo_check}${has_facebook}_";  # 2. FB referrer (0/1)
set $geo_check "${geo_check}${is_admin}_";      # 3. Admin IP (0/1)
set $geo_check "${geo_check}${is_debug}_";      # 4. Secure key (0/1)
set $geo_check "${geo_check}${is_facebook_bot}"; # 5. Facebook bot (0/1)
```

### **Pattern Örnekleri**

| Pattern | Anlamı | Sonuç |
|---------|--------|-------|
| `1_0_0_0_0` | Türkiye + Normal user | ✅ İzinli |
| `0_1_0_0_0` | Yurtdışı + FB ref + Normal | ✅ İzinli |
| `0_0_0_0_1` | Yurtdışı + FB yok + **BOT** | ✅ **İzinli (Bot)** |
| `1_0_0_0_1` | Türkiye + **BOT** | ✅ **İzinli (Bot)** |
| `0_0_0_0_0` | Yurtdışı + FB yok + Normal | ❌ Bloklu |

### **Bot Kontrolü Regex**

```nginx
# Facebook bot tespiti (case-insensitive)
if ($http_user_agent ~* "(facebookexternalhit|facebookcatalog|Facebot)") {
    set $is_facebook_bot 1;
}

# Geo-blocking bypass
if ($geo_check ~ "_1$") {  # Son karakter 1 ise (bot varsa)
    set $geo_allowed 1;
}

# Mobile-only bypass
if ($is_facebook_bot = 1) {
    set $mobile 1;
}
```

---

## 📄 ROBOTS.TXT AYARLARI

**Dosya:** `/root/hurriyet-health/public/robots.txt`

```
User-agent: *
Disallow: /
# Tüm botları engelle

User-agent: Googlebot
Disallow: /

User-agent: Bingbot
Disallow: /

User-agent: Slurp
Disallow: /

User-agent: DuckDuckBot
Disallow: /

User-agent: Baiduspider
Disallow: /

User-agent: YandexBot
Disallow: /

User-agent: facebookexternalhit
Allow: /

User-agent: Twitterbot
Disallow: /

User-agent: LinkedInBot
Disallow: /

User-agent: Facebot
Allow: /

User-agent: WhatsApp
Allow: /

User-agent: Applebot
Disallow: /

# Hiçbir sitemap yok
# Sitemap:
```

### **Beyaz Liste**

✅ **İzin verilen botlar:**
- `facebookexternalhit` → Facebook link crawler
- `Facebot` → Facebook genel bot
- `WhatsApp` → WhatsApp link önizleme

❌ **Engellenen botlar:**
- `Googlebot` → Google arama motoru
- `Bingbot` → Bing arama motoru
- `Slurp` → Yahoo arama motoru
- `DuckDuckBot` → DuckDuckGo
- `Baiduspider` → Baidu (Çin)
- `YandexBot` → Yandex (Rusya)
- `Twitterbot` → Twitter
- `LinkedInBot` → LinkedIn
- `Applebot` → Apple Siri/Spotlight
- **Diğer tüm botlar** → Varsayılan engel

### **Neden Sadece Facebook?**

1. **Arama Motorlarını Engelleme Nedeni:**
   - Organik trafik istemiyoruz
   - Sadece Meta reklamlarından trafik
   - SEO'ya gerek yok

2. **Facebook İzin Verme Nedeni:**
   - Domain doğrulama zorunlu
   - Link önizleme gerekli
   - Reklam onayı için gerekli

3. **WhatsApp İzin Verme Nedeni:**
   - WhatsApp link paylaşımında önizleme
   - Meta'nın bir parçası
   - Organik paylaşımlar için faydalı

---

## 🏷️ OPEN GRAPH & META TAGS

### **Facebook Domain Verification**

```html
<meta name="facebook-domain-verification" content="miulwpw89v22n8ikewuj8m365r6l09" />
```

**Bu kod:**
- Facebook Business Manager'da oluşturulur
- HTML `<head>` bölümüne eklenir
- Facebook bot tarafından okunur
- Domain sahipliğini doğrular

### **Facebook Pixel**

```html
<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1536997377317312');
fbq('track', 'PageView');
</script>
```

**Pixel ID:** `1536997377317312`

### **Open Graph Tags (Önerilen)**

Şu anda eksik, eklenmesi önerilir:

```html
<!-- Open Graph Meta Tags -->
<meta property="og:title" content="Hürriyet Sağlık - Sağlık Ürünleri" />
<meta property="og:description" content="En kaliteli sağlık ürünleri için doğru adres" />
<meta property="og:image" content="https://hüriyetsagliksonnhaberler.site/images/og-image.jpg" />
<meta property="og:url" content="https://hüriyetsagliksonnhaberler.site/" />
<meta property="og:type" content="website" />
<meta property="og:locale" content="tr_TR" />

<!-- Facebook App ID (opsiyonel) -->
<meta property="fb:app_id" content="YOUR_APP_ID" />
```

**Faydaları:**
- Facebook'ta paylaşımlarda güzel görünüm
- Link önizlemesinde başlık ve resim
- Daha fazla tıklama oranı

---

## 🧪 TEST VE DOĞRULAMA

### **1. NGINX Test**

```bash
# Facebook bot olarak erişim testi
curl -I -k https://localhost:443/ \
  -H "Host: xn--hriyetsagliksonnhaberler-vsc.site" \
  -H "User-Agent: facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
```

**Beklenen Sonuç:**
```
HTTP/2 200 
server: nginx
content-type: text/html; charset=utf-8
```

✅ **200 OK** = Bot beyaz listede ve erişebiliyor

---

### **2. Facebook Sharing Debugger**

**Tool:** https://developers.facebook.com/tools/debug/

**Kullanım:**
1. URL'inizi girin: `https://hüriyetsagliksonnhaberler.site/`
2. "Scrape Again" butonuna tıklayın
3. Sonuçları inceleyin

**Kontrol Edilecekler:**
- ✅ Sayfa başarıyla yükleniyor mu?
- ✅ Meta tags okunuyor mu?
- ✅ Resim görünüyor mu?
- ✅ Domain verification görülüyor mu?

**Hata Örnekleri:**
```
❌ "Error Scraping Page" → Bot engellenmiş
❌ "Could not retrieve data" → Erişim reddedilmiş
❌ "403 Forbidden" → Geo-blocking aktif
❌ "404 Not Found" → Mobile-only engeli
```

---

### **3. Facebook Bot Log İnceleme**

```bash
# Facebook bot isteklerini görüntüle
sudo grep "facebookexternalhit\|Facebot" \
  /var/log/nginx-hurriyet/hurriyet-health-ssl.access.log | tail -10
```

**Örnek Log:**
```
185.60.216.35 [--] - - [17/Oct/2025:03:15:42 +0200] "GET / HTTP/1.1" 200 12374 "-" "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
```

**Analiz:**
- IP: `185.60.216.35` (Facebook IP range)
- Ülke: `--` (GeoIP tanımadı, normal)
- HTTP Kodu: `200` ✅ (Başarılı)
- User-Agent: `facebookexternalhit/1.1` ✅ (Bot tanındı)

---

### **4. Domain Verification Testi**

**Facebook Business Manager'da:**

1. **Business Settings** → **Brand Safety** → **Domains**
2. Domain'inizi ekleyin
3. Verification meta tag'i kopyalayın
4. HTML'e ekleyin
5. "Verify" butonuna tıklayın

**Başarılı:**
```
✅ Domain verified successfully
✅ miulwpw89v22n8ikewuj8m365r6l09 code found
```

**Başarısız:**
```
❌ Verification failed
❌ Could not find meta tag
→ Facebook bot engellenmiş olabilir
```

---

### **5. Rate Limiting Test (Bot için)**

```bash
# 50 rapid request as Facebook bot
for i in {1..50}; do
  curl -s -o /dev/null -w "Request $i: %{http_code}\n" \
    -k https://localhost:443/ \
    -H "Host: xn--hriyetsagliksonnhaberler-vsc.site" \
    -H "User-Agent: facebookexternalhit/1.1"
done
```

**Beklenen:**
```
Request 1-40: 200 OK
Request 41-50: 429 Too Many Requests
```

⚠️ **Not:** Facebook bot rate limiting'e TABİ (ama gerçekte nadiren 40+ istek yapar)

---

## 🚨 TROUBLESHOOTING

### **SORUN 1: Domain Verification Başarısız**

**Belirtiler:**
```
❌ Facebook: "Could not verify domain"
❌ Meta tag bulunamadı
```

**Kontroller:**

1. **Facebook bot erişimi test et:**
```bash
curl -I https://hüriyetsagliksonnhaberler.site/ \
  -H "User-Agent: facebookexternalhit/1.1"
```

2. **NGINX config kontrol et:**
```bash
sudo grep "is_facebook_bot" /etc/nginx-hurriyet/sites-available/hurriyet-health
```

3. **Meta tag varlığını kontrol et:**
```bash
curl -s https://hüriyetsagliksonnhaberler.site/ | grep "facebook-domain-verification"
```

**Çözüm:**
- NGINX'te bot bypass varsa → Meta tag'i HTML'e ekle
- Meta tag varsa → NGINX bot bypass ekle
- İkisi de varsa → Cache temizle ve tekrar dene

---

### **SORUN 2: Link Önizleme Çıkmıyor**

**Belirtiler:**
```
Facebook'ta link paylaşıldığında:
┌────────────────────────────────────┐
│  hüriyetsagliksonnhaberler.site    │
│  [Önizleme yok - sadece link]     │
└────────────────────────────────────┘
```

**Kontroller:**

1. **Facebook Debugger kullan:**
   - https://developers.facebook.com/tools/debug/
   - URL gir ve "Scrape Again"

2. **Open Graph tag'leri kontrol et:**
```bash
curl -s https://hüriyetsagliksonnhaberler.site/ | grep "og:"
```

**Çözüm:**
```html
<!-- Bu tag'leri ekle -->
<meta property="og:title" content="..." />
<meta property="og:description" content="..." />
<meta property="og:image" content="..." />
```

---

### **SORUN 3: Bot 403/404 Alıyor**

**Belirtiler:**
```
Log'da:
"GET / HTTP/1.1" 403 ... "facebookexternalhit/1.1"
veya
"GET / HTTP/1.1" 404 ... "facebookexternalhit/1.1"
```

**Neden:**
- Geo-blocking bot'u engelliyor (403)
- Mobile-only bot'u engelliyor (404)

**Çözüm:**

1. **Geo-blocking bypass ekle:**
```nginx
# Facebook bot - always allowed
if ($geo_check ~ "_1$") {
    set $geo_allowed 1;
}
```

2. **Mobile-only bypass ekle:**
```nginx
# Facebook bot bypass (domain verification)
if ($is_facebook_bot = 1) {
    set $mobile 1;
}
```

3. **NGINX reload:**
```bash
sudo kill -HUP $(cat /run/nginx-hurriyet.pid)
```

---

### **SORUN 4: Rate Limiting Bot'u Blokluyor**

**Belirtiler:**
```
Log'da:
"GET / HTTP/1.1" 429 ... "facebookexternalhit/1.1"
limiting requests, excess: 10.000 ...
```

**Neden:**
Facebook bot çok hızlı istek gönderiyor (nadiren olur)

**Çözüm 1 - Bot'a özel zone (önerilmez):**
```nginx
# Bot'lar için ayrı zone
limit_req_zone $binary_remote_addr zone=bots:10m rate=100r/m;

# Bot ise farklı zone kullan
if ($is_facebook_bot = 1) {
    limit_req zone=bots burst=50 nodelay;
}
```

**Çözüm 2 - Burst artır (önerilen):**
```nginx
# Mevcut burst'ü artır
limit_req zone=pages burst=20 nodelay;  # 10'dan 20'ye
```

---

### **SORUN 5: WhatsApp Önizleme Çalışmıyor**

**Belirtiler:**
WhatsApp'ta link paylaşıldığında önizleme görünmüyor

**Kontroller:**

1. **robots.txt'te WhatsApp izinli mi:**
```bash
curl -s https://hüriyetsagliksonnhaberler.site/robots.txt | grep -A2 "WhatsApp"
```

2. **WhatsApp bot erişimi:**
```bash
curl -I https://hüriyetsagliksonnhaberler.site/ \
  -H "User-Agent: WhatsApp/2.19.175"
```

**Çözüm:**

1. **NGINX'e WhatsApp bypass ekle:**
```nginx
set $is_whatsapp 0;
if ($http_user_agent ~* "WhatsApp") {
    set $is_whatsapp 1;
}

# Geo-blocking bypass
if ($is_whatsapp = 1) {
    set $geo_allowed 1;
}

# Mobile-only bypass
if ($is_whatsapp = 1) {
    set $mobile 1;
}
```

---

## 📊 GÜNCEL DURUM

### **Whitelist Status**

```
╔═══════════════════════════════════════════════════════════╗
║            🤖 FACEBOOK BOT WHITELIST STATUS               ║
╠═══════════════════════════════════════════════════════════╣
║                                                           ║
║  NGINX Bypass:         ✅ AKTİF                          ║
║  • facebookexternalhit ✅ Tanımlı                        ║
║  • Facebot             ✅ Tanımlı                        ║
║  • facebookcatalog     ✅ Tanımlı                        ║
║                                                           ║
║  Bypass Yetenekleri:                                      ║
║  • Geo-Blocking        ✅ BYPASS                         ║
║  • Mobile-Only         ✅ BYPASS                         ║
║  • FB Referrer         ✅ BYPASS                         ║
║  • Rate Limiting       ⚠️  AKTİF (ama düşük risk)        ║
║                                                           ║
║  robots.txt:           ✅ AKTİF                          ║
║  • facebookexternalhit ✅ Allow: /                       ║
║  • Facebot             ✅ Allow: /                       ║
║  • WhatsApp            ✅ Allow: /                       ║
║  • Diğer botlar        ❌ Disallow: /                    ║
║                                                           ║
║  Meta Tags:                                               ║
║  • Domain Verification ✅ miulwpw89v22n8ikewuj8m365r6l09 ║
║  • Facebook Pixel      ✅ 1536997377317312               ║
║  • Open Graph Tags     ⚠️  EKLENMELİ (önerilen)          ║
║                                                           ║
║  Test Sonuçları:                                          ║
║  • Bot Erişimi         ✅ 200 OK                         ║
║  • Domain Verification ✅ Başarılı                       ║
║  • Link Preview        ⚠️  Çalışıyor (OG tags önerilir)  ║
║                                                           ║
║  Overall Status:       ✅ OPERASYONEL                    ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
```

---

## 🎯 ÖNERİLER

### **1. Open Graph Tags Ekle** (Yüksek Öncelik)

```html
<!-- HEAD bölümüne ekle -->
<meta property="og:title" content="Hürriyet Sağlık - Premium Sağlık Ürünleri" />
<meta property="og:description" content="En kaliteli sağlık ürünleri için güvenilir adres. Hemen sipariş verin!" />
<meta property="og:image" content="https://hüriyetsagliksonnhaberler.site/images/og-preview.jpg" />
<meta property="og:url" content="https://hüriyetsagliksonnhaberler.site/" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="Hürriyet Sağlık" />
<meta property="og:locale" content="tr_TR" />
```

**Fayda:** Facebook'ta link paylaşımlarında profesyonel görünüm

---

### **2. Twitter Card Tags Ekle** (Düşük Öncelik)

```html
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Hürriyet Sağlık" />
<meta name="twitter:description" content="Premium sağlık ürünleri" />
<meta name="twitter:image" content="https://hüriyetsagliksonnhaberler.site/images/twitter-card.jpg" />
```

**Not:** Twitter bot robots.txt'te engellenmiş (şu an gerek yok)

---

### **3. Structured Data Ekle** (Opsiyonel)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Hürriyet Sağlık",
  "url": "https://hüriyetsagliksonnhaberler.site/",
  "logo": "https://hüriyetsagliksonnhaberler.site/images/logo.png"
}
</script>
```

---

### **4. Facebook App ID Ekle** (Opsiyonel)

```html
<meta property="fb:app_id" content="YOUR_FACEBOOK_APP_ID" />
```

**Fayda:** Facebook Analytics ve Insights için

---

## 📚 İLGİLİ DOKÜMANTASYON

- [Facebook Meta & NGINX Trafik Kuralları](./FACEBOOK_META_NGINX_TRAFIK_KURALLARI.md)
- [Güvenlik Özeti](./HURRIYET_COMPLETE_SECURITY_SUMMARY.md)
- [Proje Durumu](./HURRIYET_PROJECT_STATE.md)

---

## 🔗 FAYDALI LİNKLER

- **Facebook Sharing Debugger:** https://developers.facebook.com/tools/debug/
- **Facebook Business Manager:** https://business.facebook.com/
- **Open Graph Protocol:** https://ogp.me/
- **Facebook Crawler Info:** https://developers.facebook.com/docs/sharing/webmasters/crawler

---

**Doküman Versiyonu**: 1.0  
**Son Güncelleme**: 2025-10-17  
**Durum**: ✅ Aktif ve Operasyonel  
**Bot Whitelist**: ✅ Çalışıyor ve Test Edildi
