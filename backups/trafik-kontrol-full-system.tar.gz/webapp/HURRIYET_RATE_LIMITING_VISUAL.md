# 🛡️ Hürriyet Sağlık Rate Limiting Visual Guide

## 📊 Rate Limiting Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        INCOMING TRAFFIC                              │
│                     (Various Sources & IPs)                          │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    NGINX RATE LIMITER                                │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  IP-Based Tracking: $binary_remote_addr                      │   │
│  │  Memory Zones: 10MB each (160,000 unique IPs)                │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐           │
│  │  PAGES   │  │  FORMS   │  │  STATIC  │  │   API    │           │
│  │  Zone    │  │  Zone    │  │  Zone    │  │  Zone    │           │
│  │ 30/min   │  │  5/min   │  │ 100/min  │  │  10/min  │           │
│  │ burst=10 │  │ burst=2  │  │ burst=50 │  │ burst=3  │           │
│  └─────┬────┘  └─────┬────┘  └─────┬────┘  └─────┬────┘           │
│        │             │              │             │                 │
└────────┼─────────────┼──────────────┼─────────────┼─────────────────┘
         │             │              │             │
         ▼             ▼              ▼             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     DECISION POINT                                   │
│                                                                       │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │  Rate Limit Check:                                           │   │
│  │  • Count requests from this IP in last minute                │   │
│  │  • Compare against zone limit + burst                        │   │
│  │  • Decision: Allow or Reject                                 │   │
│  └─────────────────────────────────────────────────────────────┘   │
│                                                                       │
│         ┌─────────────────┴─────────────────┐                       │
│         │                                    │                       │
│         ▼                                    ▼                       │
│  ┌─────────────┐                     ┌─────────────┐                │
│  │   ALLOW     │                     │   REJECT    │                │
│  │  (Under     │                     │  (Over      │                │
│  │   Limit)    │                     │   Limit)    │                │
│  └──────┬──────┘                     └──────┬──────┘                │
│         │                                    │                       │
└─────────┼────────────────────────────────────┼───────────────────────┘
          │                                    │
          ▼                                    ▼
┌──────────────────┐                  ┌──────────────────┐
│  Proxy to        │                  │  Return 429      │
│  Backend         │                  │  Too Many        │
│  (Port 8080)     │                  │  Requests        │
└──────────────────┘                  └──────────────────┘
```

---

## 🔄 Request Flow by Type

### 1️⃣ Main Page Request (`/`)

```
User Request → NGINX
                │
                ▼
        [Rate Limit Check]
        Zone: pages (30/min)
        Burst: 10 extra
                │
        ┌───────┴───────┐
        ▼               ▼
    [Under 40/min]  [Over 40/min]
        │               │
        ▼               ▼
    [Allow]         [429 Error]
        │
        ▼
    [Security Checks]
    • Mobile device?
    • Facebook referrer?
    • Admin IP?
        │
        ▼
    [Proxy to Backend]
        │
        ▼
    [HTML Response]
```

### 2️⃣ Form Submission (`/submit-order`)

```
Form Submit → NGINX
                │
                ▼
        [Rate Limit Check]
        Zone: forms (5/min)
        Burst: 2 extra
                │
        ┌───────┴───────┐
        ▼               ▼
    [Under 7/min]   [Over 7/min]
        │               │
        ▼               ▼
    [Allow]         [429 Error]
        │            [Bot Blocked!]
        ▼
    [Proxy to Backend]
        │
        ▼
    [Webhook to N8N]
        │
        ▼
    [Success Response]
```

### 3️⃣ Static Assets (`.css`, `.js`, `.jpg`)

```
Asset Request → NGINX
                │
                ▼
        [Rate Limit Check]
        Zone: static (100/min)
        Burst: 50 extra
                │
        ┌───────┴───────┐
        ▼               ▼
    [Under 150/min] [Over 150/min]
        │               │
        ▼               ▼
    [Allow]         [429 Error]
        │            [Scraper Blocked!]
        ▼
    [Proxy to Backend]
        │
        ▼
    [File with Cache]
    [Expires: 1 Month]
```

### 4️⃣ API Requests (`/api/*`)

```
API Call → NGINX
                │
                ▼
        [Rate Limit Check]
        Zone: api (10/min)
        Burst: 3 extra
                │
        ┌───────┴───────┐
        ▼               ▼
    [Under 13/min]  [Over 13/min]
        │               │
        ▼               ▼
    [Allow]         [429 Error]
        │            [API Abuse Blocked!]
        ▼
    [Proxy to Backend]
        │
        ▼
    [JSON Response]
```

---

## 🧪 Rate Limiting in Action

### Scenario 1: Normal User Browsing

```
Time    Request    Result      Reason
────────────────────────────────────────────────────
00:00   GET /      200 OK      Request 1/30
00:05   GET /      200 OK      Request 2/30
00:10   GET /form  200 OK      Request 3/30
00:15   POST /sub  200 OK      Request 4/30
00:20   GET /img   200 OK      Request 5/30

Result: ✅ All requests successful - under limit
```

### Scenario 2: Rapid Clicking (Burst Used)

```
Time    Request    Result      Reason
────────────────────────────────────────────────────
00:00   GET / x30  200 OK      Normal quota used
00:00   GET / x10  200 OK      Burst quota used (10 extra)
00:00   GET / x5   429 Error   Over limit (30+10=40)

Result: ⚠️ First 40 requests OK, then blocked
Next Request Allowed: 00:02 (rate: 30/min = 1 every 2 seconds)
```

### Scenario 3: Bot Attack (Forms)

```
Time    Request         Result      Reason
────────────────────────────────────────────────────
00:00   POST /sub x5    200 OK      Normal quota (5/min)
00:00   POST /sub x2    200 OK      Burst quota (2 extra)
00:00   POST /sub x1    429 Error   Over limit (5+2=7)
00:00   POST /sub x993  429 Error   Bot blocked!

Result: 🛡️ Bot can only submit 7 forms, then blocked for 1 minute
```

### Scenario 4: DDoS Attack

```
Attacker: Sends 10,000 requests from single IP

Time    Requests       Allowed    Blocked    Result
────────────────────────────────────────────────────────────
00:00   10,000 req     40 (burst) 9,960      99.6% blocked!
00:02   10,000 req     1 (rate)   9,999      99.99% blocked!
01:00   10,000 req     40 (reset) 9,960      99.6% blocked!

Result: 🛡️ Server protected! Only 82 requests in 1 minute vs 30,000 attempted
```

---

## 📈 Memory Usage Breakdown

### Rate Limiting Zones

```
┌─────────────────────────────────────────────────────────────┐
│  Zone: pages (10MB)                                          │
│  ┌─────────────────────────────────────────────────────────┤
│  │ IP: 192.168.1.100 → Count: 25, Last: 00:00:45          │
│  │ IP: 10.0.0.50     → Count: 15, Last: 00:00:30          │
│  │ IP: 172.16.0.20   → Count: 30, Last: 00:00:55          │
│  │ ... ~160,000 unique IPs can be tracked ...             │
│  └─────────────────────────────────────────────────────────┤
└─────────────────────────────────────────────────────────────┘

Each entry: ~64 bytes (IP + counter + timestamp)
10MB = ~160,000 concurrent unique IPs tracked
```

### Memory Efficiency Comparison

```
Format                  Size per IP    10MB can track
──────────────────────────────────────────────────────
$binary_remote_addr     64 bytes       ~160,000 IPs  ✅ (Used)
$remote_addr (string)   ~128 bytes     ~80,000 IPs
```

---

## 🚦 Traffic Light System

### Visual Rate Limit Status

```
Request Count         Status              Action
─────────────────────────────────────────────────────────────
0-30 per minute       🟢 GREEN            Allow all requests
31-40 per minute      🟡 YELLOW           Using burst capacity
41+ per minute        🔴 RED              Block with 429 error

Example Timeline:
│
│ 🟢 Normal Traffic (0-30 req/min)
├──────────────────────────────────────
│
│ 🟡 Burst Used (31-40 req/min)
├──────────────────────
│
│ 🔴 BLOCKED (41+ req/min)
├──────────────────────────────────────
│
│ 🟢 Rate Reset (next minute)
├──────────────────────────────────────
```

---

## 🎯 Rate Limit Decision Tree

```
                    [Request Arrives]
                           │
                           ▼
                 ┌─────────────────┐
                 │ Which Location?  │
                 └────────┬─────────┘
                          │
           ┌──────────────┼──────────────┬──────────────┐
           ▼              ▼              ▼              ▼
      [Pages /]      [Forms /sub]   [Static .*]    [API /api]
      30/min+10      5/min+2        100/min+50     10/min+3
           │              │              │              │
           └──────────────┴──────────────┴──────────────┘
                          │
                          ▼
              ┌───────────────────────┐
              │ Check IP Request      │
              │ Count in Last Minute  │
              └──────────┬────────────┘
                          │
                ┌─────────┴─────────┐
                ▼                   ▼
        [Under Limit]         [Over Limit]
        (Rate + Burst)        (Exceeded)
                │                   │
                ▼                   ▼
        ┌──────────────┐    ┌──────────────┐
        │   ALLOW      │    │   REJECT     │
        │   Process    │    │   429 Error  │
        │   Request    │    │              │
        └──────────────┘    └──────────────┘
```

---

## 📊 Real-World Performance Impact

### Before Rate Limiting

```
┌────────────────────────────────────────────────┐
│  Attack Scenario: Bot sending 100 req/second   │
├────────────────────────────────────────────────┤
│  Requests per minute:  6,000                   │
│  Server CPU Usage:     95%                     │
│  Memory Usage:         3.8GB                   │
│  Response Time:        5-10 seconds            │
│  Legitimate Users:     ❌ Site unresponsive    │
│  Result:               🔴 Service degraded     │
└────────────────────────────────────────────────┘
```

### After Rate Limiting

```
┌────────────────────────────────────────────────┐
│  Attack Scenario: Bot sending 100 req/second   │
├────────────────────────────────────────────────┤
│  Requests per minute:  6,000 attempted         │
│  Actually processed:   40 (99.3% blocked!)     │
│  Server CPU Usage:     15%                     │
│  Memory Usage:         450MB                   │
│  Response Time:        <100ms                  │
│  Legitimate Users:     ✅ Site working fast    │
│  Result:               🟢 Service protected    │
└────────────────────────────────────────────────┘
```

---

## 🔧 Configuration Hierarchy

```
/etc/nginx-hurriyet/nginx.conf
│
├── [Global Settings]
│   ├── worker_processes: auto
│   ├── worker_connections: 768
│   └── error_log: /var/log/nginx-hurriyet/error.log
│
├── [HTTP Block]
│   ├── Basic Settings (sendfile, tcp_nopush, etc.)
│   ├── SSL Settings (TLS 1.2/1.3)
│   │
│   ├── 🛡️ RATE LIMITING ZONES ← ADDED HERE
│   │   ├── limit_req_zone pages:10m rate=30r/m
│   │   ├── limit_req_zone forms:10m rate=5r/m
│   │   ├── limit_req_zone static:10m rate=100r/m
│   │   └── limit_req_zone api:10m rate=10r/m
│   │
│   ├── limit_req_status 429
│   ├── limit_req_log_level warn
│   │
│   ├── Logging Format
│   ├── Gzip Settings
│   │
│   └── Include sites-enabled/*
│       │
│       └── /etc/nginx-hurriyet/sites-enabled/hurriyet-health
│           │
│           ├── [HTTP Server :80] → Redirect to HTTPS
│           │
│           └── [HTTPS Server :443]
│               ├── SSL Certificates
│               ├── Security Headers
│               │
│               ├── [Location /] ← Main pages
│               │   ├── 🛡️ limit_req zone=pages burst=10
│               │   ├── Mobile-only check
│               │   ├── Facebook referrer check
│               │   └── Proxy to :8080
│               │
│               ├── [Location /submit-order] ← Forms
│               │   ├── 🛡️ limit_req zone=forms burst=2
│               │   └── Proxy to :8080
│               │
│               ├── [Location ~* .*\.(css|js|...)] ← Static
│               │   ├── 🛡️ limit_req zone=static burst=50
│               │   └── Proxy to :8080 with cache
│               │
│               └── [Location /api/] ← API
│                   ├── 🛡️ limit_req zone=api burst=3
│                   └── Proxy to :8080
```

---

## 🎭 Multi-Layer Security Visualization

```
┌─────────────────────────────────────────────────────────────┐
│                       USER REQUEST                           │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
         ┌───────────────────────────────┐
         │   Layer 1: Rate Limiting      │  🛡️ NEW!
         │   • Block excessive requests   │
         │   • Prevent DDoS              │
         └──────────────┬────────────────┘
                        │
                        ▼
         ┌───────────────────────────────┐
         │   Layer 2: Device Check       │  📱 Existing
         │   • Mobile-only access        │
         │   • Block desktop browsers    │
         └──────────────┬────────────────┘
                        │
                        ▼
         ┌───────────────────────────────┐
         │   Layer 3: Referrer Check     │  🔗 Existing
         │   • Facebook traffic only     │
         │   • Block direct access       │
         └──────────────┬────────────────┘
                        │
                        ▼
         ┌───────────────────────────────┐
         │   Layer 4: IP Whitelist       │  🔑 Existing
         │   • Admin IP: 85.98.16.30     │
         │   • Bypass all restrictions   │
         └──────────────┬────────────────┘
                        │
                        ▼
         ┌───────────────────────────────┐
         │   Layer 5: SSL/TLS            │  🔒 Existing
         │   • HTTPS encryption          │
         │   • TLS 1.2/1.3 only          │
         └──────────────┬────────────────┘
                        │
                        ▼
         ┌───────────────────────────────┐
         │   Layer 6: Proxy to Backend   │  🔄 Existing
         │   • Node.js Express (8080)    │
         │   • Application logic         │
         └───────────────────────────────┘

All 6 layers must pass for request to succeed!
```

---

## 📝 Quick Reference Card

### Rate Limit Quick Stats

```
╔═══════════════════════════════════════════════════════════╗
║           HÜRRIYET SAĞLIK RATE LIMITS                     ║
╠═══════════════════════════════════════════════════════════╣
║  Zone      │ Base Rate  │ Burst │ Total Allowed          ║
╟────────────┼────────────┼───────┼────────────────────────╢
║  Pages     │ 30/min     │  +10  │ 40 req/min max         ║
║  Forms     │  5/min     │  +2   │  7 req/min max         ║
║  Static    │ 100/min    │  +50  │ 150 req/min max        ║
║  API       │ 10/min     │  +3   │ 13 req/min max         ║
╟────────────┴────────────┴───────┴────────────────────────╢
║  Response Code: 429 Too Many Requests                     ║
║  Tracking: Per IP address ($binary_remote_addr)           ║
║  Memory: 10MB per zone (160,000 IPs)                      ║
║  Algorithm: Leaky bucket with burst                       ║
╚═══════════════════════════════════════════════════════════╝
```

### Admin Commands

```bash
# Test configuration
sudo /usr/sbin/nginx -c /etc/nginx-hurriyet/nginx.conf -t

# Reload NGINX
sudo kill -HUP $(cat /run/nginx-hurriyet.pid)

# View rate limit logs
sudo tail -f /var/log/nginx-hurriyet/error.log | grep limiting

# Count 429 errors
sudo grep " 429 " /var/log/nginx-hurriyet/*.log | wc -l

# Find top blocked IPs
sudo grep "limiting" /var/log/nginx-hurriyet/error.log | \
  grep -oP 'client: \K[0-9.]+' | sort | uniq -c | sort -rn
```

---

## 🎓 Educational Examples

### Example 1: Shopping Cart Behavior

```
User adds items to cart rapidly:

00:00:00  GET /product/1      ✅ 200 OK  (1/40)
00:00:01  GET /product/2      ✅ 200 OK  (2/40)
00:00:02  POST /add-to-cart   ✅ 200 OK  (3/40)
00:00:03  GET /cart           ✅ 200 OK  (4/40)
00:00:04  POST /add-to-cart   ✅ 200 OK  (5/40)
...
00:00:39  GET /checkout       ✅ 200 OK  (40/40) [Burst used]
00:00:40  POST /submit-order  ✅ 200 OK  (Form zone: 1/7)

Result: Normal shopping behavior works perfectly!
```

### Example 2: Accidental Refresh Spam

```
User accidentally holds F5 (refresh):

00:00:00  GET / x 30          ✅ 200 OK  (Normal quota)
00:00:01  GET / x 10          ✅ 200 OK  (Burst quota)
00:00:02  GET / x 1           ❌ 429 Error
00:00:03  GET / x 1           ❌ 429 Error
00:00:05  GET / x 1           ✅ 200 OK  (Rate recovered)

Result: Burst protects against accidental spam, then blocks
```

### Example 3: Malicious Bot

```
Bot attempts form spam attack:

00:00:00  POST /submit x 1000

Server processes only:
  - First 5: ✅ Normal quota
  - Next 2: ✅ Burst quota
  - Remaining 993: ❌ 429 Error (99.3% blocked!)

Bot IP logged, can be permanently banned if needed.

Result: Attack neutralized with minimal impact!
```

---

**Document Version**: 1.0  
**Last Updated**: 2025-10-14  
**Purpose**: Visual guide for understanding rate limiting implementation
