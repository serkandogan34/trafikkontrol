# 🎯 3 AD SET KAMPANYA YAPILANDIRMASI

## ✅ KAMPANYA DETAYLARI (TAMAMLANDI)

```
Kampanya Adı: Özphyzen-üriyet-krem-10-25-test
Campaign ID: 120236018975950246
Günlük Bütçe: 400 TL
Optimizasyon: CBO (Campaign Budget Optimization) - Otomatik Dağıtım
Amaç: Potansiyel müşteriler (Lead Generation)
Teklif Stratejisi: En yüksek hacim (Highest Volume)
Kategori: Kozmetik ve Kişisel Bakım
Özel Reklam Kategorisi: Yok
```

---

## 📊 3 AD SET STRATEJİSİ

### 🎯 STRATEJİK YAKLAŞIM

**NEDEN 3 AD SET?**
1. **Farklı yaş segmentleri test** → En karlı grubu bul
2. **10 görseli akıllıca dağıt** → Hangi görsel hangi yaşta çalışıyor?
3. **CBO algoritması optimize etsin** → Kazanan ad set'e otomatik bütçe artışı
4. **Risk dağıtımı** → Tek sepette tüm yumurta yok

**BEKLENEN SONUÇ (3-5 GÜN SONRA):**
- 1 ad set öne çıkacak (CPL 15-25 TL)
- 1 ad set orta performans (CPL 25-35 TL)
- 1 ad set düşük performans (CPL 35+ TL veya pause)

**AKSIYON:**
- Kazanan ad set'e bütçe artır (600-800 TL)
- Orta ad set'i 100-150 TL'de tut
- Kaybeden ad set'i pause/kapatma

---

## 📂 AD SET 1: "Geniş Test - 30-60" (KONTROL GRUBU)

### ⚙️ TEMEL AYARLAR

```
Ad Set Adı: Geniş-Test-30-60-Mobile-Feed
Bütçe: CBO Otomatik (Facebook dağıtır, başlangıç ~120-150 TL/gün)
Optimizasyon: Potansiyel Müşteri (Lead)
Teklif Stratejisi: En yüksek hacim
```

### 👥 HEDEF KİTLE

```
Lokasyon: 
  ✅ Türkiye (Tüm ülke)
  ❌ Yurtdışı hariç (nginx zaten engelliyor)

Yaş: 30-60 yaş
  → GENİŞ TEST (Baseline/Kontrol grubu)

Cinsiyet: Tümü
  → Kadın + Erkek (Krem her iki cinse de satılabilir)

Dil: Türkçe
```

### 🎯 DETAYLI HEDEFLEMESoft Interests (Geniş Erişim):
```
İlgi Alanları:
  ✅ Wellness (Genel sağlık ilgisi)
  ✅ Sağlıklı yaşam (Healthy living)
  ✅ Sağlık gıdası (Health food)
  ✅ Doğal sağlık (Natural health)
  ✅ Fitness (Aktif yaşam)
  ✅ Stres yönetimi (Stress management)
  
  🚫 FAZLA DARALTMA! → Geniş ad set için broad hedefleme
```

### 📱 YERLEŞIM (PLACEMENT)

```
Yerleşim: Manuel Seçim (Automatic Placements KAPALI)

✅ AKTIF YERLEŞIMLER:
  📱 Facebook Feed (Mobile)
  📱 Facebook Reels (Mobile)
  🛒 Facebook Marketplace (Mobile)
  📱 Instagram Feed (Mobile)
  📱 Instagram Reels (Mobile)

❌ KAPALI YERLEŞIMLER:
  🚫 Audience Network (Düşük kalite trafik)
  🚫 Facebook Stories (İlk testte hariç)
  🚫 Instagram Stories (İlk testte hariç)
  🚫 Messenger (İlk testte hariç)
  🚫 Desktop Placements (Site zaten mobile-only)
```

### 🎨 GÖRSEL DAĞILIMI (3 EN İYİ GÖRSEL)

**Ad Set 1 için 3 görsel seç - Farklı tiplerde:**

```
GÖRSEL SEÇIM KRİTERİ:
  ✓ Görsel 1: En güçlü before/after görseli
  ✓ Görsel 2: Prof. Dr. Mehmet Öz fotoğrafı (otorite)
  ✓ Görsel 3: Ürün close-up (krem/kutu görseli)
  
Bu 3 görsel = CONTROL GROUP (Baseline performans)
```

---

## 📂 AD SET 2: "Orta Yaş Power - 35-55" (SWEET SPOT)

### ⚙️ TEMEL AYARLAR

```
Ad Set Adı: OrtaYas-Power-35-55-Mobile-Feed
Bütçe: CBO Otomatik (Facebook dağıtır, beklenti ~150-200 TL/gün)
Optimizasyon: Potansiyel Müşteri (Lead)
Teklif Stratejisi: En yüksek hacim
```

### 👥 HEDEF KİTLE

```
Lokasyon: Türkiye (Tüm ülke)

Yaş: 35-55 yaş ⭐ SWEET SPOT
  → En yüksek gelir + Cilt sorunları farkındalığı
  → Kredi kartı kullanım oranı yüksek
  → Online alışveriş deneyimi var

Cinsiyet: Tümü

Dil: Türkçe
```

### 🎯 DETAYLI HEDEFLEME (BİRAZ DAHA DAR)

```
İlgi Alanları (Ad Set 1 ile AYNI):
  ✅ Wellness
  ✅ Sağlıklı yaşam
  ✅ Sağlık gıdası
  ✅ Doğal sağlık
  ✅ Fitness
  ✅ Stres yönetimi

+ EK HEDEFLEME (OPTIONAL - Test için):
  ✅ Cilt bakımı (Skin care)
  ✅ Anti-aging (Yaşlanma karşıtı)
  ✅ Güzellik ürünleri (Beauty products)
  
  ⚠️ EĞER ERIŞIM 500K'NIN ALTINA DÜŞERSE EK HEDEFLEME EKLEME!
```

### 📱 YERLEŞIM (PLACEMENT)

```
Yerleşim: Manuel Seçim (Ad Set 1 ile AYNI)

✅ AKTIF:
  📱 Facebook Feed (Mobile)
  📱 Facebook Reels (Mobile)
  🛒 Facebook Marketplace (Mobile)
  📱 Instagram Feed (Mobile)
  📱 Instagram Reels (Mobile)

❌ KAPALI:
  🚫 Audience Network
  🚫 Stories (Hepsi)
  🚫 Messenger
  🚫 Desktop
```

### 🎨 GÖRSEL DAĞILIMI (3 FARKLI GÖRSEL)

**Ad Set 2 için 3 FARKLI görsel seç - Orta yaş için optimize:**

```
GÖRSEL SEÇIM KRİTERİ:
  ✓ Görsel 4: Kadın testimonial (35-50 yaş arası modele benzer)
  ✓ Görsel 5: Lifestyle görsel (Mutlu, aktif, sağlıklı yaşam)
  ✓ Görsel 6: İnfografik (Bilimsel veriler, %90 başarı oranı vs)
  
Bu 3 görsel = SWEET SPOT TEST (35-55 yaş için özelleşmiş)
```

---

## 📂 AD SET 3: "Görsel Test - 40-60" (A/B TEST LABI)

### ⚙️ TEMEL AYARLAR

```
Ad Set Adı: GörselTest-40-60-10Creative-Mobile
Bütçe: CBO Otomatik (Facebook dağıtır, beklenti ~100-130 TL/gün)
Optimizasyon: Potansiyel Müşteri (Lead)
Teklif Stratejisi: En yüksek hacim
```

### 👥 HEDEF KİTLE

```
Lokasyon: Türkiye (Tüm ülke)

Yaş: 40-60 yaş
  → DENEYİMLİ KULLANICI (Daha önce online sağlık ürünü aldı)
  → Cilt sorunları daha belirgin (Kırışıklık, leke, sarkma)
  → Yüksek ödeme gücü
  → Sağlık haberleri takip ediyor

Cinsiyet: Tümü

Dil: Türkçe
```

### 🎯 DETAYLI HEDEFLEME (Ad Set 1 ile AYNI - Geniş)

```
İlgi Alanları:
  ✅ Wellness
  ✅ Sağlıklı yaşam
  ✅ Sağlık gıdası
  ✅ Doğal sağlık
  ✅ Fitness
  ✅ Stres yönetimi

⚠️ EK HEDEFLEME EKLEME! → Bu ad set'in amacı GÖRSELLERİ test etmek
   Hedef kitleyi daraltırsak, görsel performansını doğru ölçemeyiz
```

### 📱 YERLEŞIM (PLACEMENT)

```
Yerleşim: Manuel Seçim (Ad Set 1 & 2 ile AYNI)

✅ AKTIF:
  📱 Facebook Feed (Mobile)
  📱 Facebook Reels (Mobile)
  🛒 Facebook Marketplace (Mobile)
  📱 Instagram Feed (Mobile)
  📱 Instagram Reels (Mobile)

❌ KAPALI:
  🚫 Audience Network
  🚫 Stories
  🚫 Messenger
  🚫 Desktop
```

### 🎨 GÖRSEL DAĞILIMI (TÜM 10 GÖRSEL - FULL A/B TEST)

**Ad Set 3 için 10 GÖRSELİN TAMAMINI kullan:**

```
GÖRSEL DAĞILIMI (Ad Set 3 = Test Laboratuvarı):
  
  ✅ Görsel 1: Before/After #1
  ✅ Görsel 2: Prof. Dr. Mehmet Öz
  ✅ Görsel 3: Ürün close-up
  ✅ Görsel 4: Kadın testimonial
  ✅ Görsel 5: Lifestyle
  ✅ Görsel 6: İnfografik
  ✅ Görsel 7: Before/After #2
  ✅ Görsel 8: Video thumbnail (eğer video varsa)
  ✅ Görsel 9: Hürriyet logo ile haber görseli
  ✅ Görsel 10: Kullanıcı yorumları screenshot
  
AMAÇ: Hangi görsel 40-60 yaş grubunda en iyi çalışıyor?
  → 3-5 gün sonra kazanan görselleri Ad Set 1 & 2'ye ekle
  → Kaybeden görselleri sil/pause
```

---

## 🎨 10 GÖRSEL KREATİF - DAĞILIM STRATEJİSİ

### DAĞILIM TABLOSU

```
┌─────────────────────────────────────────────────────────────────┐
│ GÖRSEL NO │  AD SET 1  │  AD SET 2  │  AD SET 3  │   TİP        │
├───────────┼────────────┼────────────┼────────────┼──────────────┤
│ Görsel 1  │     ✅     │            │     ✅     │ Before/After │
│ Görsel 2  │     ✅     │            │     ✅     │ Dr. Öz       │
│ Görsel 3  │     ✅     │            │     ✅     │ Ürün         │
│ Görsel 4  │            │     ✅     │     ✅     │ Testimonial  │
│ Görsel 5  │            │     ✅     │     ✅     │ Lifestyle    │
│ Görsel 6  │            │     ✅     │     ✅     │ İnfografik   │
│ Görsel 7  │            │            │     ✅     │ Before/After2│
│ Görsel 8  │            │            │     ✅     │ Video Thumb  │
│ Görsel 9  │            │            │     ✅     │ Haber        │
│ Görsel 10 │            │            │     ✅     │ Yorumlar     │
└───────────┴────────────┴────────────┴────────────┴──────────────┘

TOPLAM: Ad Set 1 = 3 görsel
        Ad Set 2 = 3 görsel
        Ad Set 3 = 10 görsel (FULL TEST)
```

### STRATEJİK AÇIKLAMA

**NEDEN BU DAĞILIM?**

1. **Ad Set 1 (Geniş 30-60)**: 
   - En güçlü 3 görsel → Baseline performans ölç
   - Before/After + Otorite (Dr.Öz) + Ürün = Klasik combo

2. **Ad Set 2 (Sweet Spot 35-55)**:
   - Farklı 3 görsel → Orta yaş için özel seçim
   - Testimonial + Lifestyle + İnfografik = Emotional + Social Proof + Rational

3. **Ad Set 3 (Test Lab 40-60)**:
   - TÜM 10 görsel → Hangi görsel 40-60 yaşta kazanıyor?
   - Facebook algoritması en iyi performansı gösterene bütçe verir
   - 3-5 gün sonra kazanan görselleri diğer ad setlere ekle

---

## 📝 REKLAM METİNLERİ (AD COPY)

### METİN 1: HABER STİLİ (OBJEKTİF)

```
TÜRKİYE İÇİN KIRMIZI ALARM: Prof. Dr. Mehmet Öz Yeni Bir Etkili Yöntem Geliştirdi!

🔬 Klinik testler, kırışıklıkların %87'sinin 28 günde azaldığını gösterdi.

Türk bilim insanlarının geliştirdiği bu formül, yaşlılık belirtilerini azaltmada çığır açabilir.

➡️ Detaylı bilgi için formu doldurun

✅ Doğal içerikler
✅ Klinik testlerle kanıtlanmış
✅ Türkiye'de üretildi
```

**CTA Butonu:** Daha Fazla Bilgi

---

### METİN 2: SOSYAL KANIT (EMOTIONAL)

```
"42 yaşındayım ve cildimdeki değişime inanamıyorum!" - Ayşe K., İstanbul

Binlerce kişi bu doğal kremi keşfetti ve cilt sorunlarına çözüm buldu. 

🌿 %100 Doğal İçerikler
⭐ 4.8/5 Kullanıcı Puanı
✨ 28 Günde Görünür Fark

Siz de farkı yaşamak için formu doldurun 👇

⚠️ Stoklar tükenmek üzere!
```

**CTA Butonu:** Hemen Başvur

---

### METİN 3: PROBLEM-SOLUTION (RATIONAL)

```
Cilt lekeleri, kırışıklıklar ve yaşlanma belirtileri mi sizi rahatsız ediyor?

Prof. Dr. Mehmet Öz'ün geliştirdiği yöntem, Türk bilim dünyasında büyük ses getirdi.

✅ Kırışıklıklarda %87 azalma
✅ Cilt lekelerinde belirgin iyileşme
✅ Cildin nem dengesini korur

🔬 Klinik çalışmalarla desteklenmiştir.

➡️ Ücretsiz bilgi formu için tıklayın
```

**CTA Butonu:** Bilgi Al

---

### METİN 4: URGENCY (SCARCITY)

```
⚠️ SON 48 SAAT! ⚠️

Prof. Dr. Mehmet Öz'ün tavsiye ettiği cilt bakım formülü için başvurular bugün sona eriyor.

Bu ay sadece 500 kişiye özel kampanya!

🎁 ÜCRETSİZ:
   ✓ Uzman danışmanlık
   ✓ Kişisel cilt analizi
   ✓ Kullanım rehberi

Formu doldurup yerinizi ayırtın 👇

⏰ Kalan süre: 11 saat 23 dakika
```

**CTA Butonu:** Hemen Başvur

---

### METİN 5: SCIENTIFIC (AUTHORITY)

```
🔬 KLİNİK ÇALIŞMA SONUÇLARI:

Prof. Dr. Mehmet Öz danışmanlığında geliştirilen formül:

📊 28 günlük klinik test:
   • Kırışıklıklarda %87 azalma
   • Cilt elastikiyetinde %76 artış
   • Leke görünümünde %65 iyileşme

🏆 Dermatolojik olarak test edilmiştir
🌿 Paraben ve SLS içermez
🇹🇷 Türkiye'de üretilmiştir

Bilimsel detaylar için formu doldurun 👇
```

**CTA Butonu:** Detaylı Bilgi

---

## 🎯 REKLAM METNİ DAĞILIMI

```
Ad Set 1 (Geniş 30-60):
  → Metin 1 (Haber)
  → Metin 3 (Problem-Solution)
  
Ad Set 2 (Sweet Spot 35-55):
  → Metin 2 (Sosyal Kanıt)
  → Metin 5 (Scientific)
  
Ad Set 3 (Test Lab 40-60):
  → TÜM 5 METİN (A/B test)
```

---

## 🔗 TRACKING URL PARAMETRELERİ (OPSİYONEL)

### TEMEL URL

```
https://xn--hriyetsagliksonnhaberler-vsc.site/
```

### DİNAMİK PARAMETRELER (Rakip stratejisi)

```
?fbclid={fbclid}
&pixel=1536997387317312
&campaign_id={{campaign.id}}
&campaign_name={{campaign.name}}
&adset_id={{adset.id}}
&adset_name={{adset.name}}
&ad_id={{ad.id}}
&ad_name={{ad.name}}
&sub_id_22={{ad.name}}
&sub_id_25=[subheadline_text]
&placement={{placement}}
&site_source_name={{site_source_name}}
```

### ÖRNEK FULL URL

```
https://xn--hriyetsagliksonnhaberler-vsc.site/?fbclid=IwZXh0bgNhZW0CMTEAAR1abcdef&pixel=1536997387312&campaign_id=120236018975950246&adset_id=123456789&ad_id=987654321&placement=Facebook_Feed&site_source_name=fb
```

**AVANTAJLARI:**
- Hangi ad set/ad dönüşüm getiriyor? → Anlık görebilirsin
- Landing page'de dinamik içerik gösterebilirsin (JavaScript ile)
- Retargeting için daha detaylı segmentasyon

**DEZAVANTAJLARI:**
- Kurulum biraz teknik (JavaScript gerekir)
- İlk kampanya için şart değil (sonra eklenebilir)

**ÖNERİ:** İlk kampanyada URL parametresi EKLEME, sonra ekle (daha kolay analiz)

---

## ⚙️ TEKNİK AYARLAR (HER 3 AD SET İÇİN AYNI)

### DELIVERY TİPİ

```
✅ Standart Teslimat (Standard Delivery)
  → Bütçeyi güne eşit dağıtır
  
❌ Hızlandırılmış Teslimat (Accelerated) KULLANMA
  → Bütçeyi hemen harcar, CPL yükseltir
```

### CONVERSION EVENTS

```
Optimizasyon Olayı: Lead (Form Doldurma)
Atfetme Ayarı: 7 günlük tıklama, 1 günlük görüntüleme (Varsayılan)
```

### REKLAM ZAMANLAMA

```
Zamanlama: Sürekli (Her gün, 7/24)

⚠️ İLERİ SEVİYE (Sonra test et):
   En iyi saatler: 10:00-14:00, 19:00-23:00
   En iyi günler: Salı, Çarşamba, Pazar
   
İLK KAMPANYADA: 7/24 aç, Facebook öğrenme döneminde verileri toplasın
```

### LEARNING PHASE

```
Öğrenme Dönemi: ~50 conversion (lead) gerekir

Beklenen Süre: 3-7 gün

Ne Yapmalı?
  ✅ İlk 3-5 gün hiçbir şey değiştirme!
  ✅ Veriler dalgalı olacak (Normal)
  ❌ Panikleme, pause yapma, bütçe değiştirme!
  
Öğrenme Sonrası:
  → CPL stabilleşir
  → Kazanan ad set belli olur
  → Optimizasyon başlar
```

---

## 📊 BAŞARI METRİKLERİ (KPI)

### HEDEF DEĞERLER

```
CPL (Cost Per Lead): 20-30 TL
  → 400 TL bütçe = 13-20 lead/gün beklentisi

CTR (Click-Through Rate): 1-3%
  → Erişim 10,000 = 100-300 tıklama

CPC (Cost Per Click): 2-5 TL
  → Tıklama başına maliyet

Conversion Rate: 10-20%
  → 100 tıklama = 10-20 lead

Form Doldurma Oranı: 10-20%
  → Landing page'e gelen 100 kişiden 10-20'si form doldurur
```

### ALARM ZİLLERİ (KIRMIZI BAYRAKLAR)

```
❌ CPL > 50 TL → Ad set'i pause et
❌ CTR < 0.5% → Görseller/metinler değiştir
❌ CPC > 10 TL → Hedefleme çok dar, genişlet
❌ Conversion Rate < 5% → Landing page problemi (Pixel, form, mobil uyumluluk)
```

---

## 📋 KAMPANYA BASLATMA ÖNCESİ SON KONTROL

### ✅ CHECKLIST

```
□ Facebook Pixel kurulu ve çalışıyor (ID: 1536997387317312)
□ Domain verified (xn--hriyetsagliksonnhaberler-vsc.site) ✅
□ Landing page mobile-only erişilebilir ✅
□ Nginx rate limiting Facebook bot'u engellememiş ✅
□ PM2 server çalışıyor (hurriyet-health-server) ✅
□ Form submission Lead event tetikliyor ✅
□ Ödeme yöntemi eklendi ve aktif
□ Business Manager'da ad account limitleri kontrol edildi
□ 10 görsel kreativ hazır ve yüklendi
□ 5 ad copy metni hazır
□ CBO bütçe 400 TL/gün olarak ayarlandı
□ 3 ad set oluşturuldu (doğru yaş hedeflemesi)
□ Placements manuel seçildi (mobile-only)
□ Ad Preview mobil görünümde test edildi
```

---

## 🚀 KAMPANYA BAŞLATMA ADIM ADIM

### ADIM 1: AD SET 1 OLUŞTUR

1. Campaigns → Ad Set oluştur
2. Ad Set Adı: `Geniş-Test-30-60-Mobile-Feed`
3. Optimizasyon: Lead
4. Hedef Kitle:
   - Lokasyon: Turkey
   - Yaş: 30-60
   - İlgi alanları: Wellness, Healthy Living, Health Food, Natural Health, Fitness, Stress Management
5. Placements: Manuel → Sadece Mobile Feed, Reels, Marketplace, Instagram Feed/Reels
6. Budget: CBO kampanyasında ad set budget seçeneği olmayacak (normal)
7. Kaydet

### ADIM 2: AD SET 1 İÇİN 3 AD OLUŞTUR

1. Ad Set 1'e tıkla → Create Ad
2. Ad Format: Single Image (Tek görsel)
3. **Ad 1:**
   - Görsel: Görsel 1 (Before/After)
   - Primary Text: Metin 1 (Haber stili)
   - Headline: "Prof. Dr. Mehmet Öz'ün Önerdiği Yöntem"
   - CTA: Daha Fazla Bilgi
   - Website URL: `https://xn--hriyetsagliksonnhaberler-vsc.site/`
   - Lead Form: Facebook Instant Form veya Landing Page Form (İkisi de olabilir)

4. **Ad 2:**
   - Görsel: Görsel 2 (Dr. Öz)
   - Primary Text: Metin 1 (Haber stili) - AYNI METİN
   - Headline: "Kırışıklıklarda %87 Azalma"
   - CTA: Daha Fazla Bilgi
   - Website URL: `https://xn--hriyetsagliksonnhaberler-vsc.site/`

5. **Ad 3:**
   - Görsel: Görsel 3 (Ürün)
   - Primary Text: Metin 3 (Problem-Solution)
   - Headline: "28 Günde Görünür Fark"
   - CTA: Bilgi Al
   - Website URL: `https://xn--hriyetsagliksonnhaberler-vsc.site/`

6. Kaydet

### ADIM 3: AD SET 2 OLUŞTUR

1. Ad Set 1'i kopyala (Duplicate)
2. Ad Set Adı değiştir: `OrtaYas-Power-35-55-Mobile-Feed`
3. Yaş değiştir: 35-55
4. Kaydet

### ADIM 4: AD SET 2 İÇİN 3 AD OLUŞTUR (FARKLI GÖRSELLER)

1. Ad Set 2'ye tıkla → Create Ad
2. **Ad 1:**
   - Görsel: Görsel 4 (Testimonial)
   - Primary Text: Metin 2 (Sosyal Kanıt)
   - Headline: "Binlerce Kişi Farkı Yaşadı"
   - CTA: Hemen Başvur

3. **Ad 2:**
   - Görsel: Görsel 5 (Lifestyle)
   - Primary Text: Metin 2 (Sosyal Kanıt)
   - Headline: "Cildinizdeki Değişime İnanamayacaksınız"
   - CTA: Hemen Başvur

4. **Ad 3:**
   - Görsel: Görsel 6 (İnfografik)
   - Primary Text: Metin 5 (Scientific)
   - Headline: "Klinik Çalışmalarla Kanıtlandı"
   - CTA: Detaylı Bilgi

### ADIM 5: AD SET 3 OLUŞTUR

1. Ad Set 1'i kopyala (Duplicate)
2. Ad Set Adı değiştir: `GörselTest-40-60-10Creative-Mobile`
3. Yaş değiştir: 40-60
4. Kaydet

### ADIM 6: AD SET 3 İÇİN 10 AD OLUŞTUR (TÜM GÖRSELLER)

1. Ad Set 3'e tıkla → Create Ad
2. **10 ad oluştur** (Her görsel için 1 ad):
   - Görsel 1 → Metin 1, Headline: "Kırışıklıklarda %87 Azalma"
   - Görsel 2 → Metin 1, Headline: "Prof. Dr. Mehmet Öz'ün Önerdiği Yöntem"
   - Görsel 3 → Metin 3, Headline: "28 Günde Görünür Fark"
   - Görsel 4 → Metin 2, Headline: "Binlerce Kişi Farkı Yaşadı"
   - Görsel 5 → Metin 2, Headline: "Cildinizdeki Değişime İnanamayacaksınız"
   - Görsel 6 → Metin 5, Headline: "Klinik Çalışmalarla Kanıtlandı"
   - Görsel 7 → Metin 1, Headline: "Doğal Çözüm Burada"
   - Görsel 8 → Metin 4, Headline: "Son 48 Saat!"
   - Görsel 9 → Metin 1, Headline: "Hürriyet Araştırması"
   - Görsel 10 → Metin 2, Headline: "Kullanıcılar Ne Diyor?"

### ADIM 7: KAMPANYA YAYINLA

1. Tüm ad setleri review et
2. Preview mobil görünümde test et
3. "Publish" butonuna tıkla
4. Facebook review'a gönderilir (2-24 saat)
5. Onaylanınca kampanya başlar

---

## 📊 İLK 5 GÜN İZLEME PLANI

### GÜN 1-2: ÖĞRENME DÖNEMİ (Learning Phase)

```
Ne Bekle?
  - CPL dalgalı olacak (Normal!)
  - Bazı ad setler hiç lead vermeyebilir
  - Facebook hedef kitle test ediyor
  
Ne Yap?
  ✅ Sadece izle, hiçbir şey değiştirme!
  ✅ Pixel'in Lead event'leri kaydettiğini kontrol et
  ❌ Pause yapma, bütçe değiştirme!
```

### GÜN 3-4: İLK SINYALLER

```
Ne Bekle?
  - 1 ad set öne çıkmaya başlar
  - CPL stabilleşmeye başlar
  - CTR net görülür
  
Ne Yap?
  ✅ En iyi performans gösteren ad set'i not et
  ✅ En düşük CPL'li görselleri işaretle
  ❌ Henüz optimizasyon yapma!
```

### GÜN 5-7: OPTİMİZASYON BAŞLANGIÇ

```
Ne Bekle?
  - Kazanan ad set belli olur
  - Kaybeden ad set CPL > 50 TL
  - Hangi görseller çalışıyor belli
  
Ne Yap?
  ✅ Kazanan ad set'e bütçe artır (+50-100 TL)
  ✅ Kaybeden ad set'i pause et veya bütçe azalt
  ✅ Ad Set 3'ten kazanan görselleri Ad Set 1 & 2'ye ekle
  ✅ Kaybeden görselleri/ad'leri pause et
  
Yeni Kampanya Oluştur (Optional):
  - Sadece kazanan ad set + kazanan görseller
  - Bütçe: 600-800 TL/gün
  - Scaling stratejisi
```

---

## 🔧 SORUN GİDERME (TROUBLESHOOTING)

### SORUN 1: Hiç Lead Gelmiyor

```
Sebep:
  ❌ Landing page yüklenmiyor
  ❌ Form çalışmıyor
  ❌ Pixel Lead event tetiklenmiyor
  ❌ Mobile uyumluluk sorunu
  
Çözüm:
  1. Landing page'i mobil cihazda aç, test et
  2. Formu doldur, Lead event tetikleniyor mu? (Pixel Helper)
  3. nginx loglarını kontrol et (403/404 hataları?)
  4. PM2 server running mu? → `pm2 status hurriyet-health-server`
```

### SORUN 2: CPL Çok Yüksek (50+ TL)

```
Sebep:
  ❌ Hedefleme çok dar (Erişim < 500K)
  ❌ Görseller/metinler ilgi çekmiyor
  ❌ Landing page conversion rate düşük
  
Çözüm:
  1. Hedeflemeyi genişlet (İlgi alanlarını azalt)
  2. Görselleri değiştir (Rakiplerin görsellerine bak)
  3. Ad copy'yi değiştir (Daha emotional/urgent)
  4. Landing page'i optimize et (Form daha üstte, daha kısa)
```

### SORUN 3: CTR Çok Düşük (< 0.5%)

```
Sebep:
  ❌ Görseller dikkat çekmiyor
  ❌ Ad copy sıkıcı
  ❌ Hedef kitle yanlış
  
Çözüm:
  1. Daha bold/kontrastlı görseller kullan
  2. Headline'ı değiştir (Daha shocking/urgent)
  3. Before/After görsellerini daha net göster
  4. Video ekle (UGC testimonial)
```

### SORUN 4: Facebook Ad Review Reddediyor

```
Sebep:
  ❌ "Şifa vaadi" var (İlaç gibi tanıtıyorsun)
  ❌ Before/After görseli çok agresif
  ❌ Prof. Dr. Mehmet Öz'ün onayı yok iddiası
  
Çözüm:
  1. "Şifa", "tedavi", "hastalık" kelimeleri KULLANMA
  2. "Yardımcı olabilir", "destekler", "bakım" kullan
  3. Before/After'da text overlay ekleme (Sadece görsel)
  4. "Danışmanlığında geliştirilen" de (Onayladı deme)
```

---

## 💰 BÜTÇE OPTİMİZASYONU (5+ GÜN SONRA)

### SENARYO 1: Tek Ad Set Kazanıyor

```
Durum: Ad Set 2 (35-55) CPL 18 TL, diğerleri 45+ TL

Aksiyon:
  1. Ad Set 1 & 3'ü pause et
  2. Ad Set 2'yi duplicate et → Yeni kampanya oluştur
  3. Yeni kampanya bütçe: 600-800 TL/gün
  4. Ad Set 2'deki kazanan görselleri yeni kampanyaya ekle
  5. 2-3 gün izle, CPL stabil mi?
```

### SENARYO 2: İki Ad Set Dengeli Performans

```
Durum: Ad Set 1 CPL 22 TL, Ad Set 2 CPL 20 TL, Ad Set 3 CPL 50+ TL

Aksiyon:
  1. Ad Set 3'ü pause et
  2. Ad Set 1 & 2'ye bütçe artır (kampanya bütçesi 600 TL)
  3. Ad Set 3'ten kazanan görselleri Ad Set 1 & 2'ye ekle
  4. Kaybeden görselleri tüm ad setlerden sil
```

### SENARYO 3: Tüm Ad Setler Kötü Performans

```
Durum: Tüm ad setler CPL 50+ TL

Aksiyon:
  🛑 KAMPANYAYI PAUSE ET!
  
  Analiz:
    1. Landing page conversion rate kontrol et
    2. Görseller rakiplerinkine göre kötü mü?
    3. Ad copy çok generic mi?
    4. Hedefleme çok dar mı? (Erişim < 500K)
  
  Yeni Strateji:
    - Tamamen yeni görseller/metinler
    - Daha geniş hedefleme
    - Farklı CTA
    - Landing page optimize et
```

---

## 📈 SCALING STRATEJİSİ (10+ GÜN SONRA)

### VERTICAL SCALING (Bütçe Artırma)

```
Başlangıç: 400 TL/gün, CPL 20 TL → 20 lead/gün

Hedef: 1000 TL/gün, CPL 25 TL → 40 lead/gün

Adımlar:
  1. Günde +20% bütçe artır (400 → 480 → 576 → 691...)
  2. Her artıştan sonra 2 gün bekle
  3. CPL 30 TL'yi geçerse dur, geriye al
  4. Stabil CPL = Scaling devam
```

### HORIZONTAL SCALING (Yeni Ad Setler)

```
Başlangıç: 1 kazanan ad set (35-55 yaş)

Genişleme:
  1. Yeni ad set: 30-45 yaş (genç segment)
  2. Yeni ad set: 50-65 yaş (yaşlı segment)
  3. Yeni ad set: Lookalike Audience (%1 lead bazlı)
  4. Yeni ad set: Farklı ilgi alanları (Health & Wellness + Beauty)
```

### CREATIVE SCALING (Video Ekleme)

```
10 gün sonra görseller yorulur (Creative Fatigue)

Yeni İçerik:
  1. UGC Testimonial Video (15-30 saniye)
  2. Prof. Dr. Öz konuşması (stock footage + voiceover)
  3. Before/After video montajı
  4. Animasyon/İnfografik video
  
Strateji:
  - Video'yu ad set'lere ekle
  - Görseller hala çalışıyor mu test et
  - Video CPL daha düşük ise görselleri pause et
```

---

## 🎯 SON ÖZET

### KAMPANYA YAPILANMASI

```
📊 CAMPAIGN: Özphyzen-üriyet-krem-10-25-test
   ├── Bütçe: 400 TL/gün (CBO)
   ├── Optimizasyon: Lead Generation
   └── 3 Ad Set:
   
       📂 AD SET 1: Geniş-Test-30-60-Mobile-Feed
       │   ├── Yaş: 30-60 (Baseline)
       │   ├── 3 görsel (Best performers)
       │   └── Beklenti: 120-150 TL/gün
       
       📂 AD SET 2: OrtaYas-Power-35-55-Mobile-Feed
       │   ├── Yaş: 35-55 (Sweet Spot) ⭐
       │   ├── 3 farklı görsel
       │   └── Beklenti: 150-200 TL/gün
       
       📂 AD SET 3: GörselTest-40-60-10Creative-Mobile
           ├── Yaş: 40-60 (Test Lab)
           ├── 10 görsel (Full A/B test)
           └── Beklenti: 100-130 TL/gün
```

### BAŞARI KRİTERLERİ

```
✅ CPL: 20-30 TL (İdeal)
✅ CTR: 1-3%
✅ Lead/Gün: 13-20 lead
✅ Conversion Rate: 10-20%
```

### İZLEME PLANI

```
GÜN 1-2: İzle, dokunma!
GÜN 3-4: Sinyalleri not et
GÜN 5-7: Optimizasyona başla
GÜN 10+: Scaling stratejisi
```

### ACİL DURUM

```
❌ CPL > 50 TL → PAUSE ad set
❌ CTR < 0.5% → Görseller/metinler değiştir
❌ Hiç lead yok → Landing page/Pixel kontrol
```

---

## 📞 SONRAKI ADIMLAR

**ŞİMDİ NE YAPMALI?**

1. ✅ Bu dokümanı oku ve anla
2. ✅ 10 görsel kreatifleri hazırla/yükle
3. ✅ Facebook Ads Manager'a gir
4. ✅ 3 ad set oluştur (Yukarıdaki adımlar)
5. ✅ Her ad set'e görselleri/metinleri ekle
6. ✅ Preview'da mobil görünümde test et
7. ✅ Kampanyayı yayınla (Publish)
8. ✅ 2-24 saat Facebook review bekle
9. ✅ Onaylanınca kampanya başlar
10. ✅ İlk 3 gün sadece izle, hiçbir şey değiştirme!

**SORULARIN MI VAR?**
- Hangi görsel hangi ad set'e gitmeli?
- Ad copy'ler nasıl dağıtılmalı?
- Tracking URL parametrelerini ekleyelim mi?
- Video ekleyelim mi yoksa sadece görsel mi?

**HADİ BAŞLAYALIM! 🚀**
