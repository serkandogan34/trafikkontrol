# 🎯 META VERİ KAYNAĞI KATEGORİSİ DEĞİŞTİRME - ADIM ADIM

**Tarih**: 2025-10-17  
**Durum**: 🔴 ACİL - Şu anda Meta Business Suite'tesiniz  
**Hedef**: Kategoriyi "General wellness" olarak değiştirmek

---

## 📍 **ŞU ANDA NEREDESİNİZ**

```
✅ Meta Business Suite Ana Sayfa
   URL: business.facebook.com/latest/home
   Sayfa: "Sağlıklı yaşam için her şey"
```

Soldaki menüde şunları görüyorsunuz:
- Sağlıklı yaşam... (Dropdown)
- Reklam Yöneticisi
- Gelen kutusu
- İçerik
- Yaratıcı pazar yeri
- Planlayıcı
- Reklamlar
- Görüşler
- Tüm araçlar

---

## 🎯 **HEDEF: EVENTS MANAGER'A GİTMEK**

### **YÖNTEM 1: Soldaki Menüden (En Kolay)**

#### **ADIM 1: "Tüm araçlar" tıklayın**
```
Sol menüde en altta:
☰ Tüm araçlar
```

#### **ADIM 2: "Events Manager" bulun**
```
Açılan listede arayın:
📊 Events Manager (Etkinlik Yöneticisi)

veya

🔍 Arama kutusuna yazın: "Events Manager"
```

#### **ADIM 3: Events Manager'ı açın**
```
Tıklayın ve sayfa yüklensin
```

---

### **YÖNTEM 2: Direkt URL (En Hızlı)**

Tarayıcı adres çubuğuna yapıştırın:

```
https://business.facebook.com/events_manager2/list/pixel/1536997377317312/overview
```

veya

```
https://business.facebook.com/events_manager2/
```

**Enter'a basın** ve Events Manager açılsın.

---

## 📊 **EVENTS MANAGER'DA YAPILACAKLAR**

### **ADIM 1: Veri Kaynağınızı Bulun**

Events Manager açıldığında sol tarafta göreceksiniz:

```
📊 Data Sources (Veri Kaynakları)

Listede bulunacak:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Pixel: 1536997377317312
Domain: xn--hriyetsagliksonnhaberler-vsc.site
       (veya hüriyetsagliksonnhaberler.site)
```

**Bu veri kaynağını tıklayın.**

---

### **ADIM 2: Settings (Ayarlar) Sekmesine Gidin**

Üst menüde göreceksiniz:

```
Overview | Events | Settings | Test Events
                      ↑
                   BURAYA TIKLAYIN
```

**"Settings" tıklayın.**

---

### **ADIM 3: "Veri Kaynağı Kategorisi" Bulun**

Settings sayfasında aşağı kaydırın ve şunu bulun:

```
┌─────────────────────────────────────────────────┐
│ 📋 Veri kaynağı kategorileri                    │
│                                                 │
│ Veri kaynaklarınızın kategorilerini yönetin    │
│                                                 │
│ ➤ Veri kaynağını kategorilerini yönet          │
└─────────────────────────────────────────────────┘
```

**"Veri kaynağını kategorilerini yönet" linkine tıklayın.**

---

### **ADIM 4: Kategoriyi Değiştirin**

Açılan popup'ta göreceksiniz:

```
┌─────────────────────────────────────────────────┐
│ Veri kaynağı kategorileri                       │
├─────────────────────────────────────────────────┤
│                                                 │
│ Veri kaynağınızın kategorilerini seçin         │
│                                                 │
│ Kanal: Web sitesi                               │
│                                                 │
│ Kategori: [DROPDOWN MENU]                      │
│   Şu anda: "Sağlık ve zindelik - diğer" ❌     │
│                                                 │
│ İnceleme Durumu: [DROPDOWN MENU]               │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

#### **4A. Kategori Dropdown'u Açın**

"Kategori" yanındaki dropdown ok'a tıklayın.

Açılan listede göreceksiniz:

```
📂 Kategori seçin:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
○ Alkollü içecekler
○ E-commerce
  ├─ Apparel & Accessories
  ├─ Beauty & Personal Care
  ├─ Health & Beauty ← BU DA OLABİLİR ✅
  └─ ...
○ Eğitim
○ Emlak
○ Finansal hizmetler
○ Haber ve eğlence
○ Health & wellness
  ├─ General wellness ← BU İDEAL ✅
  ├─ Health conditions
  └─ ...
○ İş ve endüstri
○ Otomotiv
○ Sağlık ve zindelik
  ├─ Sağlık ve zindelik - diğer ← ŞU AN BU (YANLIŞ) ❌
  └─ ...
○ Seyahat
○ Teknoloji
```

---

#### **4B. Doğru Kategoriyi Seçin**

**SEÇİM 1 (EN ÖNERİLEN):**
```
"Health & wellness" → "General wellness" ✅

Neden?
• Genel sağlık ürünleri için ideal
• Veri kısıtlaması yok
• Vitamin, takviye, fitness ürünleri için
• Meta hassas veri olarak görmez
```

**SEÇİM 2 (ALTERNATİF):**
```
"E-commerce" → "Health & Beauty" ✅

Neden?
• E-ticaret kategorisi güvenli
• Sağlık & güzellik ürünleri
• Veri paylaşımı serbest
• Hassas veri kısıtlaması yok
```

**ASLA SEÇME:**
```
"Sağlık ve zindelik" → "Sağlık ve zindelik - diğer" ❌

Neden?
• Meta hassas sağlık verisi olarak görür
• Otomatik veri kısıtlaması
• Lead'ler bloklanır
• Conversion tracking çalışmaz
```

---

#### **4C. İnceleme Durumunu Ayarlayın (Opsiyonel)**

```
İnceleme Durumu: [DROPDOWN]

Önerilen:
○ İnceleme yapılmadı
○ İnceleme tamamlandı ✅ (eğer reklam onaylandıysa)
```

**Not:** Bu alan zorunlu değil, boş bırakılabilir.

---

### **ADIM 5: Kaydedin ve Onaylayın**

```
┌─────────────────────────────────────────────────┐
│                                                 │
│ [ İptal ]              [ Kaydet ] ← TIKLAYIN   │
│                                                 │
└─────────────────────────────────────────────────┘
```

**"Kaydet" butonuna tıklayın.**

---

### **ADIM 6: Onay Mesajı**

Başarılı olursa göreceksiniz:

```
✅ Veri kaynağı kategorisi güncellendi

Kategori: General wellness
Kanal: Web sitesi
```

---

## ⏱️ **BEKLENTİLER**

### **Hemen Sonra (0-5 dakika)**
```
• Değişiklik kaydedildi
• Meta sistemi güncelleniyor
```

### **10-30 Dakika İçinde**
```
✅ Yeni kategori aktif oldu
✅ Veri kısıtlamaları kalktı
✅ Lead event'leri akabilir
```

### **1-2 Saat İçinde**
```
✅ Tam stabilizasyon
✅ Conversion tracking normal
✅ CRM'e veri akışı başlar
```

### **24 Saat İçinde**
```
✅ Tüm sistem stabil
✅ Lead'ler düzenli geliyor
✅ ROI ölçülebilir
```

---

## 🧪 **DEĞİŞİKLİK SONRASI TEST**

### **Test 1: Browser Console (5 dakika sonra)**

```javascript
// Tarayıcı console'unda test event gönder
fbq('track', 'Lead', {
    content_name: 'Test After Category Change',
    value: 1,
    currency: 'TRY'
});
```

**Kontrol:**
- Events Manager → Overview
- Son event'lerde "Lead" görünüyor mu?
- Status: "Processed" mi?

---

### **Test 2: Gerçek Form (30 dakika sonra)**

```
1. https://hüriyetsagliksonnhaberler.site/?key=HUR2024_SecureTest_9K3mP7xQ
2. Formu doldurun (test verileri)
3. Submit edin
4. Events Manager'da görünüyor mu?
5. Webhook'a ulaştı mı?
6. CRM'de kayıt var mı?
```

---

### **Test 3: Kampanya Kontrolü (1 saat sonra)**

```
Ads Manager → Campaigns → Senin Kampanyan

Kontrol Et:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✓ Impressions: Artıyor mu?
✓ Clicks: Var mı?
✓ Leads: GELİYOR MU? ← EN ÖNEMLİ
✓ Cost per lead: Normal mi?
✓ Conversion rate: %1-3 arası mı?
```

---

## 🚨 **EĞER HALA LEAD GELMİYORSA**

### **Kontrol 1: Pixel Çalışıyor mu?**

```javascript
// Browser console
fbq('getState')

// Beklenen çıktı:
{
  pixelID: "1536997377317312",
  version: "2.0",
  ...
}
```

---

### **Kontrol 2: Domain Verification**

```
Business Settings → Brand Safety → Domains

Kontrol et:
✓ hüriyetsagliksonnhaberler.site → Verified?
✓ xn--hriyetsagliksonnhaberler-vsc.site → Verified?
```

---

### **Kontrol 3: Event Setup Tool**

```
Events Manager → Test Events

1. Pixel ID gir: 1536997377317312
2. "Open Event Setup Tool" tıkla
3. Landing page'i aç
4. Form doldur ve gönder
5. Event yakalandı mı?
```

---

### **Kontrol 4: Webhook Test**

```bash
# Terminal'de test
curl -X POST https://n8nwork.dtekai.com/webhook/bc74f59e-54c2-4521-85a1-6e21a0438c31 \
  -H "Content-Type: application/json" \
  -d '{
    "customerName": "Test Kategori Sonrası",
    "phoneNumber": "5551234567",
    "timestamp": "2025-10-17T06:00:00Z"
  }'

# Başarılı ise:
{"success": true}
```

---

## 📊 **BAŞARI KRİTERLERİ**

### **Kategori Değişikliği Başarılı Sayılır Eğer:**

```
✅ Events Manager'da kategori "General wellness" görünüyor
✅ Test event'i 10 dakika içinde Events Manager'a düşüyor
✅ Gerçek form lead'i 30 dakika içinde geliyor
✅ Webhook'a veri ulaşıyor
✅ CRM'de kayıt oluşuyor
✅ Ads Manager'da "Leads" metriği artıyor
```

---

## 🎯 **ÖZET KONTROL LİSTESİ**

```
□ 1. "Tüm araçlar" menüsünden "Events Manager" aç
□ 2. Pixel 1536997377317312'yi seç
□ 3. "Settings" sekmesine git
□ 4. "Veri kaynağını kategorilerini yönet" tıkla
□ 5. Kategori: "General wellness" seç
□ 6. Kaydet
□ 7. 10 dakika bekle
□ 8. Test event gönder (browser console)
□ 9. Events Manager'da event görünüyor mu?
□ 10. Gerçek form test et
□ 11. Webhook'a ulaşıyor mu?
□ 12. 1 saat sonra kampanya lead'lerini kontrol et
```

---

## 📞 **SORUN DEVAM EDERSE**

### **Facebook Destek**

```
1. Business Help Center
   https://business.facebook.com/help/

2. Search: "data source categories lead events"

3. Live Chat (varsa):
   Help (?) → Chat with support

Sor:
"Veri kaynağı kategorisini 'General wellness' olarak 
değiştirdim ama lead event'leri hala gelmiyor. 
Kategori değişikliği ne kadar sürede aktif olur?"
```

---

## 🎯 **SON KONTROL**

### **Değişiklik Öncesi:**
```
❌ Kategori: "Sağlık ve zindelik - diğer"
❌ Lead'ler: 0
❌ Veri kısıtlaması: Aktif
💸 Para: Harcandı ama lead yok
```

### **Değişiklik Sonrası (Beklenen):**
```
✅ Kategori: "General wellness"
✅ Lead'ler: Gelmeye başlar
✅ Veri kısıtlaması: Kaldırıldı
💰 Para: Artık lead getiriyor
```

---

**SON UYARI:**

```
⏰ Her dakika değerli!

Şu anda kampanya çalışıyorsa:
• Her tıklama para harcıyor
• Ama lead gelmiyor
• Bu HEMEN düzeltilmeli

Tahmini süre:
• Kategori değiştirme: 2 dakika
• Değişikliğin aktif olması: 10-30 dakika
• Toplam: 30-45 dakika
```

---

**Doküman Versiyonu**: 1.0  
**Tarih**: 2025-10-17  
**Mevcut Konum**: Meta Business Suite Ana Sayfa  
**Hedef**: Events Manager → Settings → Kategori Değiştir

---

**ŞIMDI HAREKETİN ZAMANI!** 🚀

Yukarıdaki adımları takip edin ve kategoriyi değiştirin.
