# 🚀 hürriyetrehberhaber.store KURULUM REHBERİ

**Tarih**: 2025-10-17  
**Domain**: hürriyetrehberhaber.store  
**Punycode**: xn--hrriyetrehberhaber-tzc.store  
**Tahmini Süre**: 2-3 saat (ilk çalışır hale)  
**Risk Seviyesi**: 🟢 DÜŞÜK - Sağlık kelimesi yok, Meta kilitleme riski yok

---

## 📋 İÇİNDEKİLER

1. [AŞAMA 1: DNS AYARLARI](#aşama-1-dns-ayarlari) (10 dakika)
2. [AŞAMA 2: FACEBOOK PIXEL OLUŞTUR](#aşama-2-facebook-pixel-oluştur) (15 dakika)
3. [AŞAMA 3: NGINX KONFIGÜRASYONU](#aşama-3-nginx-konfigürasyonu) (20 dakika)
4. [AŞAMA 4: SSL SERTİFİKA](#aşama-4-ssl-sertifika) (10 dakika)
5. [AŞAMA 5: LANDING PAGE DEPLOY](#aşama-5-landing-page-deploy) (15 dakika)
6. [AŞAMA 6: TEST ve DOĞRULAMA](#aşama-6-test-ve-doğrulama) (30 dakika)
7. [AŞAMA 7: KAMPANYA TAŞIMA](#aşama-7-kampanya-taşima) (20 dakika)
8. [AŞAMA 8: ESKİ DOMAIN'İ KAPAT](#aşama-8-eski-domaini-kapat) (48 saat sonra)

---

## 🎯 NEDEN YENİ DOMAIN?

```
❌ ESKİ DOMAIN SORUNU:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Domain: xn--hrriyet-salk-3pbh.com (hürriyet-sağlık)
• "sağlık" kelimesi var → Meta otomatik kilitlemiş
• Kategori dropdown'da sadece 3 hassas sağlık kategorisi
• Kategori değiştirilemez
• Tüm lead'ler hassas veri olarak engellenir
• Para harcanıyor ama lead gelmiyor ❌

✅ YENİ DOMAIN ÇÖZÜMÜ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Domain: hürriyetrehberhaber.store
• "rehber + haber" → Medya/bilgi temalı, NÖTR
• Sağlık/hastalık kelimesi YOK
• Meta kategorisi: E-commerce, News, veya General
• Veri kısıtlaması YOK
• Lead'ler normal akacak ✅
```

---

## AŞAMA 1: DNS AYARLARI

### 1.1 Domain Registrar'a Giriş Yapın

Domain'i nereden aldınız? (GoDaddy, Namecheap, CloudFlare, vs.)

### 1.2 DNS Kayıtlarını Ekleyin

**Sunucu IP'sini öğrenin:**
```bash
# SSH ile sunucuya bağlanın
ssh root@SUNUCU_IP

# Sunucu IP'sini kontrol edin
curl -4 ifconfig.me
# VEYA
hostname -I
```

**DNS Kayıtları:**

```
TIP: A RECORD (IPv4)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Host/Name: @
Type: A
Value: [SUNUCU_IP]
TTL: 300 (5 dakika - test için kısa)

Host/Name: www
Type: A
Value: [SUNUCU_IP]
TTL: 300

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TIP: CAA RECORD (SSL için)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Host/Name: @
Type: CAA
Value: 0 issue "letsencrypt.org"
TTL: 300

Host/Name: @
Type: CAA
Value: 0 issuewild "letsencrypt.org"
TTL: 300
```

**⚠️ PUNYCODE ÖNEMLİ:**
- Domain registrar'da `hürriyetrehberhaber.store` olarak görünecek
- Arka planda `xn--hrriyetrehberhaber-tzc.store` olarak işlem yapılacak
- DNS kayıtları her iki formatta da çalışır

### 1.3 DNS Propagation Kontrol

**10-30 dakika bekleyin, sonra test edin:**

```bash
# DNS çalışıyor mu?
dig +short xn--hrriyetrehberhaber-tzc.store

# Beklenen çıktı: SUNUCU_IP
# Örnek: 185.123.45.67

# www alt domain da çalışıyor mu?
dig +short www.xn--hrriyetrehberhaber-tzc.store

# Her iki DNS de aynı IP'yi göstermeli
```

**DNS çalışmazsa:**
```bash
# DNS nameserver kontrol
dig NS xn--hrriyetrehberhaber-tzc.store

# TTL kontrol
dig xn--hrriyetrehberhaber-tzc.store | grep TTL

# Trace kontrol
dig +trace xn--hrriyetrehberhaber-tzc.store
```

---

## AŞAMA 2: FACEBOOK PIXEL OLUŞTUR

### 2.1 Yeni Pixel Oluştur

1. **Facebook Business Manager'a git:**
   - https://business.facebook.com/

2. **Events Manager'ı aç:**
   - Sol menüden "Events Manager" seç
   - VEYA: https://business.facebook.com/events_manager2

3. **Yeni Data Source ekle:**
   - Yeşil buton: "Connect Data Sources"
   - "Web" seç
   - "Facebook Pixel" seç
   - "Connect" tıkla

4. **Pixel'e isim ver:**
   ```
   İsim: Hürriyet Rehber Haber - 2024
   Website URL: https://xn--hrriyetrehberhaber-tzc.store
   ```

5. **🚨 KRİTİK: DOĞRU KATEGORİ SEÇ!**

   **SEÇENEK 1 (ÖNERİLEN):**
   ```
   Kategori: E-commerce
   Alt Kategori: Other
   
   ✅ Neden iyi?
   • .store TLD ile uyumlu
   • Veri kısıtlaması yok
   • Lead form için ideal
   ```

   **SEÇENEK 2:**
   ```
   Kategori: E-commerce
   Alt Kategori: Health & Beauty
   
   ✅ Neden iyi?
   • Ürün satışı için uygun
   • Genel sağlık ürünleri (hassas veri değil)
   • Kısıtlama yok
   ```

   **SEÇENEK 3:**
   ```
   Kategori: General
   Alt Kategori: News & Media
   
   ✅ Neden iyi?
   • "rehber haber" temasıyla uyumlu
   • Hiç kısıtlama yok
   • En güvenli seçenek
   ```

   **❌ ASLA SEÇME:**
   - "Sağlık ve zindelik - diğer"
   - "Health & wellness - other"
   - "Sağlık ve zindelik durumu"
   - "Health & wellness conditions"

6. **Pixel ID'yi kaydet:**
   ```
   Yeni Pixel ID: [ÖRNEK: 1234567890123456]
   ```

### 2.2 Domain Verification Kur

1. **Business Settings → Brand Safety → Domains**
   - https://business.facebook.com/settings/domains

2. **Add Domain:**
   ```
   Domain: xn--hrriyetrehberhaber-tzc.store
   ```

3. **Verification Method: Meta Tag**
   
   Facebook size bir kod verecek:
   ```html
   <meta name="facebook-domain-verification" content="abc123xyz456" />
   ```

4. **Bu kodu landing page'e ekleyeceğiz (Aşama 5'te)**

---

## AŞAMA 3: NGINX KONFIGÜRASYONU

### 3.1 Sunucuya Bağlan

```bash
# SSH ile sunucuya bağlan
ssh root@SUNUCU_IP
```

### 3.2 NGINX Config Dosyasını Oluştur

```bash
# Config dizinine git
cd /etc/nginx-hurriyet/sites-available/

# Yeni config dosyasını oluştur
sudo nano hurriyetrehberhaber-store
```

**Config içeriğini kopyala:**

`/home/root/webapp/hurriyetrehberhaber-store-NGINX-CONFIG.conf` dosyasının içeriğini buraya yapıştır.

**⚠️ ÖNEMLİ DEĞİŞİKLİKLER:**
- `server_name`: `xn--hrriyetrehberhaber-tzc.store www.xn--hrriyetrehberhaber-tzc.store`
- `ssl_certificate`: `/etc/letsencrypt/live/xn--hrriyetrehberhaber-tzc.store/fullchain.pem`
- `ssl_certificate_key`: `/etc/letsencrypt/live/xn--hrriyetrehberhaber-tzc.store/privkey.pem`
- `root`: `/root/hurriyetrehberhaber-store/public`
- `access_log`: `/var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log`
- `error_log`: `/var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.error.log`

**Kaydet ve çık:**
- `Ctrl + O` (kaydet)
- `Enter` (onayla)
- `Ctrl + X` (çık)

### 3.3 Site'ı Aktifleştir

```bash
# Symlink oluştur
sudo ln -s /etc/nginx-hurriyet/sites-available/hurriyetrehberhaber-store \
           /etc/nginx-hurriyet/sites-enabled/

# Config test et (HENÜZ SSL YOK, HATA VERECEKTİR - NORMAL!)
sudo nginx -t -c /etc/nginx-hurriyet/nginx.conf

# Şimdilik hata normal - SSL kurulumundan sonra düzelecek
```

### 3.4 robots.txt Hazırla

```bash
# robots.txt için içerik hazırla (Aşama 5'te kullanacağız)
cat > /tmp/robots.txt << 'EOF'
# Facebook bots allowed
User-agent: facebookexternalhit
Allow: /

User-agent: Facebot
Allow: /

User-agent: facebookcatalog
Allow: /

# All other bots blocked
User-agent: *
Disallow: /
EOF
```

---

## AŞAMA 4: SSL SERTİFİKA

### 4.1 Certbot ile SSL Al

**⚠️ DNS propagation tamamlandıysa devam edin!**

```bash
# DNS kontrol (son bir kez)
dig +short xn--hrriyetrehberhaber-tzc.store

# IP görünüyorsa devam et
```

**Certbot webroot dizinini hazırla:**

```bash
# Certbot webroot dizini var mı kontrol et
ls -la /var/www/certbot/

# Yoksa oluştur
sudo mkdir -p /var/www/certbot
sudo chown -R www-data:www-data /var/www/certbot
sudo chmod -R 755 /var/www/certbot
```

**SSL sertifikası al:**

```bash
# Certbot ile SSL sertifika al
sudo certbot certonly --webroot \
  -w /var/www/certbot \
  -d xn--hrriyetrehberhaber-tzc.store \
  -d www.xn--hrriyetrehberhaber-tzc.store \
  --email admin@xn--hrriyetrehberhaber-tzc.store \
  --agree-tos \
  --no-eff-email
```

**Beklenen çıktı:**
```
Successfully received certificate.
Certificate is saved at: /etc/letsencrypt/live/xn--hrriyetrehberhaber-tzc.store/fullchain.pem
Key is saved at: /etc/letsencrypt/live/xn--hrriyetrehberhaber-tzc.store/privkey.pem
```

**SSL sertifikayı kontrol et:**

```bash
# Sertifika dosyaları var mı?
sudo ls -la /etc/letsencrypt/live/xn--hrriyetrehberhaber-tzc.store/

# Beklenen dosyalar:
# - fullchain.pem
# - privkey.pem
# - cert.pem
# - chain.pem
```

### 4.2 NGINX Reload

```bash
# Config test et (artık SSL var, hata vermemeli)
sudo nginx -t -c /etc/nginx-hurriyet/nginx.conf

# Beklenen çıktı:
# nginx: the configuration file /etc/nginx-hurriyet/nginx.conf syntax is ok
# nginx: configuration file /etc/nginx-hurriyet/nginx.conf test is successful

# NGINX reload
sudo systemctl reload nginx-hurriyet

# NGINX status kontrol
sudo systemctl status nginx-hurriyet
```

### 4.3 SSL Auto-Renewal Test

```bash
# Certbot renewal test
sudo certbot renew --dry-run

# Beklenen çıktı:
# Congratulations, all simulated renewals succeeded
```

---

## AŞAMA 5: LANDING PAGE DEPLOY

### 5.1 Landing Page Template'i Güncelle

**Template dosyasını aç:**

```bash
cd /home/root/webapp

# Template'i düzenle
nano hurriyetrehberhaber-store-template.html
```

**GÜNCELLEME 1: Facebook Domain Verification**

Satır 6'daki:
```html
<meta name="facebook-domain-verification" content="[YENİ_VERIFICATION_CODE_BURAYA]" />
```

Değiştir:
```html
<meta name="facebook-domain-verification" content="ABC123XYZ456" />
```
*(Aşama 2.2'de aldığınız gerçek kodu kullanın)*

**GÜNCELLEME 2: Facebook Pixel ID (3 yerde değiştirin)**

1. Satır 34:
```javascript
fbq('init', '[YENİ_PIXEL_ID_BURAYA]');
```
→
```javascript
fbq('init', '1234567890123456');
```

2. Satır 39:
```html
src="https://www.facebook.com/tr?id=[YENİ_PIXEL_ID_BURAYA]&ev=PageView&noscript=1"/>
```
→
```html
src="https://www.facebook.com/tr?id=1234567890123456&ev=PageView&noscript=1"/>
```

**Kaydet ve çık:**
- `Ctrl + O` → `Enter` → `Ctrl + X`

### 5.2 Public Dizin Oluştur ve Deploy Et

```bash
# Public dizin oluştur
sudo mkdir -p /root/hurriyetrehberhaber-store/public

# Template'i index.html olarak kopyala
sudo cp /home/root/webapp/hurriyetrehberhaber-store-template.html \
        /root/hurriyetrehberhaber-store/public/index.html

# robots.txt kopyala
sudo cp /tmp/robots.txt /root/hurriyetrehberhaber-store/public/

# İzinleri ayarla
sudo chown -R www-data:www-data /root/hurriyetrehberhaber-store/
sudo chmod -R 755 /root/hurriyetrehberhaber-store/

# Dosyalar hazır mı kontrol et
ls -la /root/hurriyetrehberhaber-store/public/
```

**Beklenen çıktı:**
```
total 28
-rw-r--r-- 1 www-data www-data 22038 Oct 17 12:00 index.html
-rw-r--r-- 1 www-data www-data   234 Oct 17 12:00 robots.txt
```

---

## AŞAMA 6: TEST ve DOĞRULAMA

### 6.1 Temel Erişim Testi

```bash
# HTTPS çalışıyor mu?
curl -I https://xn--hrriyetrehberhaber-tzc.store

# Beklenen çıktı:
# HTTP/2 403  (Facebook referrer yok çünkü - NORMAL!)
```

**403 normal mi?** EVET! Çünkü:
- Facebook referrer yok
- fbclid yok
- access_key yok
→ NGINX doğru çalışıyor, güvenlik katmanları aktif

### 6.2 Access Key ile Test

```bash
# Access key ile test
curl -I "https://xn--hrriyetrehberhaber-tzc.store?access_key=HUR2024_SecureTest_9K3mP7xQ"

# Beklenen çıktı:
# HTTP/2 200 OK
# content-type: text/html
```

**✅ 200 OK aldıysanız: BAŞARI! Site çalışıyor!**

### 6.3 Facebook Bot Testi

```bash
# Facebook bot olarak istek gönder
curl -I -A "facebookexternalhit/1.1" https://xn--hrriyetrehberhaber-tzc.store

# Beklenen çıktı:
# HTTP/2 200 OK
```

### 6.4 Mobile User-Agent Testi

```bash
# Mobile user-agent + fbclid ile test
curl -I -A "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X)" \
  "https://xn--hrriyetrehberhaber-tzc.store?fbclid=test123"

# Beklenen çıktı:
# HTTP/2 200 OK
```

### 6.5 Desktop Engelleme Testi

```bash
# Desktop user-agent ile test (ENGELLENMELİ!)
curl -I -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" \
  "https://xn--hrriyetrehberhaber-tzc.store?fbclid=test123"

# Beklenen çıktı:
# HTTP/2 403 Forbidden ✅ (Desktop engellendi - DOĞRU!)
```

### 6.6 Form Submit Testi

```bash
# Test lead gönder
curl -X POST https://xn--hrriyetrehberhaber-tzc.store/submit-order \
  -H "Content-Type: application/json" \
  -H "Origin: https://xn--hrriyetrehberhaber-tzc.store" \
  -d '{
    "customerName": "Test User",
    "phoneNumber": "5551234567",
    "timestamp": "'$(date -u +"%Y-%m-%dT%H:%M:%SZ")'"
  }'

# Beklenen çıktı:
# {"success": true} (veya N8N webhook'unuzun response'u)
```

**N8N webhook'a ulaştı mı kontrol edin:**
- N8N dashboard'a gidin
- Webhook execution'ları kontrol edin
- Test lead görünmeli

### 6.7 Browser'da Manuel Test

1. **Access key ile siteyi aç:**
   ```
   https://xn--hrriyetrehberhaber-tzc.store?access_key=HUR2024_SecureTest_9K3mP7xQ
   ```

2. **Sayfa açıldı mı?**
   - ✅ Başlık: "Hürriyet Rehber Haber - Güncel Bilgiler"
   - ✅ Form görünüyor
   - ✅ "799 TL" fiyat kutusu var

3. **Browser Console kontrol (F12):**
   ```
   🔐 SECURE ACCESS KEY VERIFIED
   Test/Debug Mode Aktif
   ```

4. **Facebook Pixel test:**
   ```javascript
   // Console'a yazın
   fbq('track', 'PageView');
   
   // Network tab'da kontrol edin:
   // Request to: https://www.facebook.com/tr?id=1234567890123456&ev=PageView
   ```

5. **Form test:**
   - İsim: Test User
   - Telefon: 5551234567
   - "Siparişimi Ver" butonuna tıkla
   - ✅ "Siparişiniz alındı! Teşekkür ederiz."

### 6.8 Facebook Domain Verification

1. **Business Settings → Domains**
   - https://business.facebook.com/settings/domains

2. **Domain'i ekle:**
   - `xn--hrriyetrehberhaber-tzc.store`

3. **Meta tag verify et:**
   - "Verify" butonuna tıkla
   - ✅ Yeşil onay işareti görmeli

4. **Events Manager'da Pixel kontrol:**
   - Events Manager → Pixel → Overview
   - "PageView" event görünüyor mu?
   - Son 20 dakikadaki test event'leri görmeli

---

## AŞAMA 7: KAMPANYA TAŞIMA

### 7.1 Yeni Test Kampanya Oluştur

**Ads Manager → Create Campaign**

#### Campaign Level:
```
Objective: Leads
Campaign Name: Hürriyet Rehber Haber - Test
Buying Type: Auction
Special Ad Category: NONE (veya "Housing", "Employment" DEĞİL!)
Budget: 100-200 TRY (test için düşük)
```

#### Ad Set Level:
```
Ad Set Name: Hürriyet Test - Mobile TR
Pixel: [YENİ_PIXEL_ID] ← ÇOK ÖNEMLİ!
Conversion Event: Lead
Location: Turkey
Age: 25-65 (veya hedef kitleniz)
Gender: All
Placement: Automatic (Mobile öncelikli)
Budget: 50-100 TRY/gün
```

#### Ad Level:
```
Ad Name: Hürriyet Rehber Haber - Ad 1
Format: Single image or video
Primary Text: [Aynı reklam metni]
Headline: [Aynı başlık]
Description: [Aynı açıklama]

Destination:
Website URL: https://xn--hrriyetrehberhaber-tzc.store?fbclid={{ad.id}}

Call to Action: Learn More (veya "Sign Up")
```

### 7.2 Eski Kampanyayı Duraklat

```
❌ ESKİ KAMPANYA (Eski Pixel) → PAUSE
✅ YENİ KAMPANYA (Yeni Pixel) → ACTIVE
```

### 7.3 İlk 24 Saat İzle

**Kontrol Listesi:**

- [ ] Kampanya active mi?
- [ ] İlk tıklama geldi mi? (1 saat içinde)
- [ ] İlk lead geldi mi? (3-6 saat içinde)
- [ ] Events Manager'da lead görünüyor mu?
- [ ] N8N webhook'a lead ulaştı mı?
- [ ] CRM'e kaydedildi mi?

**Başarı Kriterleri (24 saat):**
```
✅ 5-10 lead geldi
✅ CPL (Cost Per Lead) makul seviyede (100-200 TRY)
✅ Conversion rate %3-5
✅ Events Manager'da tüm lead'ler görünüyor
✅ N8N webhook çalışıyor
```

**Başarısızlık (24 saat lead gelmedi):**
```
❌ Lead yok → SORUN VAR
→ Debug gerekli (Aşama 8: Sorun Giderme)
```

---

## AŞAMA 8: ESKİ DOMAIN'İ KAPAT

**⚠️ YENİ DOMAIN 48 SAAT STABIL ÇALIŞTIKTAN SONRA!**

### 8.1 Eski Site'ı Devre Dışı Bırak

```bash
# SSH ile sunucuya bağlan
ssh root@SUNUCU_IP

# Eski NGINX site'ı kapat
sudo rm /etc/nginx-hurriyet/sites-enabled/hurriyet-health

# Config test
sudo nginx -t -c /etc/nginx-hurriyet/nginx.conf

# NGINX reload
sudo systemctl reload nginx-hurriyet
```

### 8.2 Eski Pixel'i Devre Dışı Bırak

1. **Events Manager → Pixel (1536997377317312)**
   - Settings → Deactivate

2. **Kampanyaları kontrol et:**
   - Eski pixel kullanan kampanya var mı?
   - Hepsini yeni pixel'e taşı veya durdur

### 8.3 Eski Domain'i Park Et

```
Seçenek A: Domain yenilemeyi iptal et
Seçenek B: 301 redirect yap (SEO için)
Seçenek C: Domain'i sat
```

---

## 🚨 SORUN GİDERME

### DNS Çalışmıyor

**Semptom:** `dig +short xn--hrriyetrehberhaber-tzc.store` IP göstermiyor

**Çözüm:**
```bash
# DNS nameserver kontrol
dig NS xn--hrriyetrehberhaber-tzc.store

# Nameserver'lar doğru mu?
# Domain registrar'da nameserver ayarları kontrol et

# TTL dolmasını bekle (300 saniye = 5 dakika)
# DNS cache temizle:
sudo systemd-resolve --flush-caches
```

### SSL Alınamıyor

**Semptom:** Certbot hata veriyor

**Çözüm:**
```bash
# Port 80 açık mı?
sudo netstat -tulpn | grep :80

# Webroot dizin var mı?
ls -la /var/www/certbot/

# NGINX HTTP server çalışıyor mu?
curl -I http://xn--hrriyetrehberhaber-tzc.store/.well-known/acme-challenge/test

# DNS propagation tamamlandı mı?
dig +short xn--hrriyetrehberhaber-tzc.store
```

### 403 Forbidden (Access Key ile de çalışmıyor)

**Semptom:** Access key ile bile 403

**Çözüm:**
```bash
# NGINX error log kontrol
sudo tail -50 /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.error.log

# Geo-blocking sorunu mu?
grep "geoip_country_code" /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.error.log

# Mobile-only sorunu mu?
curl -I -A "Mozilla/5.0 (iPhone)" \
  "https://xn--hrriyetrehberhaber-tzc.store?access_key=HUR2024_SecureTest_9K3mP7xQ"
```

### Facebook Bot Engelliyor

**Semptom:** Facebook bot 403 alıyor

**Çözüm:**
```bash
# User-agent regex doğru mu?
grep "facebook" /etc/nginx-hurriyet/sites-available/hurriyetrehberhaber-store

# Beklenen:
# if ($http_user_agent ~* "(facebookexternalhit|facebookcatalog|Facebot)") {

# Test:
curl -I -A "facebookexternalhit/1.1" https://xn--hrriyetrehberhaber-tzc.store
# Beklenen: 200 OK
```

### Lead Gelmiyor

**Semptom:** Kampanya çalışıyor ama lead yok

**Kontrol Listesi:**
```bash
# 1. Pixel çalışıyor mu?
# Browser console:
fbq('track', 'Lead', {content_name: 'Test', value: 1, currency: 'TRY'});

# 2. Events Manager'da event görünüyor mu?
# Facebook Events Manager → Test Events

# 3. Form submit çalışıyor mu?
curl -X POST https://xn--hrriyetrehberhaber-tzc.store/submit-order \
  -H "Content-Type: application/json" \
  -d '{"customerName": "Test", "phoneNumber": "5551234567"}'

# 4. N8N webhook çalışıyor mu?
curl -X POST https://n8nwork.dtekai.com/webhook/bc74f59e-54c2-4521-85a1-6e21a0438c31 \
  -H "Content-Type: application/json" \
  -d '{"test": true}'

# 5. NGINX form submit blokluyor mu?
grep "submit-order" /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log
```

### Meta Yine Sağlık Kategorisine Kilitledi

**Semptom:** Yeni pixel'de de sadece sağlık kategorileri görünüyor

**Çözüm:**
```
1. Facebook Support'a başvur
   - Business Help Center
   - "My pixel category is locked"

2. Pixel'i sil ve yenisini oluştur
   - Farklı kategori seç (E-commerce veya General)

3. Domain içeriğini değiştir
   - Landing page'den sağlık ile ilgili kelimeler çıkar
   - Daha nötr içerik ekle
```

---

## 📊 MONITORING ve MAINTENANCE

### Günlük Kontroller

```bash
# 1. Site erişilebilir mi?
curl -I "https://xn--hrriyetrehberhaber-tzc.store?access_key=HUR2024_SecureTest_9K3mP7xQ"

# 2. SSL geçerli mi?
openssl s_client -connect xn--hrriyetrehberhaber-tzc.store:443 -servername xn--hrriyetrehberhaber-tzc.store

# 3. Facebook bot access var mı?
grep "facebook" /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log | tail -10

# 4. Form submit var mı?
grep "submit-order" /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.access.log | tail -10

# 5. Rate limiting aşılıyor mu?
grep "limiting" /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.error.log

# 6. Error var mı?
tail -20 /var/log/nginx-hurriyet/hurriyetrehberhaber-store-ssl.error.log
```

### Haftalık Kontroller

```bash
# SSL sertifika ne zaman dolacak?
sudo certbot certificates | grep "xn--hrriyetrehberhaber-tzc.store" -A 10

# Disk kullanımı
df -h

# Log rotation çalışıyor mu?
ls -lh /var/log/nginx-hurriyet/*.log

# NGINX memory kullanımı
ps aux | grep nginx
```

---

## 📋 KONTROL LİSTESİ

### Başlamadan Önce

- [ ] Domain satın alındı: `hürriyetrehberhaber.store`
- [ ] Domain erişimi var
- [ ] Sunucu SSH erişimi var
- [ ] Facebook Business Manager erişimi var

### DNS (Aşama 1)

- [ ] A record eklendi (@ ve www)
- [ ] CAA record eklendi (SSL için)
- [ ] DNS propagation tamamlandı (10-30 dakika)
- [ ] `dig +short xn--hrriyetrehberhaber-tzc.store` IP gösteriyor

### Facebook Pixel (Aşama 2)

- [ ] Yeni pixel oluşturuldu
- [ ] ✅ DOĞRU kategori seçildi (E-commerce/General/News)
- [ ] Pixel ID kaydedildi
- [ ] Domain verification meta tag alındı
- [ ] Domain Business Settings'e eklendi

### NGINX (Aşama 3)

- [ ] Config dosyası oluşturuldu
- [ ] Site enabled edildi
- [ ] robots.txt hazırlandı

### SSL (Aşama 4)

- [ ] Certbot ile sertifika alındı
- [ ] NGINX reload yapıldı
- [ ] SSL test edildi (curl -I https://...)
- [ ] Auto-renewal test edildi

### Landing Page (Aşama 5)

- [ ] Template güncellendi (verification code)
- [ ] Pixel ID 3 yerde değiştirildi
- [ ] Public dizin oluşturuldu
- [ ] index.html ve robots.txt deploy edildi
- [ ] İzinler ayarlandı (www-data:www-data)

### Test (Aşama 6)

- [ ] Access key ile 200 OK
- [ ] Facebook bot bypass çalışıyor
- [ ] Mobile user-agent + fbclid ile 200 OK
- [ ] Desktop user-agent ile 403 Forbidden
- [ ] Form submit N8N'ye ulaşıyor
- [ ] Browser'da manuel test başarılı
- [ ] Facebook domain verify edildi
- [ ] Pixel PageView event görünüyor

### Kampanya (Aşama 7)

- [ ] Yeni test kampanya oluşturuldu
- [ ] Doğru pixel seçildi
- [ ] Landing page URL doğru
- [ ] Test bütçesi ayarlandı
- [ ] Kampanya başlatıldı
- [ ] İlk tıklama geldi (1 saat içinde)
- [ ] İlk lead geldi (24 saat içinde)
- [ ] Lead N8N'ye ulaştı
- [ ] Lead CRM'e kaydedildi

### Eski Domain (Aşama 8 - 48 saat sonra)

- [ ] Yeni domain 48 saat stabil çalıştı
- [ ] Eski NGINX site kapatıldı
- [ ] Eski pixel deactivate edildi
- [ ] Eski kampanyalar durduruldu
- [ ] Domain park edildi/satıldı

---

## 🎯 ÖZET: HIZLI BAŞLANGIÇ

```
┌─────────────────────────────────────────────────────────────┐
│  🚀 YENİ DOMAIN İLE TEMİZ BAŞLANGIÇ                         │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Domain: hürriyetrehberhaber.store                         │
│  Punycode: xn--hrriyetrehberhaber-tzc.store                │
│                                                             │
│  ✅ Sağlık/hastalık kelimesi YOK                           │
│  ✅ Meta kilitleme riski YOK                               │
│  ✅ Veri kısıtlaması YOK                                   │
│  ✅ Lead'ler normal akacak                                 │
│                                                             │
│  SÜRE:                                                      │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│  • DNS: 10-30 dakika                                       │
│  • Kurulum: 2-3 saat                                       │
│  • Test: 24 saat                                           │
│  • Tam geçiş: 48 saat                                      │
│                                                             │
│  BAŞARI KRİTERİ:                                           │
│  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  │
│  • Lead'ler akıyor ✅                                      │
│  • Events Manager'da görünüyor ✅                          │
│  • N8N webhook'a ulaşıyor ✅                               │
│  • CRM'e kaydediliyor ✅                                   │
│  • CPL normal seviyede ✅                                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

**Doküman Versiyonu**: 1.0  
**Tarih**: 2025-10-17  
**Tahmini Süre**: 2-3 saat (ilk çalışır hale)  
**Risk Seviyesi**: 🟢 DÜŞÜK

---

**SONRAKI ADIM**: DNS ayarlarını yapın (Aşama 1) ve bana bildirin, adım adım ilerleyelim!
