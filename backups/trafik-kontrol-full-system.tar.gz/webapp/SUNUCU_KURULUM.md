# 🚀 SUNUCU KURULUM REHBERİ - Traffic Management Platform

## 📋 Bu Sistem Nedir?
Şu anda çalışan ve test edilmiş **Traffic Management Platform**'un tam kopyası:
- ✅ AI Bot Detection System (48,000 satır)
- ✅ Real-time Analytics Dashboard
- ✅ Domain & DNS Management
- ✅ React/Vanilla JS Hybrid System
- ✅ WebSocket/SSE Communication
- ✅ NGINX Config Generator

**Test URL:** https://3000-i8j1lmrko0n8kln030u4v-6532622b.e2b.dev/
**Login:** admin / admin123

---

## 🔧 SUNUCUDA KURULMASI GEREKENLER

### 1. Node.js 18+ ve NPM
```bash
# Ubuntu/Debian:
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs

# Kontrol:
node --version  # 18+ olmalı
npm --version
```

### 2. PM2 Process Manager
```bash
sudo npm install -g pm2
```

### 3. Git
```bash
sudo apt-get install git
```

### 4. Nginx (Opsiyonel ama Önerilen)
```bash
sudo apt-get install nginx
```

---

## 📦 KURULUM ADIMLARI

### Adım 1: Kodu İndir
```bash
# Sunucunuzda istediğiniz dizinde:
git clone https://github.com/serkandogan34/trafikkontrol.git
cd trafikkontrol
```

### Adım 2: Dependencies Yükle
```bash
npm install
```

### Adım 3: Build Et
```bash
npm run build
```

### Adım 4: Environment Ayarla
```bash
# .env dosyası oluştur:
cat > .env << 'EOF'
NODE_ENV=production
PORT=3000
ADMIN_USERNAME=admin
ADMIN_PASSWORD=Esvella2025136326
JWT_SECRET=your_super_secure_jwt_secret_change_this
EOF
```

### Adım 5: Başlat
```bash
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
# PM2'nin verdiği komutu çalıştır
```

### Adım 6: Test Et
```bash
# Çalışıyor mu kontrol et:
curl http://localhost:3000/

# PM2 durumu:
pm2 status

# Logları gör:
pm2 logs trafik-kontrol
```

---

## 🌐 NGINX AYARLARI (Opsiyonel)

```bash
sudo nano /etc/nginx/sites-available/default
```

**Nginx Config:**
```nginx
server {
    listen 80;
    server_name 207.180.204.60;  # IP'nizi yazın
    
    # Eski dashboard koruması
    location /dashboard {
        root /var/www/html;
        index index.html index.php;
        try_files $uri $uri/ =404;
    }
    
    # Yeni sistem
    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        
        # WebSocket desteği
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

```bash
sudo nginx -t
sudo systemctl restart nginx
```

---

## ✅ SONUÇ

Kurulum tamamlandıktan sonra:

- **Ana Sistem:** http://207.180.204.60/
- **Eski Dashboard:** http://207.180.204.60/dashboard
- **Login:** admin / Esvella2025136326

Tüm özellikler çalışacak:
✅ Traffic Analytics
✅ AI Bot Detection  
✅ Domain Management
✅ DNS Management
✅ Real-time Updates
✅ React UI Toggle

---

## 🆘 SORUN ÇÖZME

### Başlamazsa:
```bash
pm2 logs trafik-kontrol
pm2 restart trafik-kontrol
```

### Port problemi:
```bash
sudo netstat -tulpn | grep :3000
sudo fuser -k 3000/tcp
```

### Node.js versiyonu eski:
```bash
sudo npm cache clean -f
sudo npm install -g n
sudo n stable
```

**Sistem hazır ve test edilmiş! Sunucunuzda aynı şekilde çalışacak.** 🎯