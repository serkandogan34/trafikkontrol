#!/usr/bin/env python3
"""
Script to fix orphaned braces in dashboard.js after duplicate function removal
"""
import re

def fix_orphaned_braces():
    with open('public/static/dashboard.js', 'r') as f:
        content = f.read()
    
    lines = content.split('\n')
    cleaned_lines = []
    
    for i, line in enumerate(lines):
        # Skip lines that are just a closing brace with only comments before it
        if line.strip() == '}':
            # Look at previous lines to see if this is likely orphaned
            prev_line = lines[i-1].strip() if i > 0 else ''
            next_line = lines[i+1].strip() if i < len(lines)-1 else ''
            
            # If previous line is a variable declaration or comment, and next is comment or empty
            if (prev_line.startswith('let ') or prev_line.startswith('//') or 
                prev_line.endswith(';') or prev_line == '') and \
               (next_line.startswith('//') or next_line == ''):
                print(f"Removing orphaned closing brace at line {i+1}: '{line}'")
                continue
        
        cleaned_lines.append(line)
    
    # Write the cleaned content
    with open('public/static/dashboard.js', 'w') as f:
        f.write('\n'.join(cleaned_lines))
    
    print(f"Original lines: {len(lines)}")
    print(f"Cleaned lines: {len(cleaned_lines)}")

if __name__ == "__main__":
    fix_orphaned_braces()