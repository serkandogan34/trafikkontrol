#!/usr/bin/env python3
"""
Script to remove duplicate function declarations from dashboard.js
"""
import re

def fix_dashboard_js():
    with open('public/static/dashboard.js.backup', 'r') as f:
        content = f.read()
    
    lines = content.split('\n')
    cleaned_lines = []
    seen_functions = set()
    current_function = None
    skip_function = False
    brace_count = 0
    
    for i, line in enumerate(lines):
        # Check if this line starts a function declaration
        func_match = re.match(r'^(async\s+)?function\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*\(', line)
        
        if func_match:
            function_name = func_match.group(2)
            if function_name in seen_functions:
                # Skip this duplicate function
                skip_function = True
                current_function = function_name
                brace_count = 0
                print(f"Skipping duplicate function: {function_name} at line {i+1}")
                continue
            else:
                # This is the first occurrence
                seen_functions.add(function_name)
                skip_function = False
                current_function = function_name
                print(f"Keeping function: {function_name} at line {i+1}")
        
        if skip_function:
            # Count braces to know when function ends
            brace_count += line.count('{') - line.count('}')
            if brace_count <= 0 and current_function:
                skip_function = False
                current_function = None
            continue
        
        cleaned_lines.append(line)
    
    # Write the cleaned content
    with open('public/static/dashboard.js', 'w') as f:
        f.write('\n'.join(cleaned_lines))
    
    print(f"Original lines: {len(lines)}")
    print(f"Cleaned lines: {len(cleaned_lines)}")
    print(f"Functions seen: {len(seen_functions)}")

if __name__ == "__main__":
    fix_dashboard_js()