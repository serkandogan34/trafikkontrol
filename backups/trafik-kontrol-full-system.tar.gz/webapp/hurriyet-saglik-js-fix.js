/**
 * HÜRRİYET SAĞLIK FORM CONTAINER DÜZELTMESİ
 * Form'un sol-sağ bölünme sorununu dinamik olarak çözer
 */

(function() {
    'use strict';
    
    console.log('Hürriyet Sağlık form düzeltmeleri başlatılıyor...');
    
    // Ana düzeltme fonksiyonu
    function fixFormContainerLayout() {
        
        // Form container'ları bul ve düzelt
        const formSelectors = [
            '.form-container',
            '.order-form', 
            '.siparis-form',
            '.resmi-basvuru-form',
            'form[action*="siparis"]',
            'form[action*="order"]'
        ];
        
        formSelectors.forEach(selector => {
            const containers = document.querySelectorAll(selector);
            containers.forEach(container => {
                fixSingleContainer(container, 'Form Container');
            });
        });
        
        // Fiyat kutusunu düzelt
        const priceSelectors = [
            '.price-box',
            '.fiyat-kutusu', 
            '.fiyat-container',
            '[class*="price"]',
            '[class*="fiyat"]'
        ];
        
        priceSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                if (element.textContent.includes('799') || element.textContent.includes('TL')) {
                    fixPriceBox(element);
                }
            });
        });
        
        // Kampanya bölümünü düzelt
        const campaignSelectors = [
            '.countdown-section',
            '.kampanya-sure',
            '[class*="kampanya"]',
            '[class*="countdown"]'
        ];
        
        campaignSelectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                fixSingleContainer(element, 'Kampanya Section');
            });
        });
        
        // Form input'larını düzelt
        fixFormInputs();
        
        // Submit button'u düzelt
        fixSubmitButton();
        
        console.log('Form container düzeltmeleri tamamlandı.');
    }
    
    // Tek container düzeltme
    function fixSingleContainer(element, type = 'Container') {
        if (!element) return;
        
        console.log(`${type} düzeltiliyor:`, element);
        
        // Temel stil düzeltmeleri
        element.style.width = '800px';
        element.style.maxWidth = '90%';
        element.style.margin = '20px auto';
        element.style.padding = '20px';
        element.style.boxSizing = 'border-box';
        element.style.display = 'block';
        element.style.clear = 'both';
        element.style.float = 'none';
        element.style.position = 'relative';
        
        // İç div'leri düzelt
        const innerDivs = element.querySelectorAll('div');
        innerDivs.forEach(div => {
            div.style.boxSizing = 'border-box';
            
            // Form row'lar hariç, diğerlerini full width yap
            if (!div.classList.contains('form-row') && 
                !div.classList.contains('countdown-boxes') &&
                !div.classList.contains('sure-kutulari')) {
                div.style.width = '100%';
                div.style.clear = 'both';
                div.style.float = 'none';
            }
        });
    }
    
    // Fiyat kutusu özel düzeltmesi
    function fixPriceBox(element) {
        console.log('Fiyat kutusu düzeltiliyor:', element);
        
        element.style.width = '280px';
        element.style.maxWidth = '90%';
        element.style.margin = '15px auto';
        element.style.padding = '15px';
        element.style.background = 'white';
        element.style.border = '3px solid #4CAF50';
        element.style.borderRadius = '8px';
        element.style.textAlign = 'center';
        element.style.display = 'block';
        element.style.boxSizing = 'border-box';
    }
    
    // Form input'ları düzeltme
    function fixFormInputs() {
        const inputs = document.querySelectorAll('input[type="text"], input[type="tel"], input[type="email"], select, textarea');
        
        inputs.forEach(input => {
            input.style.width = '100%';
            input.style.maxWidth = '100%';
            input.style.padding = '12px 15px';
            input.style.border = '2px solid #ddd';
            input.style.borderRadius = '5px';
            input.style.fontSize = '16px';
            input.style.boxSizing = 'border-box';
            input.style.margin = '0';
            
            // Focus event
            input.addEventListener('focus', function() {
                this.style.borderColor = '#e74c3c';
            });
            
            input.addEventListener('blur', function() {
                this.style.borderColor = '#ddd';
            });
        });
        
        console.log(`${inputs.length} form input düzeltildi.`);
    }
    
    // Submit button düzeltme
    function fixSubmitButton() {
        const buttons = document.querySelectorAll('button[type="submit"], input[type="submit"], .submit-btn, .siralama-btn, button');
        
        buttons.forEach(button => {
            // Sadece form submit button'larını düzelt
            if (button.textContent.includes('Sıralama') || 
                button.textContent.includes('Sipariş') ||
                button.textContent.includes('Gönder') ||
                button.type === 'submit') {
                
                button.style.width = '100%';
                button.style.maxWidth = '300px';
                button.style.margin = '20px auto 0';
                button.style.padding = '15px 30px';
                button.style.background = '#e74c3c';
                button.style.color = 'white';
                button.style.border = 'none';
                button.style.borderRadius = '5px';
                button.style.fontSize = '16px';
                button.style.fontWeight = 'bold';
                button.style.cursor = 'pointer';
                button.style.display = 'block';
                button.style.textAlign = 'center';
                button.style.textTransform = 'uppercase';
                button.style.boxSizing = 'border-box';
                
                // Hover effect
                button.addEventListener('mouseenter', function() {
                    this.style.background = '#c0392b';
                });
                
                button.addEventListener('mouseleave', function() {
                    this.style.background = '#e74c3c';
                });
                
                console.log('Submit button düzeltildi:', button);
            }
        });
    }
    
    // Genişlik tutarlılığını kontrol et
    function checkWidthConsistency() {
        const sections = document.querySelectorAll('.content-section, .icerik-bolum, .form-container, .main-content');
        
        sections.forEach(section => {
            const computedStyle = window.getComputedStyle(section);
            const width = computedStyle.width;
            
            console.log('Section genişliği:', width, section);
            
            if (parseInt(width) > 850) {
                section.style.maxWidth = '800px';
                section.style.margin = '0 auto';
            }
        });
    }
    
    // CSS ekle
    function addFixCSS() {
        const style = document.createElement('style');
        style.id = 'hurriyet-saglik-fix-css';
        style.textContent = `
            /* Hürriyet Sağlık Form Container Düzeltmeleri */
            .form-container, .order-form, .siparis-form {
                width: 800px !important;
                max-width: 90% !important;
                margin: 20px auto !important;
                padding: 20px !important;
                box-sizing: border-box !important;
                display: block !important;
                clear: both !important;
                float: none !important;
                position: relative !important;
            }
            
            .price-box, .fiyat-kutusu {
                width: 280px !important;
                max-width: 90% !important;
                margin: 15px auto !important;
                display: block !important;
                text-align: center !important;
            }
            
            .form-field input, input[type="text"], input[type="tel"] {
                width: 100% !important;
                box-sizing: border-box !important;
            }
            
            .submit-btn, button[type="submit"] {
                width: 100% !important;
                max-width: 300px !important;
                margin: 20px auto 0 !important;
                display: block !important;
            }
            
            @media (max-width: 768px) {
                .form-container, .price-box {
                    width: 95% !important;
                    margin: 10px auto !important;
                }
            }
        `;
        
        // Mevcut stil varsa kaldır
        const existingStyle = document.getElementById('hurriyet-saglik-fix-css');
        if (existingStyle) {
            existingStyle.remove();
        }
        
        document.head.appendChild(style);
    }
    
    // Ana başlatma fonksiyonu
    function initialize() {
        addFixCSS();
        fixFormContainerLayout();
        checkWidthConsistency();
        
        // Form submit event'lerini yakalamak için
        document.addEventListener('submit', function(e) {
            console.log('Form submit:', e.target);
            // İsterseniz form validation ekleyebilirsiniz
        });
        
        // Sayfa tamamen yüklendikten sonra tekrar kontrol et
        setTimeout(() => {
            fixFormContainerLayout();
            checkWidthConsistency();
        }, 2000);
    }
    
    // DOM hazır olduğunda veya hemen çalıştır
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize);
    } else {
        initialize();
    }
    
    // Sayfa yüklendikten sonra da çalıştır
    window.addEventListener('load', function() {
        setTimeout(initialize, 1000);
    });
    
    // Window resize'da yeniden düzenle
    window.addEventListener('resize', function() {
        fixFormContainerLayout();
    });
    
})();