# 🚀 KAMPANYA BAŞLATMA - SON KONTROL LİSTESİ

**Tarih**: 2025-10-14  
**Durum**: 🟢 TÜM SİSTEMLER HAZIR!  
**Pixel Status**: ✅ Aktif ve Test Edildi

---

## ✅ TEKNİK HAZIRLIK (TAMAMLANDI!)

- [x] ✅ Landing page yayında
- [x] ✅ SSL sertifikası aktif (2026-01-10'a kadar)
- [x] ✅ Domain çalışıyor: hüriyetsagliksonnhaberler.site
- [x] ✅ 8 katmanlı güvenlik sistemi aktif
- [x] ✅ fbclid kontrolü çalışıyor
- [x] ✅ Form webhook hazır (N8N)
- [x] ✅ Rate limiting aktif
- [x] ✅ Mobile-only erişim aktif
- [x] ✅ Admin bypass çalışıyor

## ✅ FACEBOOK PIXEL (TAMAMLANDI!)

- [x] ✅ Pixel kodu eklendi (1536997377317312)
- [x] ✅ PageView event aktif
- [x] ✅ ViewContent event aktif
- [x] ✅ Lead event aktif
- [x] ✅ Pixel Helper ile test edildi 🟢
- [x] ✅ "Verileri Bağla" butonu yeşil 🟢
- [x] ✅ Events Manager'da görünüyor

---

## 🎯 KAMPANYA KURULUM ADIMLARI

### **Adım 1: Facebook Ads Manager'a Git**
```
URL: https://business.facebook.com/adsmanager
```

### **Adım 2: Yeni Kampanya Oluştur**
```
1. "+ Oluştur" butonuna tıkla
2. Kampanya hedefi seç: "Potansiyel müşteriler" (Leads)
3. Kampanya adı: "Hürriyet Sağlık - Eklem - Ekim 2025"
```

### **Adım 3: Kampanya Ayarları**
```
Kampanya Bütçe Optimizasyonu (CBO): AÇIK
Günlük Bütçe: 100 TL (test için)
```

### **Adım 4: Reklam Seti Oluştur**

#### A. Reklam Seti Adı:
```
"TR-Mobile-25-65-Health-v1"
```

#### B. Dönüşüm Ayarları:
```
Dönüşüm Konumu: Website
Pixel: 1536997377317312 (saglikliyasam piyasa verileri)
Dönüşüm Eventi: Lead
```

#### C. Hedef Kitle:
```
Lokasyon:
  - Türkiye (tüm ülke)
  
Yaş:
  - 25-65 yaş arası
  
Cinsiyet:
  - Tümü
  
Detaylı Hedefleme:
  - "Sağlık ve wellness"
  - "Eklem ağrısı"
  - "Fizik tedavi"
  - "Yaşlı bakımı"
  
Diller:
  - Türkçe
```

#### D. Yerleşimler:
```
Önerilen: Otomatik Yerleşimler

Veya Manuel:
  ✅ Facebook Feed (Mobil)
  ✅ Instagram Feed (Mobil)
  ✅ Instagram Stories
  ❌ Desktop (kapat - sayfa mobile-only)
```

#### E. Bütçe ve Zamanlama:
```
Bütçe: 50-100 TL/gün (test)
Teklif Stratejisi: En Düşük Maliyet
Başlangıç: Hemen
```

### **Adım 5: Reklam Oluştur**

#### A. Reklam Adı:
```
"Eklem-ProblemSolution-v1"
```

#### B. Format:
```
Tek Görsel veya Video
```

#### C. Medya:
```
Görsel: 1080x1080 (kare format)
- Before/After görseli (varsa)
- Veya ürün görseli
- Veya müşteri testimonial'ı
```

#### D. Birincil Metin (Seç):

**ŞABLON 1: Problem-Çözüm**
```
🔴 Eklem ağrıları yaşamınızı zorlaştırıyor mu?

✅ Doğal içerikli çözümümüzle:
• Ağrılardan kurtulun
• Hareketliliğinizi geri kazanın  
• Günlük yaşam kalitenizi artırın

👉 Ücretsiz danışma için formu doldurun!
```

**ŞABLON 2: Aciliyet**
```
⚠️ SINIRLI SÜRE KAMPANYASI!

💊 Eklem Sağlığı Destek Ürünümüzde:
🎁 %30 İndirim + Ücretsiz Kargo

📱 Hemen formu doldurun,
🎯 Uzmanlarımız sizi arasın!

⏰ Kampanya sonuna 3 gün kaldı!
```

**ŞABLON 3: Sosyal Kanıt**
```
⭐ 50.000+ Mutlu Müşteri!

"2 haftada dizlerimin ağrısı azaldı!" - Ayşe H.
"Artık rahatlıkla yürüyebiliyorum!" - Mehmet K.

🔬 Doğal içerik, bilimsel formül
✅ Sağlık Bakanlığı onaylı

👉 Formu doldurun, farkı yaşayın!
```

#### E. Başlık:
```
"Eklem Ağrılarına Son!"
```

#### F. Açıklama:
```
"Ücretsiz danışma ve özel indirim"
```

#### G. Harekete Geçirici Mesaj:
```
"Kayıt Ol" veya "Daha Fazla Bilgi"
```

#### H. Website URL:
```
https://hüriyetsagliksonnhaberler.site/
```

**NOT**: Facebook otomatik olarak `?fbclid=xxx` ekleyecek!

### **Adım 6: Önizleme ve Kontrol**
```
1. Mobil önizlemeyi kontrol et
2. Tüm linklerin çalıştığını doğrula
3. Metin ve görsel uyumunu kontrol et
```

### **Adım 7: Yayınla! 🚀**
```
1. "Yayınla" butonuna tıkla
2. Facebook incelemesi: 1-24 saat
3. Onaylanınca otomatik başlar
```

---

## 📊 İLK 24 SAAT TAKİP

### **Kontrol Edilecek Metrikler:**

#### Events Manager:
```
URL: https://business.facebook.com/events_manager

Kontrol Et:
- PageView: 100+ event beklenir
- ViewContent: 80+ event beklenir  
- Lead: 5-10 event beklenir
```

#### Ads Manager:
```
URL: https://business.facebook.com/adsmanager

Kontrol Et:
- Gösterim: 10,000+
- Tıklama: 100+
- CTR: %1-3 hedef
- CPC: 2-5 TL hedef
- CPL: 10-30 TL hedef
```

#### Landing Page Logs:
```bash
# fbclid trafiğini kontrol et
sudo grep "fbclid" /etc/nginx-hurriyet/logs/hurriyet-health-ssl.access.log | wc -l

# Form gönderimlerini kontrol et
sudo grep "POST /submit-form" /etc/nginx-hurriyet/logs/hurriyet-health-ssl.access.log | wc -l
```

---

## 🚨 İLK GÜN YAPILMAYACAKLAR

### ❌ İlk 24-48 Saat:
```
- Kampanyayı durdurma
- Bütçeyi değiştirme
- Hedef kitleyi değiştirme
- Kreatifleri değiştirme
- Teklif stratejisini değiştirme
```

**Sebep**: Facebook öğrenme aşamasında. Değişiklik yaparsan başa döner!

---

## ✅ İLK GÜN YAPILABİLECEKLER

### ✅ Güvenle Yapılabilir:
```
- Metrikleri izlemek
- Events Manager'da event'leri görmek
- Logları kontrol etmek
- Form gönderimlerini kontrol etmek
- Pixel Helper ile test etmek
```

---

## 📈 3-7 GÜN SONRA OPTİMİZASYON

### Düşük Performans İse:

#### CTR < %0.5:
```
Çözüm:
- Görseli değiştir (daha dikkat çekici)
- Başlığı değiştir (daha net CTA)
- Emoji kullan
```

#### CPC > 10 TL:
```
Çözüm:
- Hedef kitleyi genişlet
- Yerleşimleri optimize et
- Teklif stratejisini değiştir
```

#### CPL > 50 TL:
```
Çözüm:
- Landing page'i optimize et
- Form'u basitleştir
- Teklifi daha çekici yap
```

### Başarılı İse:

#### CTR > %2, CPL < 30 TL:
```
Ölçeklendirme:
1. Bütçeyi %20 artır (her 3 günde)
2. Benzer hedef kitle oluştur (Lookalike 1%)
3. Yeni kreativler test et
4. Retargeting kampanyası başlat
```

---

## 🎯 BAŞARI KRİTERLERİ

### İlk Hafta Hedefleri:
```
Gösterim: 50,000+
Tıklama: 500+
Lead: 20-50
CPL: 20-40 TL
CTR: %1-2
CPC: 3-6 TL
```

### İkinci Hafta Hedefleri:
```
Lead: 50-100
CPL: 15-30 TL (optimize edilmiş)
CTR: %2-3
Frequency: <3 (aynı kişiye 3'ten az gösterim)
```

---

## 📞 DESTEK DOKÜMANLARI

### Kampanya İçin:
```
FACEBOOK_KAMPANYA_REHBERI.md - Detaylı kampanya kurulum
FACEBOOK_PIXEL_VERIFICATION.md - Pixel doğrulama
HURRIYET_PROJECT_STATE.md - Proje durumu
```

### Sorun Giderme:
```
FACEBOOK_PIXEL_UYARI_COZUMU.md - Pixel sorunları
SECURE_ACCESS_KEY_DOKUMANI.md - Test erişimi
FBCLID_KONTROL_TEST_RAPORU.md - fbclid testleri
```

---

## ✅ FINAL CHECKLIST

Kampanyayı başlatmadan önce son kontrol:

- [ ] Ads Manager hesabına giriş yaptın mı?
- [ ] Ödeme yöntemi tanımlı mı?
- [ ] Görseller hazır mı? (1080x1080)
- [ ] Metin şablonu seçtin mi?
- [ ] Pixel ID doğru mu? (1536997377317312)
- [ ] Hedef kitle tanımlandı mı? (TR, 25-65, Mobil)
- [ ] Bütçe belirlendi mi? (50-100 TL/gün)
- [ ] Landing page açılıyor mu?
- [ ] Form test edildi mi?
- [ ] Webhook çalışıyor mu?

**HEPSİ ✅ İSE → YAYINA AL! 🚀**

---

**Oluşturulma**: 2025-10-14  
**Son Güncelleme**: 2025-10-14  
**Durum**: 🟢 Kampanya Başlatmaya Hazır  
**Pixel Status**: ✅ Aktif ve Doğrulanmış
